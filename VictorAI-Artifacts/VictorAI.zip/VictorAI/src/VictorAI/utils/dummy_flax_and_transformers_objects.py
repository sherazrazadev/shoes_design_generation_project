
from ..utils import DummyObject, requires_backends


class FlaxStableVictorControlNetPipeline(metaclass=DummyObject):
    _backends = ["flax", "transformers"]

    def __init__(self, *args, **kwargs):
        requires_backends(self, ["flax", "transformers"])

    @classmethod
    def from_config(cls, *args, **kwargs):
        requires_backends(cls, ["flax", "transformers"])

    @classmethod
    def from_pretrained(cls, *args, **kwargs):
        requires_backends(cls, ["flax", "transformers"])


class FlaxStableVictorImg2ImgPipeline(metaclass=DummyObject):
    _backends = ["flax", "transformers"]

    def __init__(self, *args, **kwargs):
        requires_backends(self, ["flax", "transformers"])

    @classmethod
    def from_config(cls, *args, **kwargs):
        requires_backends(cls, ["flax", "transformers"])

    @classmethod
    def from_pretrained(cls, *args, **kwargs):
        requires_backends(cls, ["flax", "transformers"])


class FlaxStableVictorInpaintPipeline(metaclass=DummyObject):
    _backends = ["flax", "transformers"]

    def __init__(self, *args, **kwargs):
        requires_backends(self, ["flax", "transformers"])

    @classmethod
    def from_config(cls, *args, **kwargs):
        requires_backends(cls, ["flax", "transformers"])

    @classmethod
    def from_pretrained(cls, *args, **kwargs):
        requires_backends(cls, ["flax", "transformers"])


class FlaxStableVictorPipeline(metaclass=DummyObject):
    _backends = ["flax", "transformers"]

    def __init__(self, *args, **kwargs):
        requires_backends(self, ["flax", "transformers"])

    @classmethod
    def from_config(cls, *args, **kwargs):
        requires_backends(cls, ["flax", "transformers"])

    @classmethod
    def from_pretrained(cls, *args, **kwargs):
        requires_backends(cls, ["flax", "transformers"])


class FlaxStableVictorXLPipeline(metaclass=DummyObject):
    _backends = ["flax", "transformers"]

    def __init__(self, *args, **kwargs):
        requires_backends(self, ["flax", "transformers"])

    @classmethod
    def from_config(cls, *args, **kwargs):
        requires_backends(cls, ["flax", "transformers"])

    @classmethod
    def from_pretrained(cls, *args, **kwargs):
        requires_backends(cls, ["flax", "transformers"])
