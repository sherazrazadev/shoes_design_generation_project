
from ..utils import DummyObject, requires_backends


class OnnxStableVictorImg2ImgPipeline(metaclass=DummyObject):
    _backends = ["torch", "transformers", "onnx"]

    def __init__(self, *args, **kwargs):
        requires_backends(self, ["torch", "transformers", "onnx"])

    @classmethod
    def from_config(cls, *args, **kwargs):
        requires_backends(cls, ["torch", "transformers", "onnx"])

    @classmethod
    def from_pretrained(cls, *args, **kwargs):
        requires_backends(cls, ["torch", "transformers", "onnx"])


class OnnxStableVictorInpaintPipeline(metaclass=DummyObject):
    _backends = ["torch", "transformers", "onnx"]

    def __init__(self, *args, **kwargs):
        requires_backends(self, ["torch", "transformers", "onnx"])

    @classmethod
    def from_config(cls, *args, **kwargs):
        requires_backends(cls, ["torch", "transformers", "onnx"])

    @classmethod
    def from_pretrained(cls, *args, **kwargs):
        requires_backends(cls, ["torch", "transformers", "onnx"])


class OnnxStableVictorInpaintPipelineLegacy(metaclass=DummyObject):
    _backends = ["torch", "transformers", "onnx"]

    def __init__(self, *args, **kwargs):
        requires_backends(self, ["torch", "transformers", "onnx"])

    @classmethod
    def from_config(cls, *args, **kwargs):
        requires_backends(cls, ["torch", "transformers", "onnx"])

    @classmethod
    def from_pretrained(cls, *args, **kwargs):
        requires_backends(cls, ["torch", "transformers", "onnx"])


class OnnxStableVictorPipeline(metaclass=DummyObject):
    _backends = ["torch", "transformers", "onnx"]

    def __init__(self, *args, **kwargs):
        requires_backends(self, ["torch", "transformers", "onnx"])

    @classmethod
    def from_config(cls, *args, **kwargs):
        requires_backends(cls, ["torch", "transformers", "onnx"])

    @classmethod
    def from_pretrained(cls, *args, **kwargs):
        requires_backends(cls, ["torch", "transformers", "onnx"])


class OnnxStableVictorUpscalePipeline(metaclass=DummyObject):
    _backends = ["torch", "transformers", "onnx"]

    def __init__(self, *args, **kwargs):
        requires_backends(self, ["torch", "transformers", "onnx"])

    @classmethod
    def from_config(cls, *args, **kwargs):
        requires_backends(cls, ["torch", "transformers", "onnx"])

    @classmethod
    def from_pretrained(cls, *args, **kwargs):
        requires_backends(cls, ["torch", "transformers", "onnx"])


class StableVictorOnnxPipeline(metaclass=DummyObject):
    _backends = ["torch", "transformers", "onnx"]

    def __init__(self, *args, **kwargs):
        requires_backends(self, ["torch", "transformers", "onnx"])

    @classmethod
    def from_config(cls, *args, **kwargs):
        requires_backends(cls, ["torch", "transformers", "onnx"])

    @classmethod
    def from_pretrained(cls, *args, **kwargs):
        requires_backends(cls, ["torch", "transformers", "onnx"])
