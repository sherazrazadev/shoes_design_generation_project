import inspect
from typing import Any, Callable, Dict, List, Optional, Union
import numpy as np
import PIL.Image
import torch
from packaging import version
from transformers import CLIPImageProcessor, CLIPTextModel, CLIPTokenizer
from ...configuration_utils import FrozenDict
from ...image_processor import PipelineImageInput, VaeImageProcessor
from ...loaders import FromSingleFileMixin, LoraLoaderMixin, TextualInversionLoaderMixin
from ...models import AsymmetricAutoencoderKL, AutoencoderKL, UNet2DConditionModel
from ...models.lora import adjust_lora_scale_text_encoder
from ...schedulers import KarrasVictorSchedulers
from ...utils import USE_PEFT_BACKEND, deprecate, logging, scale_lora_layers, unscale_lora_layers
from ...utils.torch_utils import randn_tensor
from ..pipeline_utils import VictorPipeline
from . import StableVictorPipelineOutput
from .safety_checker import StableVictorSafetyChecker


logger = logging.get_logger(__name__)  




def prepare_input_for_inpainting(input_image, input_mask, input_height, input_width, return_image: bool = False):
   
    deprecation_message = "The prepare_input_for_inpainting method is deprecated and will be removed in a future version. Please use VaeImageProcessor.preprocess instead"
    deprecate(
        "prepare_input_for_inpainting",
        "0.30.0",
        deprecation_message,
    )
    if input_image is None:
        raise ValueError("`input_image` cannot be undefined.")

    if input_mask is None:
        raise ValueError("`input_mask` cannot be undefined.")

    if isinstance(input_image, torch.Tensor):
        if not isinstance(input_mask, torch.Tensor):
            raise TypeError(f"`input_image` is a torch.Tensor but `input_mask` (type: {type(input_mask)} is not")

        # Batch single image
        if input_image.ndim == 3:
            assert input_image.shape[0] == 3, "Image outside a batch should be of shape (3, H, W)"
            input_image = input_image.unsqueeze(0)

        # Batch and add channel dim for single mask
        if input_mask.ndim == 2:
            input_mask = input_mask.unsqueeze(0).unsqueeze(0)

        # Batch single mask or add channel dim
        if input_mask.ndim == 3:
            # Single batched mask, no channel dim or single mask not batched but channel dim
            if input_mask.shape[0] == 1:
                input_mask = input_mask.unsqueeze(0)

            # Batched masks no channel dim
            else:
                input_mask = input_mask.unsqueeze(1)

        assert input_image.ndim == 4 and input_mask.ndim == 4, "Image and Mask must have 4 dimensions"
        assert input_image.shape[-2:] == input_mask.shape[-2:], "Image and Mask must have the same spatial dimensions"
        assert input_image.shape[0] == input_mask.shape[0], "Image and Mask must have the same batch size"

        # Check image is in [-1, 1]
        if input_image.min() < -1 or input_image.max() > 1:
            raise ValueError("Image should be in [-1, 1] range")

        # Check mask is in [0, 1]
        if input_mask.min() < 0 or input_mask.max() > 1:
            raise ValueError("Mask should be in [0, 1] range")

        # Binarize mask
        input_mask[input_mask < 0.5] = 0
        input_mask[input_mask >= 0.5] = 1

        # Image as float32
        input_image = input_image.to(dtype=torch.float32)
    elif isinstance(input_mask, torch.Tensor):
        raise TypeError(f"`input_mask` is a torch.Tensor but `input_image` (type: {type(input_image)} is not")
    else:
        # preprocess input_image
        if isinstance(input_image, (PIL.Image.Image, np.ndarray)):
            input_image = [input_image]
        if isinstance(input_image, list) and isinstance(input_image[0], PIL.Image.Image):
            # resize all images w.r.t passed height an width
            input_image = [i.resize((input_width, input_height), resample=PIL.Image.LANCZOS) for i in input_image]
            input_image = [np.array(i.convert("RGB"))[None, :] for i in input_image]
            input_image = np.concatenate(input_image, axis=0)
        elif isinstance(input_image, list) and isinstance(input_image[0], np.ndarray):
            input_image = np.concatenate([i[None, :] for i in input_image], axis=0)

        input_image = input_image.transpose(0, 3, 1, 2)
        input_image = torch.from_numpy(input_image).to(dtype=torch.float32) / 127.5 - 1.0

        # preprocess input_mask
        if isinstance(input_mask, (PIL.Image.Image, np.ndarray)):
            input_mask = [input_mask]

        if isinstance(input_mask, list) and isinstance(input_mask[0], PIL.Image.Image):
            input_mask = [i.resize((input_width, input_height), resample=PIL.Image.LANCZOS) for i in input_mask]
            input_mask = np.concatenate([np.array(m.convert("L"))[None, None, :] for m in input_mask], axis=0)
            input_mask = input_mask.astype(np.float32) / 255.0
        elif isinstance(input_mask, list) and isinstance(input_mask[0], np.ndarray):
            input_mask = np.concatenate([m[None, None, :] for m in input_mask], axis=0)

        input_mask[input_mask < 0.5] = 0
        input_mask[input_mask >= 0.5] = 1
        input_mask = torch.from_numpy(input_mask)

    masked_input_image = input_image * (input_mask < 0.5)

    # n.b. ensure backwards compatibility as the old function does not return the image
    if return_image:
        return input_mask, masked_input_image, input_image

    return input_mask, masked_input_image






def get_latent_representation(encoder_result, gen_model):
    if hasattr(encoder_result, "latent_dist"):
        return encoder_result.latent_dist.sample(gen_model)
    elif hasattr(encoder_result, "latents"):
        return encoder_result.latents
    else:
        raise AttributeError("Could not access latents of the provided encoder_result")

class StableVictorInpaintPipeline(
    VictorPipeline, TextualInversionLoaderMixin, LoraLoaderMixin, FromSingleFileMixin
):


    model_cpu_offload_seq = "text_encoder->unet->vae"
    _optional_components = ["safety_checker", "feature_extractor"]
    _exclude_from_cpu_offload = ["safety_checker"]
    _callback_tensor_inputs = ["latents", "prompt_embeds", "negative_prompt_embeds", "mask", "masked_image_latents"]

    def __init__(
        self,
        vae: Union[AutoencoderKL, AsymmetricAutoencoderKL],
        text_encoder: CLIPTextModel,
        tokenizer: CLIPTokenizer,
        unet: UNet2DConditionModel,
        scheduler: KarrasVictorSchedulers,
        safety_checker: StableVictorSafetyChecker,
        feature_extractor: CLIPImageProcessor,
        requires_safety_checker: bool = True,
    ):
        super().__init__()

        if hasattr(scheduler.config, "steps_offset") and scheduler.config.steps_offset != 1:
            deprecation_message = (
                f"The configuration file of this scheduler: {scheduler} is outdated. `steps_offset`"
              
            )
            deprecate("steps_offset!=1", "1.0.0", deprecation_message, standard_warn=False)
            new_config = dict(scheduler.config)
            new_config["steps_offset"] = 1
            scheduler._internal_dict = FrozenDict(new_config)

        if hasattr(scheduler.config, "skip_prk_steps") and scheduler.config.skip_prk_steps is False:
            deprecation_message = (
                f"The configuration file of this scheduler: {scheduler} has not set the configuration"
               
            )
            deprecate("skip_prk_steps not set", "1.0.0", deprecation_message, standard_warn=False)
            new_config = dict(scheduler.config)
            new_config["skip_prk_steps"] = True
            scheduler._internal_dict = FrozenDict(new_config)

        if safety_checker is None and requires_safety_checker:
            logger.warning(
                f"You have disabled the safety checker for {self.__class__} by passing `safety_checker=None`. Ensure"
               
            )

        if safety_checker is not None and feature_extractor is None:
            raise ValueError(
                "Make sure to define a feature extractor when loading {self.__class__} if you want to use the safety"
                " checker. If you do not want to use the safety checker, you can pass `'safety_checker=None'` instead."
            )

        is_unet_version_less_0_9_0 = hasattr(unet.config, "_victor_version") and version.parse(
            version.parse(unet.config._victor_version).base_version
        ) < version.parse("0.9.0.dev0")
        is_unet_sample_size_less_64 = hasattr(unet.config, "sample_size") and unet.config.sample_size < 64
        if is_unet_version_less_0_9_0 and is_unet_sample_size_less_64:
            deprecation_message = (
                "The configuration file of the unet has set the default `sample_size` to smaller than"
                " 64 which seems highly unlikely .If you're checkpoint is a fine-tuned version of any of the"
               
            )
            deprecate("sample_size<64", "1.0.0", deprecation_message, standard_warn=False)
            new_config = dict(unet.config)
            new_config["sample_size"] = 64
            unet._internal_dict = FrozenDict(new_config)

        if unet.config.in_channels != 9:
            logger.info(f"You have loaded a UNet with {unet.config.in_channels} input channels which.")

        self.register_modules(
            vae=vae,
            text_encoder=text_encoder,
            tokenizer=tokenizer,
            unet=unet,
            scheduler=scheduler,
            safety_checker=safety_checker,
            feature_extractor=feature_extractor,
        )
        self.vae_scale_factor = 2 ** (len(self.vae.config.block_out_channels) - 1)
        self.image_processor = VaeImageProcessor(vae_scale_factor=self.vae_scale_factor)
        self.mask_processor = VaeImageProcessor(
            vae_scale_factor=self.vae_scale_factor, do_normalize=False, do_binarize=True, do_convert_grayscale=True
        )
        self.register_to_config(requires_safety_checker=requires_safety_checker)



    def generate_text_embeddings(
        self,
        user_prompt,
        target_device,
        images_per_prompt,
        enable_classifier_free_guidance,
        negative_user_prompt=None,
        user_prompt_embeddings: Optional[torch.FloatTensor] = None,
        negative_user_prompt_embeddings: Optional[torch.FloatTensor] = None,
        lora_scale: Optional[float] = None,
        clip_skip: Optional[int] = None,
    ):
       
      
        if lora_scale is not None and isinstance(self, LoraLoaderMixin):
            self._lora_scale = lora_scale

            # dynamically adjust the LoRA scale
            if not USE_PEFT_BACKEND:
                adjust_lora_scale_text_encoder(self.text_encoder, lora_scale)
            else:
                scale_lora_layers(self.text_encoder, lora_scale)

        if user_prompt is not None and isinstance(user_prompt, str):
            batch_size = 1
        elif user_prompt is not None and isinstance(user_prompt, list):
            batch_size = len(user_prompt)
        else:
            batch_size = user_prompt_embeddings.shape[0]

        if user_prompt_embeddings is None:
            # textual inversion: process multi-vector tokens if necessary
            if isinstance(self, TextualInversionLoaderMixin):
                user_prompt = self.maybe_convert_prompt(user_prompt, self.tokenizer)

            text_inputs = self.tokenizer(
                user_prompt,
                padding="max_length",
                max_length=self.tokenizer.model_max_length,
                truncation=True,
                return_tensors="pt",
            )
            text_input_ids = text_inputs.input_ids
            untruncated_ids = self.tokenizer(user_prompt, padding="longest", return_tensors="pt").input_ids

            if untruncated_ids.shape[-1] >= text_input_ids.shape[-1] and not torch.equal(
                text_input_ids, untruncated_ids
            ):
                removed_text = self.tokenizer.batch_decode(
                    untruncated_ids[:, self.tokenizer.model_max_length - 1 : -1]
                )
                logger.warning(
                    "The following part of your input was truncated because CLIP can only handle sequences up to"
                    f" {self.tokenizer.model_max_length} tokens: {removed_text}"
                )

            if hasattr(self.text_encoder.config, "use_attention_mask") and self.text_encoder.config.use_attention_mask:
                attention_mask = text_inputs.attention_mask.to(target_device)
            else:
                attention_mask = None

            if clip_skip is None:
                user_prompt_embeddings = self.text_encoder(text_input_ids.to(target_device), attention_mask=attention_mask)
                user_prompt_embeddings = user_prompt_embeddings[0]
            else:
                user_prompt_embeddings = self.text_encoder(
                    text_input_ids.to(target_device), attention_mask=attention_mask, output_hidden_states=True
                )
                # Access the `hidden_states` first, that contains a tuple of
              
                user_prompt_embeddings = user_prompt_embeddings[-1][-(clip_skip + 1)]
               
                user_prompt_embeddings = self.text_encoder.text_model.final_layer_norm(user_prompt_embeddings)

        if self.text_encoder is not None:
            text_embed_dtype = self.text_encoder.dtype
        elif self.unet is not None:
            text_embed_dtype = self.unet.dtype
        else:
            text_embed_dtype = user_prompt_embeddings.dtype

        user_prompt_embeddings = user_prompt_embeddings.to(dtype=text_embed_dtype, device=target_device)

        bs_embed, seq_len, _ = user_prompt_embeddings.shape
        user_prompt_embeddings = user_prompt_embeddings.repeat(1, images_per_prompt, 1)
        user_prompt_embeddings = user_prompt_embeddings.view(bs_embed * images_per_prompt, seq_len, -1)

        if enable_classifier_free_guidance and negative_user_prompt_embeddings is None:
            uncond_tokens: List[str]
            if negative_user_prompt is None:
                uncond_tokens = [""] * batch_size
            elif user_prompt is not None and type(user_prompt) is not type(negative_user_prompt):
                raise TypeError(
                    f"`negative_user_prompt` should be the same type as `user_prompt`, but got {type(negative_user_prompt)}"
                    f" != {type(user_prompt)}."
                )
            elif isinstance(negative_user_prompt, str):
                uncond_tokens = [negative_user_prompt]
            elif batch_size != len(negative_user_prompt):
                raise ValueError(
                    f"`negative_user_prompt`: {negative_user_prompt} has batch size {len(negative_user_prompt)}, but"
                    f" `user_prompt`: {user_prompt} has batch size {batch_size}. Please make sure that the passed"
                    " `negative_user_prompt` matches the batch size of `user_prompt`."
                )
            else:
                uncond_tokens = negative_user_prompt

            # textual inversion: process multi-vector tokens if necessary
            if isinstance(self, TextualInversionLoaderMixin):
                uncond_tokens = self.maybe_convert_prompt(uncond_tokens, self.tokenizer)

            max_length = user_prompt_embeddings.shape[1]
            uncond_input = self.tokenizer(
                uncond_tokens,
                padding="max_length",
                max_length=max_length,
                truncation=True,
                return_tensors="pt",
            )

            if hasattr(self.text_encoder.config, "use_attention_mask") and self.text_encoder.config.use_attention_mask:
                attention_mask = uncond_input.attention_mask.to(target_device)
            else:
                attention_mask = None

            negative_user_prompt_embeddings = self.text_encoder(
                uncond_input.input_ids.to(target_device),
                attention_mask=attention_mask,
            )
            negative_user_prompt_embeddings = negative_user_prompt_embeddings[0]

        if enable_classifier_free_guidance:
            # duplicate unconditional embeddings for each generation per prompt, using MPS-friendly method
            seq_len = negative_user_prompt_embeddings.shape[1]

            negative_user_prompt_embeddings = negative_user_prompt_embeddings.to(dtype=text_embed_dtype, device=target_device)

            negative_user_prompt_embeddings = negative_user_prompt_embeddings.repeat(1, images_per_prompt, 1)
            negative_user_prompt_embeddings = negative_user_prompt_embeddings.view(batch_size * images_per_prompt, seq_len, -1)

        if isinstance(self, LoraLoaderMixin) and USE_PEFT_BACKEND:
            # Retrieve the original scale by scaling back the LoRA layers
            unscale_lora_layers(self.text_encoder, lora_scale)

        return user_prompt_embeddings, negative_user_prompt_embeddings



    def perform_safety_check(self, input_image, target_device, data_type):
        if self.safety_checker is None:
            has_nsfw_concept = None
        else:
            if torch.is_tensor(input_image):
                feature_extractor_input = self.image_processor.postprocess(input_image, output_type="pil")
            else:
                feature_extractor_input = self.image_processor.numpy_to_pil(input_image)
            safety_checker_input = self.feature_extractor(feature_extractor_input, return_tensors="pt").to(target_device)
            input_image, has_nsfw_concept = self.safety_checker(
                images=input_image, clip_input=safety_checker_input.pixel_values.to(data_type)
            )
        return input_image, has_nsfw_concept


    def prepare_additional_step_arguments(self, generator, eta):
     
        accepts_eta = "eta" in set(inspect.signature(self.scheduler.step).parameters.keys())
        additional_step_arguments = {}
        if accepts_eta:
            additional_step_arguments["eta"] = eta

        # check if the scheduler accepts generator
        accepts_generator = "generator" in set(inspect.signature(self.scheduler.step).parameters.keys())
        if accepts_generator:
            additional_step_arguments["generator"] = generator
        return additional_step_arguments
   
    def validate_inputs(
            self,
            user_prompt,
            target_height,
            target_width,
            perturbation_strength,
            num_callback_steps,
            user_negative_prompt=None,
            prompt_embeddings=None,
            negative_prompt_embeddings=None,
            callback_tensor_inputs=None,
        ):
        if perturbation_strength < 0 or perturbation_strength > 1:
            raise ValueError(f"The value of perturbation_strength should be in [0.0, 1.0] but is {perturbation_strength}")

        if target_height % self.vae_scale_factor != 0 or target_width % self.vae_scale_factor != 0:
            raise ValueError(f"`target_height` and `target_width` have to be divisible by 8 but are {target_height} and {target_width}.")

        if num_callback_steps is not None and (not isinstance(num_callback_steps, int) or num_callback_steps <= 0):
            raise ValueError(
                f"`num_callback_steps` has to be a positive integer but is {num_callback_steps} of type"
                f" {type(num_callback_steps)}."
            )

        if callback_tensor_inputs is not None and not all(
            k in self._callback_tensor_inputs for k in callback_tensor_inputs
        ):
            raise ValueError(
                f"`callback_tensor_inputs` has to be in {self._callback_tensor_inputs}, but found {[k for k in callback_tensor_inputs if k not in self._callback_tensor_inputs]}"
            )

        if user_prompt is not None and prompt_embeddings is not None:
            raise ValueError(
                f"Cannot provide both `user_prompt`: {user_prompt} and `prompt_embeddings`: {prompt_embeddings}. Please ensure to"
                " provide only one of the two."
            )
        elif user_prompt is None and prompt_embeddings is None:
            raise ValueError(
                "Provide either `user_prompt` or `prompt_embeddings`. Cannot leave both `user_prompt` and `prompt_embeddings` undefined."
            )
        elif user_prompt is not None and (not isinstance(user_prompt, str) and not isinstance(user_prompt, list)):
            raise ValueError(f"`user_prompt` has to be of type `str` or `list` but is {type(user_prompt)}")

        if user_negative_prompt is not None and negative_prompt_embeddings is not None:
            raise ValueError(
                f"Cannot provide both `user_negative_prompt`: {user_negative_prompt} and `negative_prompt_embeddings`:"
                f" {negative_prompt_embeddings}. Please ensure to provide only one of the two."
            )

        if prompt_embeddings is not None and negative_prompt_embeddings is not None:
            if prompt_embeddings.shape != negative_prompt_embeddings.shape:
                raise ValueError(
                    "`prompt_embeddings` and `negative_prompt_embeddings` must have the same shape when provided directly, but"
                    f" got: `prompt_embeddings` {prompt_embeddings.shape} != `negative_prompt_embeddings`"
                    f" {negative_prompt_embeddings.shape}."
                )





    def prepare_latent_vectors(
            self,
            effective_batch_size,
            num_latent_channels,
            target_height,
            target_width,
            data_type,
            target_device,
            generators,
            initial_latents=None,
            target_image=None,
            time_step=None,
            is_max_strength=True,
            include_noise=False,
            include_image_latents=False,
        ):
        shape = (effective_batch_size, num_latent_channels, target_height // self.vae_scale_factor, target_width // self.vae_scale_factor)
        if isinstance(generators, list) and len(generators) != effective_batch_size:
            raise ValueError(
                f"You have provided a list of generators with a length of {len(generators)}, but the requested effective batch"
                f" size is {effective_batch_size}. Ensure that the batch size matches the length of the generators."
            )

        if (target_image is None or time_step is None) and not is_max_strength:
            raise ValueError(
                "When strength < 1, initial latents should be initialized as a combination of Image + Noise."
                " However, either the image or the noise timestep has not been provided."
            )

        if include_image_latents or (initial_latents is None and not is_max_strength):
            target_image = target_image.to(device=target_device, dtype=data_type)

            if target_image.shape[1] == 4:
                image_latents = target_image
            else:
                image_latents = self._encode_vae_image(image=target_image, generator=generators)
            image_latents = image_latents.repeat(effective_batch_size // image_latents.shape[0], 1, 1, 1)

        if initial_latents is None:
            noise = randn_tensor(shape, generator=generators, device=target_device, dtype=data_type)
            # if strength is 1, then initialize the latents to noise, else initialize to image + noise
            initial_latents = noise if is_max_strength else self.scheduler.add_noise(image_latents, noise, time_step)
            # if pure noise, then scale the initial latents by the Scheduler's init sigma
            initial_latents = initial_latents * self.scheduler.init_noise_sigma if is_max_strength else initial_latents
        else:
            noise = initial_latents.to(device=target_device)
            initial_latents = noise * self.scheduler.init_noise_sigma

        outputs = (initial_latents,)

        if include_noise:
            outputs += (noise,)

        if include_image_latents:
            outputs += (image_latents,)

        return outputs


  


  
    def encode_image_latents(self, input_image: torch.Tensor, generators: torch.Generator):
        if isinstance(generators, list):
            image_latents = [
                get_latent_representation(self.vae.encode(input_image[i : i + 1]), generator=generators[i])
                for i in range(input_image.shape[0])
            ]
            image_latents = torch.cat(image_latents, dim=0)
        else:
            image_latents = get_latent_representation(self.vae.encode(input_image), generator=generators)

        image_latents = self.vae.config.scaling_factor * image_latents

        return image_latents

    def prepare_latent_mask(
        self, mask, masked_input_image, effective_batch_size, target_height, target_width, data_type, target_device, generators, use_classifier_free_guidance
    ):
     
        mask = torch.nn.functional.interpolate(
            mask, size=(target_height // self.vae_scale_factor, target_width // self.vae_scale_factor)
        )
        mask = mask.to(device=target_device, dtype=data_type)

        masked_input_image = masked_input_image.to(device=target_device, dtype=data_type)

        if masked_input_image.shape[1] == 4:
            masked_input_image_latents = masked_input_image
        else:
            masked_input_image_latents = self.encode_image_latents(masked_input_image, generators)

        if mask.shape[0] < effective_batch_size:
            if not effective_batch_size % mask.shape[0] == 0:
                raise ValueError(
                    "The provided mask and the required batch size do not match. Masks are supposed to be duplicated to"
                    f" a total batch size of {effective_batch_size}, but {mask.shape[0]} masks were provided. Make sure the number"
                    " of masks you pass is divisible by the total requested batch size."
                )
            mask = mask.repeat(effective_batch_size // mask.shape[0], 1, 1, 1)
        if masked_input_image_latents.shape[0] < effective_batch_size:
            if not effective_batch_size % masked_input_image_latents.shape[0] == 0:
                raise ValueError(
                    "The provided images and the required batch size do not match. Images are supposed to be duplicated"
                    f" to a total batch size of {effective_batch_size}, but {masked_input_image_latents.shape[0]} images were provided."
                    " Make sure the number of images you pass is divisible by the total requested batch size."
                )
            masked_input_image_latents = masked_input_image_latents.repeat(effective_batch_size // masked_input_image_latents.shape[0], 1, 1, 1)

        mask = torch.cat([mask] * 2) if use_classifier_free_guidance else mask
        masked_input_image_latents = (
            torch.cat([masked_input_image_latents] * 2) if use_classifier_free_guidance else masked_input_image_latents
        )

        masked_input_image_latents = masked_input_image_latents.to(device=target_device, dtype=data_type)
        return mask, masked_input_image_latents





    def obtain_timesteps(self, num_inference_steps, strength, target_device):
        # Calculate the original timestep using init_timestep
        init_timestep = min(int(num_inference_steps * strength), num_inference_steps)

        t_start = max(num_inference_steps - init_timestep, 0)
        obtained_timesteps = self.scheduler.timesteps[t_start * self.scheduler.order :]

        return obtained_timesteps, num_inference_steps - t_start

    def activate_freeu_mechanism(self, scaling_factor_1: float, scaling_factor_2: float, backbone_factor_1: float, backbone_factor_2: float):
     
        if not hasattr(self, "unet"):
            raise ValueError("The pipeline must have `unet` for using FreeU.")
        self.unet.activate_freeu(s1=scaling_factor_1, s2=scaling_factor_2, b1=backbone_factor_1, b2=backbone_factor_2)

    def deactivate_freeu_mechanism(self):
        """Deactivates the FreeU mechanism if enabled."""
        self.unet.deactivate_freeu()


   
  

    def generate_embedding_scale_guidance(self, guidance_weight, embedding_dim=512, dtype=torch.float32):
       
        assert len(guidance_weight.shape) == 1
        guidance_weight = guidance_weight * 1000.0

        half_dim = embedding_dim // 2
        embedding_values = torch.log(torch.tensor(10000.0)) / (half_dim - 1)
        embedding_values = torch.exp(torch.arange(half_dim, dtype=dtype) * -embedding_values)
        embeddings = guidance_weight.to(dtype)[:, None] * embedding_values[None, :]
        embeddings = torch.cat([torch.sin(embeddings), torch.cos(embeddings)], dim=1)
        if embedding_dim % 2 == 1:  # zero pad
            embeddings = torch.nn.functional.pad(embeddings, (0, 1))
        assert embeddings.shape == (guidance_weight.shape[0], embedding_dim)
        return embeddings

    @property
    def scale_of_guidance(self):
        return self._guidance_scale

    @property
    def skip_clip(self):
        return self._clip_skip

    @property
    def is_classifier_free_guidance_enabled(self):
        return self._guidance_scale > 1 and self.unet.config.time_cond_proj_dim is None

    @property
    def cross_attention_parameters(self):
        return self._cross_attention_kwargs

    @property
    def number_of_timesteps(self):
        return self._num_timesteps

    @torch.no_grad()
    def __call__(
        self,
        prompt: Union[str, List[str]] = None,
        image: PipelineImageInput = None,
        mask_image: PipelineImageInput = None,
        masked_image_latents: torch.FloatTensor = None,
        height: Optional[int] = None,
        width: Optional[int] = None,
        strength: float = 1.0,
        num_inference_steps: int = 50,
        guidance_scale: float = 7.5,
        negative_prompt: Optional[Union[str, List[str]]] = None,
        num_images_per_prompt: Optional[int] = 1,
        eta: float = 0.0,
        generator: Optional[Union[torch.Generator, List[torch.Generator]]] = None,
        latents: Optional[torch.FloatTensor] = None,
        prompt_embeds: Optional[torch.FloatTensor] = None,
        negative_prompt_embeds: Optional[torch.FloatTensor] = None,
        output_type: Optional[str] = "pil",
        return_dict: bool = True,
        cross_attention_kwargs: Optional[Dict[str, Any]] = None,
        clip_skip: int = None,
        callback_on_step_end: Optional[Callable[[int, int, Dict], None]] = None,
        callback_on_step_end_tensor_inputs: List[str] = ["latents"],
        **kwargs,
    ):
      
        callback = kwargs.pop("callback", None)
        callback_steps = kwargs.pop("callback_steps", None)

        if callback is not None:
            deprecate(
                "callback",
                "1.0.0",
                "Passing `callback` as an input argument to `__call__` is deprecated, consider use `callback_on_step_end`",
            )
        if callback_steps is not None:
            deprecate(
                "callback_steps",
                "1.0.0",
                "Passing `callback_steps` as an input argument to `__call__` is deprecated, consider use `callback_on_step_end`",
            )

        # 0. Default height and width to unet
        height = height or self.unet.config.sample_size * self.vae_scale_factor
        width = width or self.unet.config.sample_size * self.vae_scale_factor

        # 1. Check inputs
        self.validate_inputs(
            prompt,
            height,
            width,
            strength,
            callback_steps,
            negative_prompt,
            prompt_embeds,
            negative_prompt_embeds,
            callback_on_step_end_tensor_inputs,
        )

        self._guidance_scale = guidance_scale
        self._clip_skip = clip_skip
        self._cross_attention_kwargs = cross_attention_kwargs

        # 2. Define call parameters
        if prompt is not None and isinstance(prompt, str):
            batch_size = 1
        elif prompt is not None and isinstance(prompt, list):
            batch_size = len(prompt)
        else:
            batch_size = prompt_embeds.shape[0]

        device = self._execution_device

        # 3. Encode input prompt
        text_encoder_lora_scale = (
            cross_attention_kwargs.get("scale", None) if cross_attention_kwargs is not None else None
        )
        prompt_embeds, negative_prompt_embeds = self.generate_text_embeddings(
            prompt,
            device,
            num_images_per_prompt,
            self.do_classifier_free_guidance,
            negative_prompt,
            prompt_embeds=prompt_embeds,
            negative_prompt_embeds=negative_prompt_embeds,
            lora_scale=text_encoder_lora_scale,
            clip_skip=self.clip_skip,
        )
       
        if self.do_classifier_free_guidance:
            prompt_embeds = torch.cat([negative_prompt_embeds, prompt_embeds])

        # 4. set timesteps
        self.scheduler.set_timesteps(num_inference_steps, device=device)
        timesteps, num_inference_steps = self.get_timesteps(
            num_inference_steps=num_inference_steps, strength=strength, device=device
        )
        # check that number of inference steps is not < 1 - as this doesn't make sense
        if num_inference_steps < 1:
            raise ValueError(
                f"After adjusting the num_inference_steps by strength parameter: {strength}, the number of pipeline"
                f"steps is {num_inference_steps} which is < 1 and not appropriate for this pipeline."
            )
        # at which timestep to set the initial noise (n.b. 50% if strength is 0.5)
        latent_timestep = timesteps[:1].repeat(batch_size * num_images_per_prompt)
        # create a boolean to check if the strength is set to 1. if so then initialise the latents with pure noise
        is_strength_max = strength == 1.0

        # 5. Preprocess mask and image

        init_image = self.image_processor.preprocess(image, height=height, width=width)
        init_image = init_image.to(dtype=torch.float32)

        # 6. Prepare latent variables
        num_channels_latents = self.vae.config.latent_channels
        num_channels_unet = self.unet.config.in_channels
        return_image_latents = num_channels_unet == 4

        latents_outputs = self.prepare_latents(
            batch_size * num_images_per_prompt,
            num_channels_latents,
            height,
            width,
            prompt_embeds.dtype,
            device,
            generator,
            latents,
            image=init_image,
            timestep=latent_timestep,
            is_strength_max=is_strength_max,
            return_noise=True,
            return_image_latents=return_image_latents,
        )

        if return_image_latents:
            latents, noise, image_latents = latents_outputs
        else:
            latents, noise = latents_outputs

        # 7. Prepare mask latent variables
        mask_condition = self.mask_processor.preprocess(mask_image, height=height, width=width)

        if masked_image_latents is None:
            masked_image = init_image * (mask_condition < 0.5)
        else:
            masked_image = masked_image_latents

        mask, masked_image_latents = self.prepare_mask_latents(
            mask_condition,
            masked_image,
            batch_size * num_images_per_prompt,
            height,
            width,
            prompt_embeds.dtype,
            device,
            generator,
            self.do_classifier_free_guidance,
        )

        # 8. Check that sizes of mask, masked image and latents match
        if num_channels_unet == 9:
            # default case for runwayml/stable-diffusion-inpainting
            num_channels_mask = mask.shape[1]
            num_channels_masked_image = masked_image_latents.shape[1]
            if num_channels_latents + num_channels_mask + num_channels_masked_image != self.unet.config.in_channels:
                raise ValueError(
                    f"Incorrect configuration settings! The config of `pipeline.unet`: {self.unet.config} expects"
                    f" {self.unet.config.in_channels} but received `num_channels_latents`: {num_channels_latents} +"
                    f" `num_channels_mask`: {num_channels_mask} + `num_channels_masked_image`: {num_channels_masked_image}"
                    f" = {num_channels_latents+num_channels_masked_image+num_channels_mask}. Please verify the config of"
                    " `pipeline.unet` or your `mask_image` or `image` input."
                )
        elif num_channels_unet != 4:
            raise ValueError(
                f"The unet {self.unet.__class__} should have either 4 or 9 input channels, not {self.unet.config.in_channels}."
            )

        # 9. Prepare extra step kwargs. TODO: Logic should ideally just be moved out of the pipeline
        extra_step_kwargs = self.prepare_additional_step_arguments(generator, eta)

        # 9.5 Optionally get Guidance Scale Embedding
        timestep_cond = None
        if self.unet.config.time_cond_proj_dim is not None:
            guidance_scale_tensor = torch.tensor(self.guidance_scale - 1).repeat(batch_size * num_images_per_prompt)
            timestep_cond = self.get_guidance_scale_embedding(
                guidance_scale_tensor, embedding_dim=self.unet.config.time_cond_proj_dim
            ).to(device=device, dtype=latents.dtype)

        # 10. Denoising loop
        num_warmup_steps = len(timesteps) - num_inference_steps * self.scheduler.order
        self._num_timesteps = len(timesteps)
        with self.progress_bar(total=num_inference_steps) as progress_bar:
            for i, t in enumerate(timesteps):
                # expand the latents if we are doing classifier free guidance
                latent_model_input = torch.cat([latents] * 2) if self.do_classifier_free_guidance else latents

                # concat latents, mask, masked_image_latents in the channel dimension
                latent_model_input = self.scheduler.scale_model_input(latent_model_input, t)

                if num_channels_unet == 9:
                    latent_model_input = torch.cat([latent_model_input, mask, masked_image_latents], dim=1)

                # predict the noise residual
                noise_pred = self.unet(
                    latent_model_input,
                    t,
                    encoder_hidden_states=prompt_embeds,
                    timestep_cond=timestep_cond,
                    cross_attention_kwargs=self.cross_attention_kwargs,
                    return_dict=False,
                )[0]

                # perform guidance
                if self.do_classifier_free_guidance:
                    noise_pred_uncond, noise_pred_text = noise_pred.chunk(2)
                    noise_pred = noise_pred_uncond + self.guidance_scale * (noise_pred_text - noise_pred_uncond)

                # compute the previous noisy sample x_t -> x_t-1
                latents = self.scheduler.step(noise_pred, t, latents, **extra_step_kwargs, return_dict=False)[0]
                if num_channels_unet == 4:
                    init_latents_proper = image_latents
                    if self.do_classifier_free_guidance:
                        init_mask, _ = mask.chunk(2)
                    else:
                        init_mask = mask

                    if i < len(timesteps) - 1:
                        noise_timestep = timesteps[i + 1]
                        init_latents_proper = self.scheduler.add_noise(
                            init_latents_proper, noise, torch.tensor([noise_timestep])
                        )

                    latents = (1 - init_mask) * init_latents_proper + init_mask * latents

                if callback_on_step_end is not None:
                    callback_kwargs = {}
                    for k in callback_on_step_end_tensor_inputs:
                        callback_kwargs[k] = locals()[k]
                    callback_outputs = callback_on_step_end(self, i, t, callback_kwargs)

                    latents = callback_outputs.pop("latents", latents)
                    prompt_embeds = callback_outputs.pop("prompt_embeds", prompt_embeds)
                    negative_prompt_embeds = callback_outputs.pop("negative_prompt_embeds", negative_prompt_embeds)
                    mask = callback_outputs.pop("mask", mask)
                    masked_image_latents = callback_outputs.pop("masked_image_latents", masked_image_latents)

                # call the callback, if provided
                if i == len(timesteps) - 1 or ((i + 1) > num_warmup_steps and (i + 1) % self.scheduler.order == 0):
                    progress_bar.update()
                    if callback is not None and i % callback_steps == 0:
                        step_idx = i // getattr(self.scheduler, "order", 1)
                        callback(step_idx, t, latents)

        if not output_type == "latent":
            condition_kwargs = {}
            if isinstance(self.vae, AsymmetricAutoencoderKL):
                init_image = init_image.to(device=device, dtype=masked_image_latents.dtype)
                init_image_condition = init_image.clone()
                init_image = self._encode_vae_image(init_image, generator=generator)
                mask_condition = mask_condition.to(device=device, dtype=masked_image_latents.dtype)
                condition_kwargs = {"image": init_image_condition, "mask": mask_condition}
            image = self.vae.decode(
                latents / self.vae.config.scaling_factor, return_dict=False, generator=generator, **condition_kwargs
            )[0]
            image, has_nsfw_concept = self.perform_safety_check(image, device, prompt_embeds.dtype)
        else:
            image = latents
            has_nsfw_concept = None

        if has_nsfw_concept is None:
            do_denormalize = [True] * image.shape[0]
        else:
            do_denormalize = [not has_nsfw for has_nsfw in has_nsfw_concept]

        image = self.image_processor.postprocess(image, output_type=output_type, do_denormalize=do_denormalize)

        # Offload all models
        self.maybe_free_model_hooks()

        if not return_dict:
            return (image, has_nsfw_concept)

        return StableVictorPipelineOutput(images=image, nsfw_content_detected=has_nsfw_concept)






