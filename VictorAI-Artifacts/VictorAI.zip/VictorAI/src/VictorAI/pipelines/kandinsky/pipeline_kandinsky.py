from typing import Callable, List, Optional, Union
import torch
from transformers import (XLMRobertaTokenizer)
from ...models import UNet2DConditionModel, VQModel
from ...schedulers import DDIMScheduler, DDPMScheduler
from ...utils import (logging)
from ...utils.torch_utils import randn_tensor
from ..pipeline_utils import VictorPipeline, ImagePipelineOutput
from .text_encoder import MultilingualCLIP


logger = logging.get_logger(__name__)



def get_new_h_w_revised(input_height, input_width, factor_of_scale=8):
    new_height = input_height // factor_of_scale**2
    if input_height % factor_of_scale**2 != 0:
        new_height += 1
    new_width = input_width // factor_of_scale**2
    if input_width % factor_of_scale**2 != 0:
        new_width += 1
    return new_height * factor_of_scale, new_width * factor_of_scale

class KandinskyPipeline(VictorPipeline):
 

    model_cpu_offload_seq = "text_encoder->unet->movq"

    def __init__(
        self,
        text_encoder: MultilingualCLIP,
        tokenizer: XLMRobertaTokenizer,
        unet: UNet2DConditionModel,
        scheduler: Union[DDIMScheduler, DDPMScheduler],
        movq: VQModel,
    ):
        super().__init__()

        self.register_modules(
            text_encoder=text_encoder,
            tokenizer=tokenizer,
            unet=unet,
            scheduler=scheduler,
            movq=movq,
        )
        self.movq_scale_factor = 2 ** (len(self.movq.config.block_out_channels) - 1)


    def prepare_latents(self, target_shape, target_dtype, target_device, target_generator, input_latents, noise_scheduler):
        if input_latents is None:
            input_latents = randn_tensor(target_shape, generator=target_generator, device=target_device, dtype=target_dtype)
        else:
            if input_latents.shape != target_shape:
                raise ValueError(f"Unexpected latents shape, got {input_latents.shape}, expected {target_shape}")
            input_latents = input_latents.to(target_device)

        input_latents = input_latents * noise_scheduler.init_noise_sigma
        return input_latents

    def _encode_prompt(
        self,
        custom_input,
        target_device,
        num_samples_per_input,
        use_classifier_free_guidance,
        custom_negative_input=None,
    ):
        batch_size = len(custom_input) if isinstance(custom_input, list) else 1
        # Get text embeddings from the input
        text_inputs = self.tokenizer(
            custom_input,
            padding="max_length",
            truncation=True,
            max_length=77,
            return_attention_mask=True,
            add_special_tokens=True,
            return_tensors="pt",
        )

        text_input_ids = text_inputs.input_ids
        untruncated_ids = self.tokenizer(custom_input, padding="longest", return_tensors="pt").input_ids

        if untruncated_ids.shape[-1] >= text_input_ids.shape[-1] and not torch.equal(text_input_ids, untruncated_ids):
            removed_text = self.tokenizer.batch_decode(untruncated_ids[:, self.tokenizer.model_max_length - 1 : -1])
            logger.warning(
                "The following part of your input was truncated because CLIP can only handle sequences up to"
                f" {self.tokenizer.model_max_length} tokens: {removed_text}"
            )

        text_input_ids = text_input_ids.to(target_device)
        text_mask = text_inputs.attention_mask.to(target_device)

        prompt_embeds, text_encoder_hidden_states = self.text_encoder(
            input_ids=text_input_ids, attention_mask=text_mask
        )

        prompt_embeds = prompt_embeds.repeat_interleave(num_samples_per_input, dim=0)
        text_encoder_hidden_states = text_encoder_hidden_states.repeat_interleave(num_samples_per_input, dim=0)
        text_mask = text_mask.repeat_interleave(num_samples_per_input, dim=0)

        if use_classifier_free_guidance:
            additional_input_tokens: List[str]
            if custom_negative_input is None:
                additional_input_tokens = [""] * batch_size
            elif type(custom_input) is not type(custom_negative_input):
                raise TypeError(
                    f"`custom_negative_input` should be the same type as `custom_input`, but got {type(custom_negative_input)} !="
                    f" {type(custom_input)}."
                )
            elif isinstance(custom_negative_input, str):
                additional_input_tokens = [custom_negative_input]
            elif batch_size != len(custom_negative_input):
                raise ValueError(
                    f"`custom_negative_input`: {custom_negative_input} has batch size {len(custom_negative_input)}, but `custom_input`:"
                    f" {custom_input} has batch size {batch_size}. Please make sure that passed `custom_negative_input` matches"
                    " the batch size of `custom_input`."
                )
            else:
                additional_input_tokens = custom_negative_input

            additional_input = self.tokenizer(
                additional_input_tokens,
                padding="max_length",
                max_length=77,
                truncation=True,
                return_attention_mask=True,
                add_special_tokens=True,
                return_tensors="pt",
            )
            additional_text_input_ids = additional_input.input_ids.to(target_device)
            additional_text_mask = additional_input.attention_mask.to(target_device)

            negative_prompt_embeds, additional_text_encoder_hidden_states = self.text_encoder(
                input_ids=additional_text_input_ids, attention_mask=additional_text_mask
            )


            seq_len = negative_prompt_embeds.shape[1]
            negative_prompt_embeds = negative_prompt_embeds.repeat(1, num_samples_per_input)
            negative_prompt_embeds = negative_prompt_embeds.view(batch_size * num_samples_per_input, seq_len)

            seq_len = additional_text_encoder_hidden_states.shape[1]
            additional_text_encoder_hidden_states = additional_text_encoder_hidden_states.repeat(
                1, num_samples_per_input, 1
            )
            additional_text_encoder_hidden_states = additional_text_encoder_hidden_states.view(
                batch_size * num_samples_per_input, seq_len, -1
            )
            additional_text_mask = additional_text_mask.repeat_interleave(num_samples_per_input, dim=0)

            prompt_embeds = torch.cat([negative_prompt_embeds, prompt_embeds])
            text_encoder_hidden_states = torch.cat([additional_text_encoder_hidden_states, text_encoder_hidden_states])

            text_mask = torch.cat([additional_text_mask, text_mask])

        return prompt_embeds, text_encoder_hidden_states, text_mask


    @torch.no_grad()
    
    def __call__(
        self,
        prompt: Union[str, List[str]],
        image_embeds: Union[torch.FloatTensor, List[torch.FloatTensor]],
        negative_image_embeds: Union[torch.FloatTensor, List[torch.FloatTensor]],
        negative_prompt: Optional[Union[str, List[str]]] = None,
        height: int = 512,
        width: int = 512,
        num_inference_steps: int = 100,
        guidance_scale: float = 4.0,
        num_images_per_prompt: int = 1,
        generator: Optional[Union[torch.Generator, List[torch.Generator]]] = None,
        latents: Optional[torch.FloatTensor] = None,
        output_type: Optional[str] = "pil",
        callback: Optional[Callable[[int, int, torch.FloatTensor], None]] = None,
        callback_steps: int = 1,
        return_dict: bool = True,
    ):
       
        if isinstance(prompt, str):
            batch_size = 1
        elif isinstance(prompt, list):
            batch_size = len(prompt)
        else:
            raise ValueError(f"`prompt` has to be of type `str` or `list` but is {type(prompt)}")

        device = self._execution_device

        batch_size = batch_size * num_images_per_prompt
        do_classifier_free_guidance = guidance_scale > 1.0

        prompt_embeds, text_encoder_hidden_states, _ = self._encode_prompt(
            prompt, device, num_images_per_prompt, do_classifier_free_guidance, negative_prompt
        )

        if isinstance(image_embeds, list):
            image_embeds = torch.cat(image_embeds, dim=0)
        if isinstance(negative_image_embeds, list):
            negative_image_embeds = torch.cat(negative_image_embeds, dim=0)

        if do_classifier_free_guidance:
            image_embeds = image_embeds.repeat_interleave(num_images_per_prompt, dim=0)
            negative_image_embeds = negative_image_embeds.repeat_interleave(num_images_per_prompt, dim=0)

            image_embeds = torch.cat([negative_image_embeds, image_embeds], dim=0).to(
                dtype=prompt_embeds.dtype, device=device
            )

        self.scheduler.set_timesteps(num_inference_steps, device=device)
        timesteps_tensor = self.scheduler.timesteps

        num_channels_latents = self.unet.config.in_channels

        height, width = get_new_h_w(height, width, self.movq_scale_factor)

        # create initial latent
        latents = self.prepare_latents(
            (batch_size, num_channels_latents, height, width),
            text_encoder_hidden_states.dtype,
            device,
            generator,
            latents,
            self.scheduler,
        )

        for i, t in enumerate(self.progress_bar(timesteps_tensor)):
            # expand the latents if we are doing classifier free guidance
            latent_model_input = torch.cat([latents] * 2) if do_classifier_free_guidance else latents

            added_cond_kwargs = {"text_embeds": prompt_embeds, "image_embeds": image_embeds}
            noise_pred = self.unet(
                sample=latent_model_input,
                timestep=t,
                encoder_hidden_states=text_encoder_hidden_states,
                added_cond_kwargs=added_cond_kwargs,
                return_dict=False,
            )[0]

            if do_classifier_free_guidance:
                noise_pred, variance_pred = noise_pred.split(latents.shape[1], dim=1)
                noise_pred_uncond, noise_pred_text = noise_pred.chunk(2)
                _, variance_pred_text = variance_pred.chunk(2)
                noise_pred = noise_pred_uncond + guidance_scale * (noise_pred_text - noise_pred_uncond)
                noise_pred = torch.cat([noise_pred, variance_pred_text], dim=1)

            if not (
                hasattr(self.scheduler.config, "variance_type")
                and self.scheduler.config.variance_type in ["learned", "learned_range"]
            ):
                noise_pred, _ = noise_pred.split(latents.shape[1], dim=1)

            # compute the previous noisy sample x_t -> x_t-1
            latents = self.scheduler.step(
                noise_pred,
                t,
                latents,
                generator=generator,
            ).prev_sample

            if callback is not None and i % callback_steps == 0:
                step_idx = i // getattr(self.scheduler, "order", 1)
                callback(step_idx, t, latents)

        # post-processing
        image = self.movq.decode(latents, force_not_quantize=True)["sample"]

        self.maybe_free_model_hooks()

        if output_type not in ["pt", "np", "pil"]:
            raise ValueError(f"Only the output types `pt`, `pil` and `np` are supported not output_type={output_type}")

        if output_type in ["np", "pil"]:
            image = image * 0.5 + 0.5
            image = image.clamp(0, 1)
            image = image.cpu().permute(0, 2, 3, 1).float().numpy()

        if output_type == "pil":
            image = self.numpy_to_pil(image)

        if not return_dict:
            return (image,)

        return ImagePipelineOutput(images=image)
