import torch
from transformers import PreTrainedModel, XLMRobertaConfig, XLMRobertaModel

class MCLIPConfig(XLMRobertaConfig):
    model_type = "M-CLIP"

    def __init__(self, transformer_dim_size=1024, image_dim_size=768, **custom_kwargs):
        self.transformer_dimensions = transformer_dim_size
        self.num_dims = image_dim_size
        super().__init__(**custom_kwargs)



class MultilingualCLIP(PreTrainedModel):
    config_class = MCLIPConfig



    def __init__(self, model_configuration, *args, **kwargs):
            super().__init__(model_configuration, *args, **kwargs)
            self.transformer = XLMRobertaModel(model_configuration)
            self.linear_transformation = torch.nn.Linear(
                in_features=model_configuration.transformer_dimensions, out_features=model_configuration.num_dimensions
            )

    def forward(self, input_identifiers, mask_attention):
            embeddings = self.transformer(input_ids=input_identifiers, attention_mask=mask_attention)[0]
            weighted_embeddings = (embeddings * mask_attention.unsqueeze(2)).sum(dim=1) / mask_attention.sum(dim=1)[:, None]
            return self.linear_transformation(weighted_embeddings), embeddings
