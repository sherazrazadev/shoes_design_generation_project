from typing import Callable, List, Optional, Union
import numpy as np
import PIL.Image
import torch
from PIL import Image
from transformers import (
    XLMRobertaTokenizer,
)

from ...models import UNet2DConditionModel, VQModel
from ...schedulers import DDIMScheduler
from ...utils import (
    logging,
    
)
from ...utils.torch_utils import randn_tensor
from ..pipeline_utils import VictorPipeline, ImagePipelineOutput
from .text_encoder import MultilingualCLIP


logger = logging.get_logger(__name__) 



def get_new_h_w(original_height, original_width, scaling_factor=8):
    new_height = original_height // scaling_factor**2
    if original_height % scaling_factor**2 != 0:
        new_height += 1
    new_width = original_width // scaling_factor**2
    if original_width % scaling_factor**2 != 0:
        new_width += 1
    return new_height * scaling_factor, new_width * scaling_factor





def prepare_image(input_pil_image, new_width=512, new_height=512):
    resized_pil_image = input_pil_image.resize((new_width, new_height), resample=Image.BICUBIC, reducing_gap=1)
    image_array = np.array(resized_pil_image.convert("RGB"))
    image_array = image_array.astype(np.float32) / 127.5 - 1
    image_array = np.transpose(image_array, [2, 0, 1])
    torch_image = torch.from_numpy(image_array).unsqueeze(0)
    return torch_image



class KandinskyImg2ImgPipeline(VictorPipeline):
   

    model_cpu_offload_seq = "text_encoder->unet->movq"

    def __init__(
        self,
        text_encoder: MultilingualCLIP,
        movq: VQModel,
        tokenizer: XLMRobertaTokenizer,
        unet: UNet2DConditionModel,
        scheduler: DDIMScheduler,
    ):
        super().__init__()

        self.register_modules(
            text_encoder=text_encoder,
            tokenizer=tokenizer,
            unet=unet,
            scheduler=scheduler,
            movq=movq,
        )
        self.movq_scale_factor = 2 ** (len(self.movq.config.block_out_channels) - 1)

   
    def get_timesteps(self, total_inference_steps, modulation_strength, target_device):
        initial_timestep = min(int(total_inference_steps * modulation_strength), total_inference_steps)

        starting_point = max(total_inference_steps - initial_timestep, 0)
        extracted_timesteps = self.scheduler.timesteps[starting_point:]

        return extracted_timesteps, total_inference_steps - starting_point


   
    def prepare_latents(self, input_latents, latent_time, desired_shape, data_type, target_device, data_generator, time_scheduler):
        if input_latents is None:
            input_latents = randn_tensor(desired_shape, generator=data_generator, device=target_device, dtype=data_type)
        else:
            if input_latents.shape != desired_shape:
                raise ValueError(f"Unexpected latents shape, got {input_latents.shape}, expected {desired_shape}")
            input_latents = input_latents.to(target_device)

        input_latents = input_latents * time_scheduler.init_noise_sigma

        new_shape = input_latents.shape
        noise_data = randn_tensor(new_shape, generator=data_generator, device=target_device, dtype=data_type)

        input_latents = self.add_noise(input_latents, noise_data, latent_time)
        return input_latents



    def process_prompt_embedding(
            self,
            user_prompt,
            computing_device,
            images_per_prompt,
            enable_classifier_free_guidance,
            negative_user_prompt=None,
        ):
            batch_size = len(user_prompt) if isinstance(user_prompt, list) else 1
            # Obtain embeddings for the user prompt text
            text_inputs = self.tokenizer(
                user_prompt,
                padding="max_length",
                max_length=77,
                truncation=True,
                return_attention_mask=True,
                add_special_tokens=True,
                return_tensors="pt",
            )

            input_text_ids = text_inputs.input_ids
            untruncated_ids = self.tokenizer(user_prompt, padding="longest", return_tensors="pt").input_ids

            if untruncated_ids.shape[-1] >= input_text_ids.shape[-1] and not torch.equal(input_text_ids, untruncated_ids):
                removed_text = self.tokenizer.batch_decode(untruncated_ids[:, self.tokenizer.model_max_length - 1 : -1])
                logger.warning(
                    "The following part of your input was truncated because CLIP can only handle sequences up to"
                    f" {self.tokenizer.model_max_length} tokens: {removed_text}"
                )

            input_text_ids = input_text_ids.to(computing_device)
            text_mask = text_inputs.attention_mask.to(computing_device)

            prompt_embeddings, text_encoder_hidden_states = self.text_encoder(
                input_ids=input_text_ids, attention_mask=text_mask
            )

            prompt_embeddings = prompt_embeddings.repeat_interleave(images_per_prompt, dim=0)
            text_encoder_hidden_states = text_encoder_hidden_states.repeat_interleave(images_per_prompt, dim=0)
            text_mask = text_mask.repeat_interleave(images_per_prompt, dim=0)

            if enable_classifier_free_guidance:
                unconditional_tokens: List[str]
                if negative_user_prompt is None:
                    unconditional_tokens = [""] * batch_size
                elif type(user_prompt) is not type(negative_user_prompt):
                    raise TypeError(
                        f"`negative_user_prompt` should be the same type as `user_prompt`, but got {type(negative_user_prompt)} !="
                        f" {type(user_prompt)}."
                    )
                elif isinstance(negative_user_prompt, str):
                    unconditional_tokens = [negative_user_prompt]
                elif batch_size != len(negative_user_prompt):
                    raise ValueError(
                        f"`negative_user_prompt`: {negative_user_prompt} has batch size {len(negative_user_prompt)}, but `user_prompt`:"
                        f" {user_prompt} has batch size {batch_size}. Please make sure that passed `negative_user_prompt` matches"
                        " the batch size of `user_prompt`."
                    )
                else:
                    unconditional_tokens = negative_user_prompt

                unconditional_input = self.tokenizer(
                    unconditional_tokens,
                    padding="max_length",
                    max_length=77,
                    truncation=True,
                    return_attention_mask=True,
                    add_special_tokens=True,
                    return_tensors="pt",
                )
                unconditional_text_input_ids = unconditional_input.input_ids.to(computing_device)
                unconditional_text_mask = unconditional_input.attention_mask.to(computing_device)

                negative_user_prompt_embeddings, unconditional_text_encoder_hidden_states = self.text_encoder(
                    input_ids=unconditional_text_input_ids, attention_mask=unconditional_text_mask
                )


                sequence_length = negative_user_prompt_embeddings.shape[1]
                negative_user_prompt_embeddings = negative_user_prompt_embeddings.repeat(1, images_per_prompt)
                negative_user_prompt_embeddings = negative_user_prompt_embeddings.view(batch_size * images_per_prompt, sequence_length)

                sequence_length = unconditional_text_encoder_hidden_states.shape[1]
                unconditional_text_encoder_hidden_states = unconditional_text_encoder_hidden_states.repeat(1, images_per_prompt, 1)
                unconditional_text_encoder_hidden_states = unconditional_text_encoder_hidden_states.view(
                    batch_size * images_per_prompt, sequence_length, -1
                )
                unconditional_text_mask = unconditional_text_mask.repeat_interleave(images_per_prompt, dim=0)

                # Done duplications

                
                prompt_embeddings = torch.cat([negative_user_prompt_embeddings, prompt_embeddings])
                text_encoder_hidden_states = torch.cat([unconditional_text_encoder_hidden_states, text_encoder_hidden_states])

                text_mask = torch.cat([unconditional_text_mask, text_mask])

            return prompt_embeddings, text_encoder_hidden_states, text_mask



    def introduce_variation(
        self,
        base_samples: torch.FloatTensor,
        additional_noise: torch.FloatTensor,
        time_steps: torch.IntTensor,
    ) -> torch.FloatTensor:
        blending_factors = torch.linspace(0.0001, 0.02, 1000, dtype=torch.float32)
        complement_factors = 1.0 - blending_factors
        complement_factors_cumprod = torch.cumprod(complement_factors, dim=0)
        complement_factors_cumprod = complement_factors_cumprod.to(device=base_samples.device, dtype=base_samples.dtype)
        time_steps = time_steps.to(base_samples.device)

        sqrt_complement_prod = complement_factors_cumprod[time_steps] ** 0.5
        sqrt_complement_prod = sqrt_complement_prod.flatten()
        while len(sqrt_complement_prod.shape) < len(base_samples.shape):
            sqrt_complement_prod = sqrt_complement_prod.unsqueeze(-1)

        sqrt_one_minus_complement_prod = (1 - complement_factors_cumprod[time_steps]) ** 0.5
        sqrt_one_minus_complement_prod = sqrt_one_minus_complement_prod.flatten()
        while len(sqrt_one_minus_complement_prod.shape) < len(base_samples.shape):
            sqrt_one_minus_complement_prod = sqrt_one_minus_complement_prod.unsqueeze(-1)

        varied_samples = sqrt_complement_prod * base_samples + sqrt_one_minus_complement_prod * additional_noise

        return varied_samples


    @torch.no_grad()
    
    def __call__(
        self,
        prompt: Union[str, List[str]],
        image: Union[torch.FloatTensor, PIL.Image.Image, List[torch.FloatTensor], List[PIL.Image.Image]],
        image_embeds: torch.FloatTensor,
        negative_image_embeds: torch.FloatTensor,
        negative_prompt: Optional[Union[str, List[str]]] = None,
        height: int = 512,
        width: int = 512,
        num_inference_steps: int = 100,
        strength: float = 0.3,
        guidance_scale: float = 7.0,
        num_images_per_prompt: int = 1,
        generator: Optional[Union[torch.Generator, List[torch.Generator]]] = None,
        output_type: Optional[str] = "pil",
        callback: Optional[Callable[[int, int, torch.FloatTensor], None]] = None,
        callback_steps: int = 1,
        return_dict: bool = True,
    ):
       
        if isinstance(prompt, str):
            batch_size = 1
        elif isinstance(prompt, list):
            batch_size = len(prompt)
        else:
            raise ValueError(f"`prompt` has to be of type `str` or `list` but is {type(prompt)}")

        device = self._execution_device

        batch_size = batch_size * num_images_per_prompt

        do_classifier_free_guidance = guidance_scale > 1.0

        # 2. get text and image embeddings
        prompt_embeds, text_encoder_hidden_states, _ = self._encode_prompt(
            prompt, device, num_images_per_prompt, do_classifier_free_guidance, negative_prompt
        )

        if isinstance(image_embeds, list):
            image_embeds = torch.cat(image_embeds, dim=0)
        if isinstance(negative_image_embeds, list):
            negative_image_embeds = torch.cat(negative_image_embeds, dim=0)

        if do_classifier_free_guidance:
            image_embeds = image_embeds.repeat_interleave(num_images_per_prompt, dim=0)
            negative_image_embeds = negative_image_embeds.repeat_interleave(num_images_per_prompt, dim=0)

            image_embeds = torch.cat([negative_image_embeds, image_embeds], dim=0).to(
                dtype=prompt_embeds.dtype, device=device
            )

        # 3. pre-processing initial image
        if not isinstance(image, list):
            image = [image]
        if not all(isinstance(i, (PIL.Image.Image, torch.Tensor)) for i in image):
            raise ValueError(
                f"Input is in incorrect format: {[type(i) for i in image]}. Currently, we only support  PIL image and pytorch tensor"
            )

        image = torch.cat([prepare_image(i, width, height) for i in image], dim=0)
        image = image.to(dtype=prompt_embeds.dtype, device=device)

        latents = self.movq.encode(image)["latents"]
        latents = latents.repeat_interleave(num_images_per_prompt, dim=0)

        # 4. set timesteps
        self.scheduler.set_timesteps(num_inference_steps, device=device)

        timesteps_tensor, num_inference_steps = self.get_timesteps(num_inference_steps, strength, device)

        # the formular to calculate timestep for add_noise is taken from the original kandinsky repo
        latent_timestep = int(self.scheduler.config.num_train_timesteps * strength) - 2

        latent_timestep = torch.tensor([latent_timestep] * batch_size, dtype=timesteps_tensor.dtype, device=device)

        num_channels_latents = self.unet.config.in_channels

        height, width = get_new_h_w(height, width, self.movq_scale_factor)

        # 5. Create initial latent
        latents = self.prepare_latents(
            latents,
            latent_timestep,
            (batch_size, num_channels_latents, height, width),
            text_encoder_hidden_states.dtype,
            device,
            generator,
            self.scheduler,
        )

        # 6. Denoising loop
        for i, t in enumerate(self.progress_bar(timesteps_tensor)):
            # expand the latents if we are doing classifier free guidance
            latent_model_input = torch.cat([latents] * 2) if do_classifier_free_guidance else latents

            added_cond_kwargs = {"text_embeds": prompt_embeds, "image_embeds": image_embeds}
            noise_pred = self.unet(
                sample=latent_model_input,
                timestep=t,
                encoder_hidden_states=text_encoder_hidden_states,
                added_cond_kwargs=added_cond_kwargs,
                return_dict=False,
            )[0]

            if do_classifier_free_guidance:
                noise_pred, variance_pred = noise_pred.split(latents.shape[1], dim=1)
                noise_pred_uncond, noise_pred_text = noise_pred.chunk(2)
                _, variance_pred_text = variance_pred.chunk(2)
                noise_pred = noise_pred_uncond + guidance_scale * (noise_pred_text - noise_pred_uncond)
                noise_pred = torch.cat([noise_pred, variance_pred_text], dim=1)

            if not (
                hasattr(self.scheduler.config, "variance_type")
                and self.scheduler.config.variance_type in ["learned", "learned_range"]
            ):
                noise_pred, _ = noise_pred.split(latents.shape[1], dim=1)

            latents = self.scheduler.step(
                noise_pred,
                t,
                latents,
                generator=generator,
            ).prev_sample

            if callback is not None and i % callback_steps == 0:
                step_idx = i // getattr(self.scheduler, "order", 1)
                callback(step_idx, t, latents)

        # 7. post-processing
        image = self.movq.decode(latents, force_not_quantize=True)["sample"]

        self.maybe_free_model_hooks()

        if output_type not in ["pt", "np", "pil"]:
            raise ValueError(f"Only the output types `pt`, `pil` and `np` are supported not output_type={output_type}")

        if output_type in ["np", "pil"]:
            image = image * 0.5 + 0.5
            image = image.clamp(0, 1)
            image = image.cpu().permute(0, 2, 3, 1).float().numpy()

        if output_type == "pil":
            image = self.numpy_to_pil(image)

        if not return_dict:
            return (image,)

        return ImagePipelineOutput(images=image)
