from typing import Callable, Dict, List, Optional, Union
import PIL.Image
import torch
from transformers import CLIPImageProcessor, CLIPTextModelWithProjection, CLIPTokenizer, CLIPVisionModelWithProjection
from ...models import PriorTransformer
from ...schedulers import UnCLIPScheduler
from ...utils import (logging)
from ...utils.torch_utils import randn_tensor
from ..kandinsky import KandinskyPriorPipelineOutput
from ..pipeline_utils import VictorPipeline


logger = logging.get_logger(__name__)  

class KandinskyV22PriorPipeline(VictorPipeline):
  
    model_cpu_offload_seq = "text_encoder->image_encoder->prior"
    _exclude_from_cpu_offload = ["prior"]
    _callback_tensor_inputs = ["latents", "prompt_embeds", "text_encoder_hidden_states", "text_mask"]

    def __init__(
        self,
        prior: PriorTransformer,
        image_encoder: CLIPVisionModelWithProjection,
        text_encoder: CLIPTextModelWithProjection,
        tokenizer: CLIPTokenizer,
        scheduler: UnCLIPScheduler,
        image_processor: CLIPImageProcessor,
    ):
        super().__init__()

        self.register_modules(
            prior=prior,
            text_encoder=text_encoder,
            tokenizer=tokenizer,
            scheduler=scheduler,
            image_encoder=image_encoder,
            image_processor=image_processor,
        )

    @torch.no_grad()
    def interpolate(
        self,
        new_inputs_and_conditions: List[Union[str, PIL.Image.Image, torch.FloatTensor]],
        new_weights: List[float],
        new_num_images_per_condition: int = 1,
        new_num_inference_steps: int = 25,
        new_generator: Optional[Union[torch.Generator, List[torch.Generator]]] = None,
        new_latents: Optional[torch.FloatTensor] = None,
        new_negative_prior_condition: Optional[str] = None,
        new_negative_condition: str = "",
        new_guidance_scale: float = 4.0,
        new_device=None,
    ):
    

        new_device = new_device or self.device

        if len(new_inputs_and_conditions) != len(new_weights):
            raise ValueError(
                f"`new_inputs_and_conditions` contains {len(new_inputs_and_conditions)} items and `new_weights` contains {len(new_weights)} items - they should be lists of the same length"
            )

        new_image_embeddings = []
        for new_cond, new_weight in zip(new_inputs_and_conditions, new_weights):
            if isinstance(new_cond, str):
                new_image_emb = self(
                    new_cond,
                    num_inference_steps=new_num_inference_steps,
                    num_images_per_prompt=new_num_images_per_condition,
                    generator=new_generator,
                    latents=new_latents,
                    negative_prompt=new_negative_prior_condition,
                    guidance_scale=new_guidance_scale,
                ).image_embeds.unsqueeze(0)

            elif isinstance(new_cond, (PIL.Image.Image, torch.Tensor)):
                if isinstance(new_cond, PIL.Image.Image):
                    new_cond = (
                        self.image_processor(new_cond, return_tensors="pt")
                        .pixel_values[0]
                        .unsqueeze(0)
                        .to(dtype=self.image_encoder.dtype, device=new_device)
                    )

                new_image_emb = self.image_encoder(new_cond)["image_embeds"].repeat(new_num_images_per_condition, 1).unsqueeze(0)

            else:
                raise ValueError(
                    f"`new_inputs_and_conditions` can only contain elements of type `str`, `PIL.Image.Image`, or `torch.Tensor`  but is {type(new_cond)}"
                )

            new_image_embeddings.append(new_image_emb * new_weight)

        new_image_emb = torch.cat(new_image_embeddings).sum(dim=0)

        out_zero = self(
            new_negative_condition,
            num_inference_steps=new_num_inference_steps,
            num_images_per_prompt=new_num_images_per_condition,
            generator=new_generator,
            latents=new_latents,
            negative_prompt=new_negative_prior_condition,
            guidance_scale=new_guidance_scale,
        )
        zero_image_emb = out_zero.negative_image_embeds if new_negative_condition == "" else out_zero.image_embeds

        return KandinskyPriorPipelineOutput(image_embeds=new_image_emb, negative_image_embeds=zero_image_emb)

    def prepare_latents(self, shape, dtype, target_device, random_generator, input_latents, noise_scheduler):
        if input_latents is None:
            input_latents = randn_tensor(shape, generator=random_generator, device=target_device, dtype=dtype)
        else:
            if input_latents.shape != shape:
                raise ValueError(f"Unexpected latents shape, got {input_latents.shape}, expected {shape}")
            input_latents = input_latents.to(target_device)

        input_latents = input_latents * noise_scheduler.init_noise_sigma
        return input_latents
    

   
    def get_zero_embed(self, custom_batch_size=1, custom_device=None):
        custom_device = custom_device or self.device
        zero_img = torch.zeros(1, 3, self.image_encoder.config.image_size, self.image_encoder.config.image_size).to(
            device=custom_device, dtype=self.image_encoder.dtype
        )
        zero_image_emb = self.image_encoder(zero_img)["image_embeds"]
        zero_image_emb = zero_image_emb.repeat(custom_batch_size, 1)
        return zero_image_emb




    def _encode_prompt(
            self,
            custom_prompt,
            custom_device,
            custom_num_images_per_prompt,
            custom_do_classifier_free_guidance,
            custom_negative_prompt=None,
        ):
            batch_size = len(custom_prompt) if isinstance(custom_prompt, list) else 1
            # get prompt text embeddings
            text_inputs = self.tokenizer(
                custom_prompt,
                padding="max_length",
                max_length=self.tokenizer.model_max_length,
                truncation=True,
                return_tensors="pt",
            )
            text_input_ids = text_inputs.input_ids
            text_mask = text_inputs.attention_mask.bool().to(device=custom_device)

            untruncated_ids = self.tokenizer(custom_prompt, padding="longest", return_tensors="pt").input_ids

            if untruncated_ids.shape[-1] >= text_input_ids.shape[-1] and not torch.equal(text_input_ids, untruncated_ids):
                removed_text = self.tokenizer.batch_decode(untruncated_ids[:, self.tokenizer.model_max_length - 1 : -1])
                logger.warning(
                    "The following part of your input was truncated because CLIP can only handle sequences up to"
                    f" {self.tokenizer.model_max_length} tokens: {removed_text}"
                )
                text_input_ids = text_input_ids[:, : self.tokenizer.model_max_length]

            text_encoder_output = self.text_encoder(text_input_ids.to(device=custom_device))

            prompt_embeds = text_encoder_output.text_embeds
            text_encoder_hidden_states = text_encoder_output.last_hidden_state

            prompt_embeds = prompt_embeds.repeat_interleave(custom_num_images_per_prompt, dim=0)
            text_encoder_hidden_states = text_encoder_hidden_states.repeat_interleave(custom_num_images_per_prompt, dim=0)
            text_mask = text_mask.repeat_interleave(custom_num_images_per_prompt, dim=0)

            if custom_do_classifier_free_guidance:
                uncond_tokens: List[str]
                if custom_negative_prompt is None:
                    uncond_tokens = [""] * batch_size
                elif type(custom_prompt) is not type(custom_negative_prompt):
                    raise TypeError(
                        f"`custom_negative_prompt` should be the same type as `custom_prompt`, but got {type(custom_negative_prompt)} !="
                        f" {type(custom_prompt)}."
                    )
                elif isinstance(custom_negative_prompt, str):
                    uncond_tokens = [custom_negative_prompt]
                elif batch_size != len(custom_negative_prompt):
                    raise ValueError(
                        f"`custom_negative_prompt`: {custom_negative_prompt} has batch size {len(custom_negative_prompt)}, but `custom_prompt`:"
                        f" {custom_prompt} has batch size {batch_size}. Please make sure that passed `custom_negative_prompt` matches"
                        " the batch size of `custom_prompt`."
                    )
                else:
                    uncond_tokens = custom_negative_prompt

                uncond_input = self.tokenizer(
                    uncond_tokens,
                    padding="max_length",
                    max_length=self.tokenizer.model_max_length,
                    truncation=True,
                    return_tensors="pt",
                )
                uncond_text_mask = uncond_input.attention_mask.bool().to(device=custom_device)
                negative_prompt_embeds_text_encoder_output = self.text_encoder(uncond_input.input_ids.to(device=custom_device))

                negative_prompt_embeds = negative_prompt_embeds_text_encoder_output.text_embeds
                uncond_text_encoder_hidden_states = negative_prompt_embeds_text_encoder_output.last_hidden_state


                seq_len = negative_prompt_embeds.shape[1]
                negative_prompt_embeds = negative_prompt_embeds.repeat(1, custom_num_images_per_prompt)
                negative_prompt_embeds = negative_prompt_embeds.view(batch_size * custom_num_images_per_prompt, seq_len)

                seq_len = uncond_text_encoder_hidden_states.shape[1]
                uncond_text_encoder_hidden_states = uncond_text_encoder_hidden_states.repeat(1, custom_num_images_per_prompt, 1)
                uncond_text_encoder_hidden_states = uncond_text_encoder_hidden_states.view(
                    batch_size * custom_num_images_per_prompt, seq_len, -1
                )
                uncond_text_mask = uncond_text_mask.repeat_interleave(custom_num_images_per_prompt, dim=0)


                prompt_embeds = torch.cat([negative_prompt_embeds, prompt_embeds])
                text_encoder_hidden_states = torch.cat([uncond_text_encoder_hidden_states, text_encoder_hidden_states])

                text_mask = torch.cat([uncond_text_mask, text_mask])

            return prompt_embeds, text_encoder_hidden_states, text_mask

    
    @property
    def do_classifier_free_guidance(self):
        return self._guidance_scale > 1

    @property
    def guidance_scale(self):
        return self._guidance_scale

    @property
    def num_timesteps(self):
        return self._num_timesteps

    @torch.no_grad()
    
    def __call__(
        self,
        prompt: Union[str, List[str]],
        negative_prompt: Optional[Union[str, List[str]]] = None,
        num_images_per_prompt: int = 1,
        num_inference_steps: int = 25,
        generator: Optional[Union[torch.Generator, List[torch.Generator]]] = None,
        latents: Optional[torch.FloatTensor] = None,
        guidance_scale: float = 4.0,
        output_type: Optional[str] = "pt",  
        return_dict: bool = True,
        callback_on_step_end: Optional[Callable[[int, int, Dict], None]] = None,
        callback_on_step_end_tensor_inputs: List[str] = ["latents"],
    ):
       

        if callback_on_step_end_tensor_inputs is not None and not all(
            k in self._callback_tensor_inputs for k in callback_on_step_end_tensor_inputs
        ):
            raise ValueError(
                f"`callback_on_step_end_tensor_inputs` has to be in {self._callback_tensor_inputs}, but found {[k for k in callback_on_step_end_tensor_inputs if k not in self._callback_tensor_inputs]}"
            )

        if isinstance(prompt, str):
            prompt = [prompt]
        elif not isinstance(prompt, list):
            raise ValueError(f"`prompt` has to be of type `str` or `list` but is {type(prompt)}")

        if isinstance(negative_prompt, str):
            negative_prompt = [negative_prompt]
        elif not isinstance(negative_prompt, list) and negative_prompt is not None:
            raise ValueError(f"`negative_prompt` has to be of type `str` or `list` but is {type(negative_prompt)}")

        # if the negative prompt is defined we double the batch size to
        # directly retrieve the negative prompt embedding
        if negative_prompt is not None:
            prompt = prompt + negative_prompt
            negative_prompt = 2 * negative_prompt

        device = self._execution_device

        batch_size = len(prompt)
        batch_size = batch_size * num_images_per_prompt

        self._guidance_scale = guidance_scale

        prompt_embeds, text_encoder_hidden_states, text_mask = self._encode_prompt(
            prompt, device, num_images_per_prompt, self.do_classifier_free_guidance, negative_prompt
        )

        # prior
        self.scheduler.set_timesteps(num_inference_steps, device=device)
        timesteps = self.scheduler.timesteps

        embedding_dim = self.prior.config.embedding_dim

        latents = self.prepare_latents(
            (batch_size, embedding_dim),
            prompt_embeds.dtype,
            device,
            generator,
            latents,
            self.scheduler,
        )
        self._num_timesteps = len(timesteps)
        for i, t in enumerate(self.progress_bar(timesteps)):
            # expand the latents if we are doing classifier free guidance
            latent_model_input = torch.cat([latents] * 2) if self.do_classifier_free_guidance else latents

            predicted_image_embedding = self.prior(
                latent_model_input,
                timestep=t,
                proj_embedding=prompt_embeds,
                encoder_hidden_states=text_encoder_hidden_states,
                attention_mask=text_mask,
            ).predicted_image_embedding

            if self.do_classifier_free_guidance:
                predicted_image_embedding_uncond, predicted_image_embedding_text = predicted_image_embedding.chunk(2)
                predicted_image_embedding = predicted_image_embedding_uncond + self.guidance_scale * (
                    predicted_image_embedding_text - predicted_image_embedding_uncond
                )

            if i + 1 == timesteps.shape[0]:
                prev_timestep = None
            else:
                prev_timestep = timesteps[i + 1]

            latents = self.scheduler.step(
                predicted_image_embedding,
                timestep=t,
                sample=latents,
                generator=generator,
                prev_timestep=prev_timestep,
            ).prev_sample

            if callback_on_step_end is not None:
                callback_kwargs = {}
                for k in callback_on_step_end_tensor_inputs:
                    callback_kwargs[k] = locals()[k]
                callback_outputs = callback_on_step_end(self, i, t, callback_kwargs)

                latents = callback_outputs.pop("latents", latents)
                prompt_embeds = callback_outputs.pop("prompt_embeds", prompt_embeds)
                text_encoder_hidden_states = callback_outputs.pop(
                    "text_encoder_hidden_states", text_encoder_hidden_states
                )
                text_mask = callback_outputs.pop("text_mask", text_mask)

        latents = self.prior.post_process_latents(latents)

        image_embeddings = latents

        if negative_prompt is None:
            zero_embeds = self.get_zero_embed(latents.shape[0], device=latents.device)
        else:
            image_embeddings, zero_embeds = image_embeddings.chunk(2)

        self.maybe_free_model_hooks()

        if output_type not in ["pt", "np"]:
            raise ValueError(f"Only the output types `pt` and `np` are supported not output_type={output_type}")

        if output_type == "np":
            image_embeddings = image_embeddings.cpu().numpy()
            zero_embeds = zero_embeds.cpu().numpy()

        if not return_dict:
            return (image_embeddings, zero_embeds)

        return KandinskyPriorPipelineOutput(image_embeds=image_embeddings, negative_image_embeds=zero_embeds)
