import inspect
from typing import Any, Callable, Dict, List, Optional, Union
import PIL.Image
import torch
from transformers import CLIPImageProcessor, CLIPTextModel, CLIPTokenizer
from ...image_processor import PipelineImageInput, VaeImageProcessor
from ...loaders import FromSingleFileMixin, LoraLoaderMixin, TextualInversionLoaderMixin
from ...models import AutoencoderKL, UNet2DConditionModel
from ...models.lora import adjust_lora_scale_text_encoder
from ...schedulers import LCMScheduler
from ...utils import (
    USE_PEFT_BACKEND,
    deprecate,
    logging,
    scale_lora_layers,
    unscale_lora_layers,
)
from ...utils.torch_utils import randn_tensor
from ..pipeline_utils import VictorPipeline
from ..stable_victor import StableVictorPipelineOutput, StableVictorSafetyChecker


logger = logging.get_logger(__name__)


def retrieve_latents(encoder_output, generator):
    if hasattr(encoder_output, "latent_dist"):
        return encoder_output.latent_dist.sample(generator)
    elif hasattr(encoder_output, "latents"):
        return encoder_output.latents
    else:
        raise AttributeError("Could not access latents of provided encoder_output")



class LatentConsistencyModelImg2ImgPipeline(
    VictorPipeline, TextualInversionLoaderMixin, LoraLoaderMixin, FromSingleFileMixin
):
    

    model_cpu_offload_seq = "text_encoder->unet->vae"
    _optional_components = ["safety_checker", "feature_extractor"]
    _exclude_from_cpu_offload = ["safety_checker"]
    _callback_tensor_inputs = ["latents", "denoised", "prompt_embeds", "w_embedding"]

    def __init__(
        self,
        vae: AutoencoderKL,
        text_encoder: CLIPTextModel,
        tokenizer: CLIPTokenizer,
        unet: UNet2DConditionModel,
        scheduler: LCMScheduler,
        safety_checker: StableVictorSafetyChecker,
        feature_extractor: CLIPImageProcessor,
        requires_safety_checker: bool = True,
    ):
        super().__init__()

        self.register_modules(
            vae=vae,
            text_encoder=text_encoder,
            tokenizer=tokenizer,
            unet=unet,
            scheduler=scheduler,
            safety_checker=safety_checker,
            feature_extractor=feature_extractor,
        )

        if safety_checker is None and requires_safety_checker:
            logger.warning(
                f"You have disabled the safety checker for {self.__class__} by passing `safety_checker=None`. Ensure"
               
            )

        self.vae_scale_factor = 2 ** (len(self.vae.config.block_out_channels) - 1)
        self.image_processor = VaeImageProcessor(vae_scale_factor=self.vae_scale_factor)

    def enable_vae_slicing(self):
        r"""
        Enable sliced VAE decoding. When this option is enabled, the VAE will split the input tensor in slices to
        compute decoding in several steps. This is useful to save some memory and allow larger batch sizes.
        """
        self.vae.enable_slicing()

    def disable_vae_slicing(self):
       
        self.vae.disable_slicing()

    def enable_vae_tiling(self):
        r"""
        Enable tiled VAE decoding. When this option is enabled, the VAE will split the input tensor into tiles to
        compute decoding and encoding in several steps. This is useful for saving a large amount of memory and to allow
        processing larger images.
        """
        self.vae.enable_tiling()

    def disable_vae_tiling(self):
        r"""
        Disable tiled VAE decoding. If `enable_vae_tiling` was previously enabled, this method will go back to
        computing decoding in one step.
        """
        self.vae.disable_tiling()

    def enable_freeu(self, s1: float, s2: float, b1: float, b2: float):
      
        if not hasattr(self, "unet"):
            raise ValueError("The pipeline must have `unet` for using FreeU.")
        self.unet.enable_freeu(s1=s1, s2=s2, b1=b1, b2=b2)

    def disable_freeu(self):
        self.unet.disable_freeu()

    def encode_prompt(
        self,
        input_prompt,
        input_device,
        input_num_images_per_prompt,
        input_do_classifier_free_guidance,
        input_negative_prompt=None,
        input_prompt_embeds: Optional[torch.FloatTensor] = None,
        input_negative_prompt_embeds: Optional[torch.FloatTensor] = None,
        input_lora_scale: Optional[float] = None,
        input_clip_skip: Optional[int] = None,
    ):
        # set lora scale so that monkey patched LoRA
        if input_lora_scale is not None and isinstance(self, LoraLoaderMixin):
            self._lora_scale = input_lora_scale

            if not USE_PEFT_BACKEND:
                adjust_lora_scale_text_encoder(self.text_encoder, input_lora_scale)
            else:
                scale_lora_layers(self.text_encoder, input_lora_scale)

        if input_prompt is not None and isinstance(input_prompt, str):
            batch_size = 1
        elif input_prompt is not None and isinstance(input_prompt, list):
            batch_size = len(input_prompt)
        else:
            batch_size = input_prompt_embeds.shape[0]

        if input_prompt_embeds is None:
            # textual inversion: procecss multi-vector tokens if necessary
            if isinstance(self, TextualInversionLoaderMixin):
                input_prompt = self.maybe_convert_prompt(input_prompt, self.tokenizer)

            text_inputs = self.tokenizer(
                input_prompt,
                padding="max_length",
                max_length=self.tokenizer.model_max_length,
                truncation=True,
                return_tensors="pt",
            )
            text_input_ids = text_inputs.input_ids
            untruncated_ids = self.tokenizer(input_prompt, padding="longest", return_tensors="pt").input_ids

            if untruncated_ids.shape[-1] >= text_input_ids.shape[-1] and not torch.equal(
                text_input_ids, untruncated_ids
            ):
                removed_text = self.tokenizer.batch_decode(
                    untruncated_ids[:, self.tokenizer.model_max_length - 1 : -1]
                )
                logger.warning(
                    "The following part of your input was truncated because CLIP can only handle sequences up to"
                    f" {self.tokenizer.model_max_length} tokens: {removed_text}"
                )

            if hasattr(self.text_encoder.config, "use_attention_mask") and self.text_encoder.config.use_attention_mask:
                attention_mask = text_inputs.attention_mask.to(input_device)
            else:
                attention_mask = None

            if input_clip_skip is None:
                input_prompt_embeds = self.text_encoder(text_input_ids.to(input_device), attention_mask=attention_mask)
                input_prompt_embeds = input_prompt_embeds[0]
            else:
                input_prompt_embeds = self.text_encoder(
                    text_input_ids.to(input_device), attention_mask=attention_mask, output_hidden_states=True
                )
                # Access the `hidden_states` first, that contains a tuple of
              
                input_prompt_embeds = input_prompt_embeds[-1][-(input_clip_skip + 1)]
              
                input_prompt_embeds = self.text_encoder.text_model.final_layer_norm(input_prompt_embeds)

        if self.text_encoder is not None:
            input_prompt_embeds_dtype = self.text_encoder.dtype
        elif self.unet is not None:
            input_prompt_embeds_dtype = self.unet.dtype
        else:
            input_prompt_embeds_dtype = input_prompt_embeds.dtype

        input_prompt_embeds = input_prompt_embeds.to(dtype=input_prompt_embeds_dtype, device=input_device)

        bs_embed, seq_len, _ = input_prompt_embeds.shape
        # duplicate text embeddings for each generation per prompt, using mps friendly method
        input_prompt_embeds = input_prompt_embeds.repeat(1, input_num_images_per_prompt, 1)
        input_prompt_embeds = input_prompt_embeds.view(bs_embed * input_num_images_per_prompt, seq_len, -1)

        # get unconditional embeddings for classifier free guidance
        if input_do_classifier_free_guidance and input_negative_prompt_embeds is None:
            uncond_tokens: List[str]
            if input_negative_prompt is None:
                uncond_tokens = [""] * batch_size
            elif input_prompt is not None and type(input_prompt) is not type(input_negative_prompt):
                raise TypeError(
                    f"`input_negative_prompt` should be the same type to `input_prompt`, but got {type(input_negative_prompt)} !="
                    f" {type(input_prompt)}."
                )
            elif isinstance(input_negative_prompt, str):
                uncond_tokens = [input_negative_prompt]
            elif batch_size != len(input_negative_prompt):
                raise ValueError(
                    f"`input_negative_prompt`: {input_negative_prompt} has batch size {len(input_negative_prompt)}, but `input_prompt`:"
                    f" {input_prompt} has batch size {batch_size}. Please make sure that passed `input_negative_prompt` matches"
                    " the batch size of `input_prompt`."
                )
            else:
                uncond_tokens = input_negative_prompt

            # textual inversion: procecss multi-vector tokens if necessary
            if isinstance(self, TextualInversionLoaderMixin):
                uncond_tokens = self.maybe_convert_prompt(uncond_tokens, self.tokenizer)

            max_length = input_prompt_embeds.shape[1]
            uncond_input = self.tokenizer(
                uncond_tokens,
                padding="max_length",
                max_length=max_length,
                truncation=True,
                return_tensors="pt",
            )

            if hasattr(self.text_encoder.config, "use_attention_mask") and self.text_encoder.config.use_attention_mask:
                attention_mask = uncond_input.attention_mask.to(input_device)
            else:
                attention_mask = None

            input_negative_prompt_embeds = self.text_encoder(
                uncond_input.input_ids.to(input_device),
                attention_mask=attention_mask,
            )
            input_negative_prompt_embeds = input_negative_prompt_embeds[0]

        if input_do_classifier_free_guidance:
            # duplicate unconditional embeddings for each generation per prompt, using mps friendly method
            seq_len = input_negative_prompt_embeds.shape[1]

            input_negative_prompt_embeds = input_negative_prompt_embeds.to(dtype=input_prompt_embeds_dtype, device=input_device)

            input_negative_prompt_embeds = input_negative_prompt_embeds.repeat(1, input_num_images_per_prompt, 1)
            input_negative_prompt_embeds = input_negative_prompt_embeds.view(batch_size * input_num_images_per_prompt, seq_len, -1)

        if isinstance(self, LoraLoaderMixin) and USE_PEFT_BACKEND:
            # Retrieve the original scale by scaling back the LoRA layers
            unscale_lora_layers(self.text_encoder, input_lora_scale)

        return input_prompt_embeds, input_negative_prompt_embeds



    def run_safety_checker(self, input_image, input_device, input_dtype):
        if self.safety_checker is None:
            result_has_nsfw_concept = None
        else:
            if torch.is_tensor(input_image):
                processed_image_input = self.image_processor.postprocess(input_image, output_type="pil")
            else:
                processed_image_input = self.image_processor.numpy_to_pil(input_image)
            safety_checker_input = self.feature_extractor(processed_image_input, return_tensors="pt").to(input_device)
            input_image, result_has_nsfw_concept = self.safety_checker(
                images=input_image, clip_input=safety_checker_input.pixel_values.to(input_dtype)
            )
        return input_image, result_has_nsfw_concept

 

    def prepare_latents(self, input_image, input_timestep, input_batch_size, input_num_images_per_prompt, input_dtype, input_device, input_generator=None):
        if not isinstance(input_image, (torch.Tensor, PIL.Image.Image, list)):
            raise ValueError(
                f"`image` has to be of type `torch.Tensor`, `PIL.Image.Image` or list but is {type(input_image)}"
            )

        input_image = input_image.to(device=input_device, dtype=input_dtype)

        input_batch_size = input_batch_size * input_num_images_per_prompt

        if input_image.shape[1] == 4:
            initialized_latents = input_image
        else:
            if isinstance(input_generator, list) and len(input_generator) != input_batch_size:
                raise ValueError(
                    f"You have passed a list of generators of length {len(input_generator)}, but requested an effective batch"
                    f" size of {input_batch_size}. Make sure the batch size matches the length of the generators."
                )
            elif isinstance(input_generator, list):
                initialized_latents = [
                    retrieve_latents(self.vae.encode(input_image[i : i + 1]), generator=input_generator[i])
                    for i in range(input_batch_size)
                ]
                initialized_latents = torch.cat(initialized_latents, dim=0)
            else:
                initialized_latents = retrieve_latents(self.vae.encode(input_image), generator=input_generator)

            initialized_latents = self.vae.config.scaling_factor * initialized_latents

        if input_batch_size > initialized_latents.shape[0] and input_batch_size % initialized_latents.shape[0] == 0:
            # expand initialized_latents for input_batch_size
            deprecation_message = (
                f"You have passed {input_batch_size} text prompts (`prompt`), but only {initialized_latents.shape[0]} initial"
               
            )
            deprecate("len(prompt) != len(image)", "1.0.0", deprecation_message, standard_warn=False)
            additional_images_per_prompt = input_batch_size // initialized_latents.shape[0]
            initialized_latents = torch.cat([initialized_latents] * additional_images_per_prompt, dim=0)
        elif input_batch_size > initialized_latents.shape[0] and input_batch_size % initialized_latents.shape[0] != 0:
            raise ValueError(
                f"Cannot duplicate `image` of batch size {initialized_latents.shape[0]} to {input_batch_size} text prompts."
            )
        else:
            initialized_latents = torch.cat([initialized_latents], dim=0)

        shape = initialized_latents.shape
        noise = randn_tensor(shape, generator=input_generator, device=input_device, dtype=input_dtype)

        # get latents
        initialized_latents = self.scheduler.add_noise(initialized_latents, noise, input_timestep)
        latents = initialized_latents

        return latents

 
    def get_guidance_scale_embedding(self, input_w, input_embedding_dim=512, input_dtype=torch.float32):
      
        assert len(input_w.shape) == 1
        input_w = input_w * 1000.0

        half_dim = input_embedding_dim // 2
        emb = torch.log(torch.tensor(10000.0)) / (half_dim - 1)
        emb = torch.exp(torch.arange(half_dim, dtype=input_dtype) * -emb)
        emb = input_w.to(input_dtype)[:, None] * emb[None, :]
        emb = torch.cat([torch.sin(emb), torch.cos(emb)], dim=1)
        if input_embedding_dim % 2 == 1:  # zero pad
            emb = torch.nn.functional.pad(emb, (0, 1))
        assert emb.shape == (input_w.shape[0], input_embedding_dim)
        return emb


  

    def prepare_extra_step_kwargs(self, input_generator, input_eta):
        

        accepts_eta = "eta" in set(inspect.signature(self.scheduler.step).parameters.keys())
        extra_step_kwargs = {}
        if accepts_eta:
            extra_step_kwargs["eta"] = input_eta

        # check if the scheduler accepts generator
        accepts_generator = "generator" in set(inspect.signature(self.scheduler.step).parameters.keys())
        if accepts_generator:
            extra_step_kwargs["generator"] = input_generator
        return extra_step_kwargs



    def get_timesteps(self, total_inference_steps, input_strength, input_device):
        # get the original timestep using init_timestep
        init_timestep = min(int(total_inference_steps * input_strength), total_inference_steps)

        t_start = max(total_inference_steps - init_timestep, 0)
        timesteps = self.scheduler.timesteps[t_start * self.scheduler.order :]

        return timesteps, total_inference_steps - t_start


 

    def check_inputs(
        self,
        user_input: Union[str, List[str]],
        intensity: float,
        steps: int,
        embedded_prompt: Optional[torch.FloatTensor] = None,
        step_end_inputs=None,
    ):
        if intensity < 0 or intensity > 1:
            raise ValueError(f"The value of intensity should be in [0.0, 1.0] but is {intensity}")

        if steps is not None and (not isinstance(steps, int) or steps <= 0):
            raise ValueError(
                f"`steps` has to be a positive integer but is {steps} of type {type(steps)}."
            )

        if step_end_inputs is not None and not all(
            k in self._callback_tensor_inputs for k in step_end_inputs
        ):
            raise ValueError(
                f"`step_end_inputs` has to be in {self._callback_tensor_inputs}, but found {[k for k in step_end_inputs if k not in self._callback_tensor_inputs]}"
            )

        if user_input is not None and embedded_prompt is not None:
            raise ValueError(
                f"Cannot forward both `user_input`: {user_input} and `embedded_prompt`: {embedded_prompt}. Please make sure to"
                " only forward one of the two."
            )
        elif user_input is None and embedded_prompt is None:
            raise ValueError(
                "Provide either `user_input` or `embedded_prompt`. Cannot leave both `user_input` and `embedded_prompt` undefined."
            )
        elif user_input is not None and (not isinstance(user_input, str) and not isinstance(user_input, list)):
            raise ValueError(f"`user_input` has to be of type `str` or `list` but is {type(user_input)}")


    @property
    def guidance_scale(self):
        return self._guidance_scale

    @property
    def cross_attention_kwargs(self):
        return self._cross_attention_kwargs

    @property
    def clip_skip(self):
        return self._clip_skip

    @property
    def num_timesteps(self):
        return self._num_timesteps

    @torch.no_grad()
    
    def __call__(
        self,
        prompt: Union[str, List[str]] = None,
        image: PipelineImageInput = None,
        num_inference_steps: int = 4,
        strength: float = 0.8,
        original_inference_steps: int = None,
        guidance_scale: float = 8.5,
        num_images_per_prompt: Optional[int] = 1,
        generator: Optional[Union[torch.Generator, List[torch.Generator]]] = None,
        latents: Optional[torch.FloatTensor] = None,
        prompt_embeds: Optional[torch.FloatTensor] = None,
        output_type: Optional[str] = "pil",
        return_dict: bool = True,
        cross_attention_kwargs: Optional[Dict[str, Any]] = None,
        clip_skip: Optional[int] = None,
        callback_on_step_end: Optional[Callable[[int, int, Dict], None]] = None,
        callback_on_step_end_tensor_inputs: List[str] = ["latents"],
        **kwargs,
    ):
       
        callback = kwargs.pop("callback", None)
        callback_steps = kwargs.pop("callback_steps", None)

        if callback is not None:
            deprecate(
                "callback",
                "1.0.0",
                "Passing `callback` as an input argument to `__call__` is deprecated, consider use `callback_on_step_end`",
            )
        if callback_steps is not None:
            deprecate(
                "callback_steps",
                "1.0.0",
                "Passing `callback_steps` as an input argument to `__call__` is deprecated, consider use `callback_on_step_end`",
            )

        # 1. Check inputs. Raise error if not correct
        self.check_inputs(prompt, strength, callback_steps, prompt_embeds, callback_on_step_end_tensor_inputs)
        self._guidance_scale = guidance_scale
        self._clip_skip = clip_skip
        self._cross_attention_kwargs = cross_attention_kwargs

        # 2. Define call parameters
        if prompt is not None and isinstance(prompt, str):
            batch_size = 1
        elif prompt is not None and isinstance(prompt, list):
            batch_size = len(prompt)
        else:
            batch_size = prompt_embeds.shape[0]

        device = self._execution_device
        # do_classifier_free_guidance = guidance_scale > 1.0

        # 3. Encode input prompt
        lora_scale = (
            self.cross_attention_kwargs.get("scale", None) if self.cross_attention_kwargs is not None else None
        )

      
        prompt_embeds, _ = self.encode_prompt(
            prompt,
            device,
            num_images_per_prompt,
            False,
            negative_prompt=None,
            prompt_embeds=prompt_embeds,
            negative_prompt_embeds=None,
            lora_scale=lora_scale,
            clip_skip=self.clip_skip,
        )

        # 4. Encode image
        image = self.image_processor.preprocess(image)

        # 5. Prepare timesteps
        self.scheduler.set_timesteps(
            num_inference_steps, device, original_inference_steps=original_inference_steps, strength=strength
        )
        timesteps = self.scheduler.timesteps

        # 6. Prepare latent variables
        original_inference_steps = (
            original_inference_steps
            if original_inference_steps is not None
            else self.scheduler.config.original_inference_steps
        )
        latent_timestep = timesteps[:1]
        latents = self.prepare_latents(
            image, latent_timestep, batch_size, num_images_per_prompt, prompt_embeds.dtype, device, generator
        )
        bs = batch_size * num_images_per_prompt

        # 6. Get Guidance Scale Embedding
        # NOTE: We use the Imagen CFG formulation that StableVictorPipeline uses rather than the original LCM paper
        # CFG formulation, so we need to subtract 1 from the input guidance_scale.
        # LCM CFG formulation:  cfg_noise = noise_cond + cfg_scale * (noise_cond - noise_uncond), (cfg_scale > 0.0 using CFG)
        w = torch.tensor(self.guidance_scale - 1).repeat(bs)
        w_embedding = self.get_guidance_scale_embedding(w, embedding_dim=self.unet.config.time_cond_proj_dim).to(
            device=device, dtype=latents.dtype
        )

        # 7. Prepare extra step kwargs. TODO: Logic should ideally just be moved out of the pipeline
        extra_step_kwargs = self.prepare_extra_step_kwargs(generator, None)

        # 8. LCM Multistep Sampling Loop
        num_warmup_steps = len(timesteps) - num_inference_steps * self.scheduler.order
        self._num_timesteps = len(timesteps)
        with self.progress_bar(total=num_inference_steps) as progress_bar:
            for i, t in enumerate(timesteps):
                latents = latents.to(prompt_embeds.dtype)

                # model prediction (v-prediction, eps, x)
                model_pred = self.unet(
                    latents,
                    t,
                    timestep_cond=w_embedding,
                    encoder_hidden_states=prompt_embeds,
                    cross_attention_kwargs=self.cross_attention_kwargs,
                    return_dict=False,
                )[0]

                # compute the previous noisy sample x_t -> x_t-1
                latents, denoised = self.scheduler.step(model_pred, t, latents, **extra_step_kwargs, return_dict=False)
                if callback_on_step_end is not None:
                    callback_kwargs = {}
                    for k in callback_on_step_end_tensor_inputs:
                        callback_kwargs[k] = locals()[k]
                    callback_outputs = callback_on_step_end(self, i, t, callback_kwargs)

                    latents = callback_outputs.pop("latents", latents)
                    prompt_embeds = callback_outputs.pop("prompt_embeds", prompt_embeds)
                    w_embedding = callback_outputs.pop("w_embedding", w_embedding)
                    denoised = callback_outputs.pop("denoised", denoised)

                # call the callback, if provided
                if i == len(timesteps) - 1 or ((i + 1) > num_warmup_steps and (i + 1) % self.scheduler.order == 0):
                    progress_bar.update()
                    if callback is not None and i % callback_steps == 0:
                        step_idx = i // getattr(self.scheduler, "order", 1)
                        callback(step_idx, t, latents)

        denoised = denoised.to(prompt_embeds.dtype)
        if not output_type == "latent":
            image = self.vae.decode(denoised / self.vae.config.scaling_factor, return_dict=False)[0]
            image, has_nsfw_concept = self.run_safety_checker(image, device, prompt_embeds.dtype)
        else:
            image = denoised
            has_nsfw_concept = None

        if has_nsfw_concept is None:
            do_denormalize = [True] * image.shape[0]
        else:
            do_denormalize = [not has_nsfw for has_nsfw in has_nsfw_concept]

        image = self.image_processor.postprocess(image, output_type=output_type, do_denormalize=do_denormalize)

        # Offload all models
        self.maybe_free_model_hooks()

        if not return_dict:
            return (image, has_nsfw_concept)

        return StableVictorPipelineOutput(images=image, nsfw_content_detected=has_nsfw_concept)
