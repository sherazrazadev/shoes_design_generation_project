import inspect
from typing import Any, Callable, Dict, List, Optional, Union
import torch
from transformers import CLIPImageProcessor, CLIPTextModel, CLIPTokenizer
from ...image_processor import VaeImageProcessor
from ...loaders import FromSingleFileMixin, LoraLoaderMixin, TextualInversionLoaderMixin
from ...models import AutoencoderKL, UNet2DConditionModel
from ...models.lora import adjust_lora_scale_text_encoder
from ...schedulers import LCMScheduler
from ...utils import (
    USE_PEFT_BACKEND,
    deprecate,
    logging,
    scale_lora_layers,
    unscale_lora_layers,
)
from ...utils.torch_utils import randn_tensor
from ..pipeline_utils import VictorPipeline
from ..stable_victor import StableVictorPipelineOutput, StableVictorSafetyChecker


logger = logging.get_logger(__name__)



class LatentConsistencyModelPipeline(
    VictorPipeline, TextualInversionLoaderMixin, LoraLoaderMixin, FromSingleFileMixin
):
  
    model_cpu_offload_seq = "text_encoder->unet->vae"
    _optional_components = ["safety_checker", "feature_extractor"]
    _exclude_from_cpu_offload = ["safety_checker"]
    _callback_tensor_inputs = ["latents", "denoised", "prompt_embeds", "w_embedding"]

    def __init__(
        self,
        vae: AutoencoderKL,
        text_encoder: CLIPTextModel,
        tokenizer: CLIPTokenizer,
        unet: UNet2DConditionModel,
        scheduler: LCMScheduler,
        safety_checker: StableVictorSafetyChecker,
        feature_extractor: CLIPImageProcessor,
        requires_safety_checker: bool = True,
    ):
        super().__init__()

        if safety_checker is None and requires_safety_checker:
            logger.warning(
                f"You have disabled the safety checker for {self.__class__} by passing `safety_checker=None`. Ensure"
                        )

        if safety_checker is not None and feature_extractor is None:
            raise ValueError(
                "Make sure to define a feature extractor when loading {self.__class__} if you want to use the safety"
            )

        self.register_modules(
            vae=vae,
            text_encoder=text_encoder,
            tokenizer=tokenizer,
            unet=unet,
            scheduler=scheduler,
            safety_checker=safety_checker,
            feature_extractor=feature_extractor,
        )
        self.vae_scale_factor = 2 ** (len(self.vae.config.block_out_channels) - 1)
        self.image_processor = VaeImageProcessor(vae_scale_factor=self.vae_scale_factor)
        self.register_to_config(requires_safety_checker=requires_safety_checker)

    def enable_vae_slicing(self):
       
        self.vae.enable_slicing()

    def disable_vae_slicing(self):
   
        self.vae.disable_slicing()

    def enable_vae_tiling(self):
        r"""
        Enable tiled VAE decoding. When this option is enabled, the VAE will split the input tensor into tiles to
        compute decoding and encoding in several steps. This is useful for saving a large amount of memory and to allow
        processing larger images.
        """
        self.vae.enable_tiling()

    def disable_vae_tiling(self):
        r"""
        Disable tiled VAE decoding. If `enable_vae_tiling` was previously enabled, this method will go back to
        computing decoding in one step.
        """
        self.vae.disable_tiling()

    def enable_freeu(self, s1: float, s2: float, b1: float, b2: float):
      
        if not hasattr(self, "unet"):
            raise ValueError("The pipeline must have `unet` for using FreeU.")
        self.unet.enable_freeu(s1=s1, s2=s2, b1=b1, b2=b2)

    def disable_freeu(self):
        """Disables the FreeU mechanism if enabled."""
        self.unet.disable_freeu()

   

    def encode_prompt(
        self,
        user_prompt,
        user_device,
        user_num_images_per_prompt,
        user_do_classifier_free_guidance,
        user_negative_prompt=None,
        prompt_embeds: Optional[torch.FloatTensor] = None,
        negative_prompt_embeds: Optional[torch.FloatTensor] = None,
        user_lora_scale: Optional[float] = None,
        user_clip_skip: Optional[int] = None,
    ):
       
        if user_lora_scale is not None and isinstance(self, LoraLoaderMixin):
            self._lora_scale = user_lora_scale

            # dynamically adjust the LoRA scale
            if not USE_PEFT_BACKEND:
                adjust_lora_scale_text_encoder(self.text_encoder, user_lora_scale)
            else:
                scale_lora_layers(self.text_encoder, user_lora_scale)

        if user_prompt is not None and isinstance(user_prompt, str):
            batch_size = 1
        elif user_prompt is not None and isinstance(user_prompt, list):
            batch_size = len(user_prompt)
        else:
            batch_size = prompt_embeds.shape[0]

        if prompt_embeds is None:
            if isinstance(self, TextualInversionLoaderMixin):
                user_prompt = self.maybe_convert_prompt(user_prompt, self.tokenizer)

            text_inputs = self.tokenizer(
                user_prompt,
                padding="max_length",
                max_length=self.tokenizer.model_max_length,
                truncation=True,
                return_tensors="pt",
            )
            text_input_ids = text_inputs.input_ids
            untruncated_ids = self.tokenizer(user_prompt, padding="longest", return_tensors="pt").input_ids

            if untruncated_ids.shape[-1] >= text_input_ids.shape[-1] and not torch.equal(
                text_input_ids, untruncated_ids
            ):
                removed_text = self.tokenizer.batch_decode(
                    untruncated_ids[:, self.tokenizer.model_max_length - 1 : -1]
                )
                logger.warning(
                    "The following part of your input was truncated because CLIP can only handle sequences up to"
                    f" {self.tokenizer.model_max_length} tokens: {removed_text}"
                )

            if hasattr(self.text_encoder.config, "use_attention_mask") and self.text_encoder.config.use_attention_mask:
                attention_mask = text_inputs.attention_mask.to(user_device)
            else:
                attention_mask = None

            if user_clip_skip is None:
                prompt_embeds = self.text_encoder(text_input_ids.to(user_device), attention_mask=attention_mask)
                prompt_embeds = prompt_embeds[0]
            else:
                prompt_embeds = self.text_encoder(
                    text_input_ids.to(user_device), attention_mask=attention_mask, output_hidden_states=True
                )
                # Access the `hidden_states` first, that contains a tuple of
               
                # the tuple to access the hidden states from the desired layer.
                prompt_embeds = prompt_embeds[-1][-(user_clip_skip + 1)]
                # We also need to apply the final LayerNorm here to not mess with the
               
                prompt_embeds = self.text_encoder.text_model.final_layer_norm(prompt_embeds)

        if self.text_encoder is not None:
            prompt_embeds_dtype = self.text_encoder.dtype
        elif self.unet is not None:
            prompt_embeds_dtype = self.unet.dtype
        else:
            prompt_embeds_dtype = prompt_embeds.dtype

        prompt_embeds = prompt_embeds.to(dtype=prompt_embeds_dtype, device=user_device)

        bs_embed, seq_len, _ = prompt_embeds.shape
        prompt_embeds = prompt_embeds.repeat(1, user_num_images_per_prompt, 1)
        prompt_embeds = prompt_embeds.view(bs_embed * user_num_images_per_prompt, seq_len, -1)

        if user_do_classifier_free_guidance and negative_prompt_embeds is None:
            uncond_tokens: List[str]
            if user_negative_prompt is None:
                uncond_tokens = [""] * batch_size
            elif user_prompt is not None and type(user_prompt) is not type(user_negative_prompt):
                raise TypeError(
                    f"`negative_prompt` should be the same type to `prompt`, but got {type(user_negative_prompt)} !="
                    f" {type(user_prompt)}."
                )
            elif isinstance(user_negative_prompt, str):
                uncond_tokens = [user_negative_prompt]
            elif batch_size != len(user_negative_prompt):
                raise ValueError(
                    f"`negative_prompt`: {user_negative_prompt} has batch size {len(user_negative_prompt)}, but `prompt`:"
                    f" {user_prompt} has batch size {batch_size}. Please make sure that passed `negative_prompt` matches"
                    " the batch size of `prompt`."
                )
            else:
                uncond_tokens = user_negative_prompt

            # textual inversion: procecss multi-vector tokens if necessary
            if isinstance(self, TextualInversionLoaderMixin):
                uncond_tokens = self.maybe_convert_prompt(uncond_tokens, self.tokenizer)

            max_length = prompt_embeds.shape[1]
            uncond_input = self.tokenizer(
                uncond_tokens,
                padding="max_length",
                max_length=max_length,
                truncation=True,
                return_tensors="pt",
            )

            if hasattr(self.text_encoder.config, "use_attention_mask") and self.text_encoder.config.use_attention_mask:
                attention_mask = uncond_input.attention_mask.to(user_device)
            else:
                attention_mask = None

            negative_prompt_embeds = self.text_encoder(
                uncond_input.input_ids.to(user_device),
                attention_mask=attention_mask,
            )
            negative_prompt_embeds = negative_prompt_embeds[0]

        if user_do_classifier_free_guidance:
            # duplicate unconditional embeddings for each generation per prompt, using mps friendly method
            seq_len = negative_prompt_embeds.shape[1]

            negative_prompt_embeds = negative_prompt_embeds.to(dtype=prompt_embeds_dtype, device=user_device)

            negative_prompt_embeds = negative_prompt_embeds.repeat(1, user_num_images_per_prompt, 1)
            negative_prompt_embeds = negative_prompt_embeds.view(batch_size * user_num_images_per_prompt, seq_len, -1)

        if isinstance(self, LoraLoaderMixin) and USE_PEFT_BACKEND:
            # Retrieve the original scale by scaling back the LoRA layers
            unscale_lora_layers(self.text_encoder, user_lora_scale)

        return prompt_embeds, negative_prompt_embeds


    
    def run_safety_checker(self, user_image, user_device, user_dtype):
        if self.safety_checker is None:
            has_nsfw_concept = None
        else:
            if torch.is_tensor(user_image):
                feature_extractor_input = self.image_processor.postprocess(user_image, output_type="pil")
            else:
                feature_extractor_input = self.image_processor.numpy_to_pil(user_image)
            safety_checker_input = self.feature_extractor(feature_extractor_input, return_tensors="pt").to(user_device)
            user_image, has_nsfw_concept = self.safety_checker(
                images=user_image, clip_input=safety_checker_input.pixel_values.to(user_dtype)
            )
        return user_image, has_nsfw_concept




    def prepare_latents(self, user_batch_size, user_num_channels_latents, user_height, user_width, user_dtype, user_device, user_generator, user_latents=None):
        shape = (user_batch_size, user_num_channels_latents, user_height // self.vae_scale_factor, user_width // self.vae_scale_factor)
        if isinstance(user_generator, list) and len(user_generator) != user_batch_size:
            raise ValueError(
                f"You have passed a list of generators of length {len(user_generator)}, but requested an effective batch"
                f" size of {user_batch_size}. Make sure the batch size matches the length of the generators."
            )

        if user_latents is None:
            user_latents = randn_tensor(shape, generator=user_generator, device=user_device, dtype=user_dtype)
        else:
            user_latents = user_latents.to(user_device)

        # scale the initial noise by the standard deviation required by the scheduler
        user_latents = user_latents * self.scheduler.init_noise_sigma
        return user_latents


    def get_guidance_scale_embedding(self, input_vector, output_dim=512, data_type=torch.float32):
     
        assert len(input_vector.shape) == 1
        input_vector = input_vector * 1000.0

        half_dim = output_dim // 2
        embedding = torch.log(torch.tensor(10000.0)) / (half_dim - 1)
        embedding = torch.exp(torch.arange(half_dim, dtype=data_type) * -embedding)
        embedding = input_vector.to(data_type)[:, None] * embedding[None, :]
        embedding = torch.cat([torch.sin(embedding), torch.cos(embedding)], dim=1)
        if output_dim % 2 == 1:  # zero pad
            embedding = torch.nn.functional.pad(embedding, (0, 1))
        assert embedding.shape == (input_vector.shape[0], output_dim)
        return embedding


    
    def prepare_extra_step_kwargs(self, input_generator, input_eta):
    

        accepts_eta = "eta" in set(inspect.signature(self.scheduler.step).parameters.keys())
        extra_step_kwargs = {}
        if accepts_eta:
            extra_step_kwargs["eta"] = input_eta

        # check if the scheduler accepts input_generator
        accepts_generator = "generator" in set(inspect.signature(self.scheduler.step).parameters.keys())
        if accepts_generator:
            extra_step_kwargs["generator"] = input_generator
        return extra_step_kwargs

 
    def check_inputs(
            self,
            input_prompt: Union[str, List[str]],
            input_height: int,
            input_width: int,
            input_callback_steps: int,
            input_prompt_embeds: Optional[torch.FloatTensor] = None,
            input_callback_on_step_end_tensor_inputs=None,
        ):
        if input_height % 8 != 0 or input_width % 8 != 0:
            raise ValueError(f"`height` and `width` have to be divisible by 8 but are {input_height} and {input_width}.")

        if input_callback_steps is not None and (not isinstance(input_callback_steps, int) or input_callback_steps <= 0):
            raise ValueError(
                f"`callback_steps` has to be a positive integer but is {input_callback_steps} of type"
                f" {type(input_callback_steps)}."
            )

        if input_callback_on_step_end_tensor_inputs is not None and not all(
            k in self._callback_tensor_inputs for k in input_callback_on_step_end_tensor_inputs
        ):
            raise ValueError(
                f"`callback_on_step_end_tensor_inputs` has to be in {self._callback_tensor_inputs}, but found {[k for k in input_callback_on_step_end_tensor_inputs if k not in self._callback_tensor_inputs]}"
            )

        if input_prompt is not None and input_prompt_embeds is not None:
            raise ValueError(
                f"Cannot forward both `prompt`: {input_prompt} and `prompt_embeds`: {input_prompt_embeds}. Please make sure to"
                " only forward one of the two."
            )
        elif input_prompt is None and input_prompt_embeds is None:
            raise ValueError(
                "Provide either `prompt` or `prompt_embeds`. Cannot leave both `prompt` and `prompt_embeds` undefined."
            )
        elif input_prompt is not None and (not isinstance(input_prompt, str) and not isinstance(input_prompt, list)):
            raise ValueError(f"`prompt` has to be of type `str` or `list` but is {type(input_prompt)}")

    @property
    def guidance_scale(self):
        return self._guidance_scale

    @property
    def cross_attention_kwargs(self):
        return self._cross_attention_kwargs

    @property
    def clip_skip(self):
        return self._clip_skip

    @property
    def num_timesteps(self):
        return self._num_timesteps

    @torch.no_grad()
    
    def __call__(
        self,
        prompt: Union[str, List[str]] = None,
        height: Optional[int] = None,
        width: Optional[int] = None,
        num_inference_steps: int = 4,
        original_inference_steps: int = None,
        guidance_scale: float = 8.5,
        num_images_per_prompt: Optional[int] = 1,
        generator: Optional[Union[torch.Generator, List[torch.Generator]]] = None,
        latents: Optional[torch.FloatTensor] = None,
        prompt_embeds: Optional[torch.FloatTensor] = None,
        output_type: Optional[str] = "pil",
        return_dict: bool = True,
        cross_attention_kwargs: Optional[Dict[str, Any]] = None,
        clip_skip: Optional[int] = None,
        callback_on_step_end: Optional[Callable[[int, int, Dict], None]] = None,
        callback_on_step_end_tensor_inputs: List[str] = ["latents"],
        **kwargs,
    ):
       
        callback = kwargs.pop("callback", None)
        callback_steps = kwargs.pop("callback_steps", None)

        if callback is not None:
            deprecate(
                "callback",
                "1.0.0",
                "Passing `callback` as an input argument to `__call__` is deprecated, consider use `callback_on_step_end`",
            )
        if callback_steps is not None:
            deprecate(
                "callback_steps",
                "1.0.0",
                "Passing `callback_steps` as an input argument to `__call__` is deprecated, consider use `callback_on_step_end`",
            )

        # 0. Default height and width to unet
        height = height or self.unet.config.sample_size * self.vae_scale_factor
        width = width or self.unet.config.sample_size * self.vae_scale_factor

        # 1. Check inputs. Raise error if not correct
        self.check_inputs(prompt, height, width, callback_steps, prompt_embeds, callback_on_step_end_tensor_inputs)
        self._guidance_scale = guidance_scale
        self._clip_skip = clip_skip
        self._cross_attention_kwargs = cross_attention_kwargs

        # 2. Define call parameters
        if prompt is not None and isinstance(prompt, str):
            batch_size = 1
        elif prompt is not None and isinstance(prompt, list):
            batch_size = len(prompt)
        else:
            batch_size = prompt_embeds.shape[0]

        device = self._execution_device

        # 3. Encode input prompt
        lora_scale = (
            self.cross_attention_kwargs.get("scale", None) if self.cross_attention_kwargs is not None else None
        )

        prompt_embeds, _ = self.encode_prompt(
            prompt,
            device,
            num_images_per_prompt,
            False,
            negative_prompt=None,
            prompt_embeds=prompt_embeds,
            negative_prompt_embeds=None,
            lora_scale=lora_scale,
            clip_skip=self.clip_skip,
        )

        # 4. Prepare timesteps
        self.scheduler.set_timesteps(num_inference_steps, device, original_inference_steps=original_inference_steps)
        timesteps = self.scheduler.timesteps

        # 5. Prepare latent variable
        num_channels_latents = self.unet.config.in_channels
        latents = self.prepare_latents(
            batch_size * num_images_per_prompt,
            num_channels_latents,
            height,
            width,
            prompt_embeds.dtype,
            device,
            generator,
            latents,
        )
        bs = batch_size * num_images_per_prompt

        # 6. Get Guidance Scale Embedding
        w = torch.tensor(self.guidance_scale - 1).repeat(bs)
        w_embedding = self.get_guidance_scale_embedding(w, embedding_dim=self.unet.config.time_cond_proj_dim).to(
            device=device, dtype=latents.dtype
        )

        # 7. Prepare extra step kwargs. TODO: Logic should ideally just be moved out of the pipeline
        extra_step_kwargs = self.prepare_extra_step_kwargs(generator, None)

        # 8. LCM MultiStep Sampling Loop:
        num_warmup_steps = len(timesteps) - num_inference_steps * self.scheduler.order
        self._num_timesteps = len(timesteps)
        with self.progress_bar(total=num_inference_steps) as progress_bar:
            for i, t in enumerate(timesteps):
                latents = latents.to(prompt_embeds.dtype)

                # model prediction (v-prediction, eps, x)
                model_pred = self.unet(
                    latents,
                    t,
                    timestep_cond=w_embedding,
                    encoder_hidden_states=prompt_embeds,
                    cross_attention_kwargs=self.cross_attention_kwargs,
                    return_dict=False,
                )[0]

                # compute the previous noisy sample x_t -> x_t-1
                latents, denoised = self.scheduler.step(model_pred, t, latents, **extra_step_kwargs, return_dict=False)
                if callback_on_step_end is not None:
                    callback_kwargs = {}
                    for k in callback_on_step_end_tensor_inputs:
                        callback_kwargs[k] = locals()[k]
                    callback_outputs = callback_on_step_end(self, i, t, callback_kwargs)

                    latents = callback_outputs.pop("latents", latents)
                    prompt_embeds = callback_outputs.pop("prompt_embeds", prompt_embeds)
                    w_embedding = callback_outputs.pop("w_embedding", w_embedding)
                    denoised = callback_outputs.pop("denoised", denoised)

                # call the callback, if provided
                if i == len(timesteps) - 1 or ((i + 1) > num_warmup_steps and (i + 1) % self.scheduler.order == 0):
                    progress_bar.update()
                    if callback is not None and i % callback_steps == 0:
                        step_idx = i // getattr(self.scheduler, "order", 1)
                        callback(step_idx, t, latents)

        denoised = denoised.to(prompt_embeds.dtype)
        if not output_type == "latent":
            image = self.vae.decode(denoised / self.vae.config.scaling_factor, return_dict=False)[0]
            image, has_nsfw_concept = self.run_safety_checker(image, device, prompt_embeds.dtype)
        else:
            image = denoised
            has_nsfw_concept = None

        if has_nsfw_concept is None:
            do_denormalize = [True] * image.shape[0]
        else:
            do_denormalize = [not has_nsfw for has_nsfw in has_nsfw_concept]

        image = self.image_processor.postprocess(image, output_type=output_type, do_denormalize=do_denormalize)

        # Offload all models
        self.maybe_free_model_hooks()

        if not return_dict:
            return (image, has_nsfw_concept)

        return StableVictorPipelineOutput(images=image, nsfw_content_detected=has_nsfw_concept)
