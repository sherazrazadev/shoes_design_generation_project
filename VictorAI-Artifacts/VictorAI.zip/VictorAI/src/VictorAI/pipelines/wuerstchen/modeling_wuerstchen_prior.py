import math
from typing import Dict, Union
import torch
import torch.nn as nn
from ...configuration_utils import ConfigMixin, register_to_config
from ...loaders import UNet2DConditionLoadersMixin
from ...models.attention_processor import (
    ADDED_KV_ATTENTION_PROCESSORS,
    CROSS_ATTENTION_PROCESSORS,
    AttentionProcessor,
    AttnAddedKVProcessor,
    AttnProcessor
)
from ...models.lora import LoRACompatibleConv, LoRACompatibleLinear
from ...models.modeling_utils import ModelMixin
from ...utils import USE_PEFT_BACKEND, is_torch_version
from .modeling_wuerstchen_common import AttnBlock, ResBlock, TimestepBlock, WuerstchenLayerNorm


class WuerstchenPrior(ModelMixin, ConfigMixin, UNet2DConditionLoadersMixin):
    unet_name = "prior"
    _supports_gradient_checkpointing = True

    @register_to_config
    def __init__(self, c_in=16, c=1280, c_cond=1024, c_r=64, depth=16, nhead=16, dropout=0.1):
        super().__init__()
        conv_cls = nn.Conv2d if USE_PEFT_BACKEND else LoRACompatibleConv
        linear_cls = nn.Linear if USE_PEFT_BACKEND else LoRACompatibleLinear

        self.c_r = c_r
        self.projection = conv_cls(c_in, c, kernel_size=1)
        self.cond_mapper = nn.Sequential(
            linear_cls(c_cond, c),
            nn.LeakyReLU(0.2),
            linear_cls(c, c),
        )

        self.blocks = nn.ModuleList()
        for _ in range(depth):
            self.blocks.append(ResBlock(c, dropout=dropout))
            self.blocks.append(TimestepBlock(c, c_r))
            self.blocks.append(AttnBlock(c, c, nhead, self_attn=True, dropout=dropout))
        self.out = nn.Sequential(
            WuerstchenLayerNorm(c, elementwise_affine=False, eps=1e-6),
            conv_cls(c, c_in * 2, kernel_size=1),
        )

        self.gradient_checkpointing = False
        self.set_default_attn_processor()

    @property
  
    def attn_processors(self) -> Dict[str, AttentionProcessor]:
        """
        Returns:
            `dict` of attention processors: A dictionary containing all attention processors used in the model with
            indexed by its weight name.
        """
        # set recursively
        all_processors = {}

        def recursive_add_processors(name: str, module: torch.nn.Module, processors: Dict[str, AttentionProcessor]):
            if hasattr(module, "get_processor"):
                processors[f"{name}.processor"] = module.get_processor(return_deprecated_lora=True)

            for sub_name, child in module.named_children():
                recursive_add_processors(f"{name}.{sub_name}", child, processors)

            return processors

        for name, module in self.named_children():
            all_processors = recursive_add_processors(name, module, all_processors)

        return all_processors


   

    def set_attn_processor(
        self, input_processor: Union[AttentionProcessor, Dict[str, AttentionProcessor]], _remove_lora=False
    ):
        
        num_processors = len(self.attn_processors.keys())

        if isinstance(input_processor, dict) and len(input_processor) != num_processors:
            raise ValueError(
                f"A dict of processors was passed, but the number of processors {len(input_processor)} does not match the"
                f" number of attention layers: {num_processors}. Please make sure to pass {num_processors} processor classes."
            )

        def recursive_attn_processor(name: str, module: torch.nn.Module, processor):
            if hasattr(module, "set_processor"):
                if not isinstance(processor, dict):
                    module.set_processor(processor, _remove_lora=_remove_lora)
                else:
                    module.set_processor(processor.pop(f"{name}.processor"), _remove_lora=_remove_lora)

            for sub_name, child in module.named_children():
                recursive_attn_processor(f"{name}.{sub_name}", child, processor)

        for name, module in self.named_children():
            recursive_attn_processor(name, module, input_processor)



    def set_default_attn_processor(self):
        """
        Disables custom attention processors and sets the default attention implementation.
        """
        if all(proc.__class__ in ADDED_KV_ATTENTION_PROCESSORS for proc in self.attn_processors.values()):
            processor = AttnAddedKVProcessor()
        elif all(proc.__class__ in CROSS_ATTENTION_PROCESSORS for proc in self.attn_processors.values()):
            processor = AttnProcessor()
        else:
            raise ValueError(
                f"Cannot call `set_default_attn_processor` when attention processors are of type {next(iter(self.attn_processors.values()))}"
            )

        self.set_attn_processor(processor, _remove_lora=True)

    def _set_gradient_checkpointing(self, module, value=False):
        self.gradient_checkpointing = value


    def gen_r_embedding(self, input_r, max_positions=10000):
        scaled_r = input_r * max_positions
        half_dim = self.c_r // 2
        embedding_factor = math.log(max_positions) / (half_dim - 1)
        embedding_values = torch.arange(half_dim, device=input_r.device).float().mul(-embedding_factor).exp()
        embedding_values = scaled_r[:, None] * embedding_values[None, :]
        embedding_values = torch.cat([embedding_values.sin(), embedding_values.cos()], dim=1)
        if self.c_r % 2 == 1: 
            embedding_values = nn.functional.pad(embedding_values, (0, 1), mode="constant")
        return embedding_values.to(dtype=input_r.dtype)




    def forward(self, input_x, input_r, input_c):
        x_in = input_x
        input_x = self.projection(input_x)
        c_embed = self.cond_mapper(input_c)
        r_embed = self.gen_r_embedding(input_r)

        if self.training and self.gradient_checkpointing:

            def create_custom_forward(module):
                def custom_forward(*inputs):
                    return module(*inputs)

                return custom_forward

            if is_torch_version(">=", "1.11.0"):
                for block in self.blocks:
                    if isinstance(block, AttnBlock):
                        input_x = torch.utils.checkpoint.checkpoint(
                            create_custom_forward(block), input_x, c_embed, use_reentrant=False
                        )
                    elif isinstance(block, TimestepBlock):
                        input_x = torch.utils.checkpoint.checkpoint(
                            create_custom_forward(block), input_x, r_embed, use_reentrant=False
                        )
                    else:
                        input_x = torch.utils.checkpoint.checkpoint(create_custom_forward(block), input_x, use_reentrant=False)
            else:
                for block in self.blocks:
                    if isinstance(block, AttnBlock):
                        input_x = torch.utils.checkpoint.checkpoint(create_custom_forward(block), input_x, c_embed)
                    elif isinstance(block, TimestepBlock):
                        input_x = torch.utils.checkpoint.checkpoint(create_custom_forward(block), input_x, r_embed)
                    else:
                        input_x = torch.utils.checkpoint.checkpoint(create_custom_forward(block), input_x)
        else:
            for block in self.blocks:
                if isinstance(block, AttnBlock):
                    input_x = block(input_x, c_embed)
                elif isinstance(block, TimestepBlock):
                    input_x = block(input_x, r_embed)
                else:
                    input_x = block(input_x)
        a, b = self.out(input_x).chunk(2, dim=1)
        return (x_in - a) / ((1 - b).abs() + 1e-5)

