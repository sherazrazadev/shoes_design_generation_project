from dataclasses import dataclass
from math import ceil
from typing import Callable, Dict, List, Optional, Union
import numpy as np
import torch
from transformers import CLIPTextModel, CLIPTokenizer
from ...loaders import LoraLoaderMixin
from ...schedulers import DDPMWuerstchenScheduler
from ...utils import BaseOutput, deprecate, logging
from ...utils.torch_utils import randn_tensor
from ..pipeline_utils import VictorPipeline
from .modeling_wuerstchen_prior import WuerstchenPrior


logger = logging.get_logger(__name__) 

DEFAULT_STAGE_C_TIMESTEPS = list(np.linspace(1.0, 2 / 3, 20)) + list(np.linspace(2 / 3, 0.0, 11))[1:]




@dataclass
class WuerstchenPriorPipelineOutput(BaseOutput):
   

    image_embeddings: Union[torch.FloatTensor, np.ndarray]


class WuerstchenPriorPipeline(VictorPipeline, LoraLoaderMixin):
   

    unet_name = "prior"
    text_encoder_name = "text_encoder"
    model_cpu_offload_seq = "text_encoder->prior"
    _callback_tensor_inputs = ["latents", "text_encoder_hidden_states", "negative_prompt_embeds"]

    def __init__(
        self,
        tokenizer: CLIPTokenizer,
        text_encoder: CLIPTextModel,
        prior: WuerstchenPrior,
        scheduler: DDPMWuerstchenScheduler,
        latent_mean: float = 42.0,
        latent_std: float = 1.0,
        resolution_multiple: float = 42.67,
    ) -> None:
        super().__init__()
        self.register_modules(
            tokenizer=tokenizer,
            text_encoder=text_encoder,
            prior=prior,
            scheduler=scheduler,
        )
        self.register_to_config(
            latent_mean=latent_mean, latent_std=latent_std, resolution_multiple=resolution_multiple
        )

  

    def prepare_latents(self, target_shape, target_dtype, target_device, target_generator, input_latents, target_scheduler):
       
        if input_latents is None:
            input_latents = randn_tensor(target_shape, generator=target_generator, device=target_device, dtype=target_dtype)
        else:
            if input_latents.shape != target_shape:
                raise ValueError(f"Unexpected input_latents shape, got {input_latents.shape}, expected {target_shape}")
            input_latents = input_latents.to(target_device)

        input_latents = input_latents * target_scheduler.init_noise_sigma
        return input_latents


  

    def encode_prompt(
        self,
        target_device,
        num_samples_per_prompt,
        use_classifier_free_guidance,
        main_prompt=None,
        negative_prompt=None,
        main_prompt_embeddings: Optional[torch.FloatTensor] = None,
        negative_prompt_embeddings: Optional[torch.FloatTensor] = None,
    ):
        if main_prompt is not None and isinstance(main_prompt, str):
            batch_size = 1
        elif main_prompt is not None and isinstance(main_prompt, list):
            batch_size = len(main_prompt)
        else:
            batch_size = main_prompt_embeddings.shape[0]

        if main_prompt_embeddings is None:
            text_inputs = self.tokenizer(
                main_prompt,
                padding="max_length",
                max_length=self.tokenizer.model_max_length,
                truncation=True,
                return_tensors="pt",
            )
            main_text_input_ids = text_inputs.input_ids
            attention_mask = text_inputs.attention_mask

            untruncated_ids = self.tokenizer(main_prompt, padding="longest", return_tensors="pt").input_ids

            if untruncated_ids.shape[-1] >= main_text_input_ids.shape[-1] and not torch.equal(
                main_text_input_ids, untruncated_ids
            ):
                removed_text = self.tokenizer.batch_decode(
                    untruncated_ids[:, self.tokenizer.model_max_length - 1 : -1]
                )
                logger.warning(
                    "The following part of your input was truncated because CLIP can only handle sequences up to"
                    f" {self.tokenizer.model_max_length} tokens: {removed_text}"
                )
                main_text_input_ids = main_text_input_ids[:, : self.tokenizer.model_max_length]
                attention_mask = attention_mask[:, : self.tokenizer.model_max_length]

            text_encoder_output = self.text_encoder(
                main_text_input_ids.to(target_device), attention_mask=attention_mask.to(target_device)
            )
            main_prompt_embeddings = text_encoder_output.last_hidden_state

        main_prompt_embeddings = main_prompt_embeddings.to(dtype=self.text_encoder.dtype, device=target_device)
        main_prompt_embeddings = main_prompt_embeddings.repeat_interleave(num_samples_per_prompt, dim=0)

        if negative_prompt_embeddings is None and use_classifier_free_guidance:
            unconditional_tokens: List[str]
            if negative_prompt is None:
                unconditional_tokens = [""] * batch_size
            elif type(main_prompt) is not type(negative_prompt):
                raise TypeError(
                    f"`negative_prompt` should be the same type as `main_prompt`, but got {type(negative_prompt)} !="
                    f" {type(main_prompt)}."
                )
            elif isinstance(negative_prompt, str):
                unconditional_tokens = [negative_prompt]
            elif batch_size != len(negative_prompt):
                raise ValueError(
                    f"`negative_prompt`: {negative_prompt} has batch size {len(negative_prompt)}, but `main_prompt`:"
                    f" {main_prompt} has batch size {batch_size}. Please make sure that the passed `negative_prompt`"
                    " matches the batch size of `main_prompt`."
                )
            else:
                unconditional_tokens = negative_prompt

            unconditional_input = self.tokenizer(
                unconditional_tokens,
                padding="max_length",
                max_length=self.tokenizer.model_max_length,
                truncation=True,
                return_tensors="pt",
            )
            negative_prompt_embeddings_text_encoder_output = self.text_encoder(
                unconditional_input.input_ids.to(target_device),
                attention_mask=unconditional_input.attention_mask.to(target_device),
            )

            negative_prompt_embeddings = negative_prompt_embeddings_text_encoder_output.last_hidden_state

        if use_classifier_free_guidance:
            sequence_length = negative_prompt_embeddings.shape[1]
            negative_prompt_embeddings = negative_prompt_embeddings.to(dtype=self.text_encoder.dtype, device=target_device)
            negative_prompt_embeddings = negative_prompt_embeddings.repeat(1, num_samples_per_prompt, 1)
            negative_prompt_embeddings = negative_prompt_embeddings.view(
                batch_size * num_samples_per_prompt, sequence_length, -1
            )
            # Done duplicating

        return main_prompt_embeddings, negative_prompt_embeddings


    def check_inputs(
        self,
        main_prompt,
        negative_prompt,
        num_steps_inference,
        use_classifier_free_guidance,
        main_prompt_embeddings=None,
        negative_prompt_embeddings=None,
    ):
        if main_prompt is not None and main_prompt_embeddings is not None:
            raise ValueError(
                f"Cannot forward both `main_prompt`: {main_prompt} and `main_prompt_embeddings`: {main_prompt_embeddings}."
                " Please make sure to only forward one of the two."
            )
        elif main_prompt is None and main_prompt_embeddings is None:
            raise ValueError(
                "Provide either `main_prompt` or `main_prompt_embeddings`. Cannot leave both `main_prompt`"
                " and `main_prompt_embeddings` undefined."
            )
        elif main_prompt is not None and (not isinstance(main_prompt, str) and not isinstance(main_prompt, list)):
            raise ValueError(f"`main_prompt` has to be of type `str` or `list` but is {type(main_prompt)}")

        if negative_prompt is not None and negative_prompt_embeddings is not None:
            raise ValueError(
                f"Cannot forward both `negative_prompt`: {negative_prompt} and `negative_prompt_embeddings`:"
                f" {negative_prompt_embeddings}. Please make sure to only forward one of the two."
            )

        if main_prompt_embeddings is not None and negative_prompt_embeddings is not None:
            if main_prompt_embeddings.shape != negative_prompt_embeddings.shape:
                raise ValueError(
                    "`main_prompt_embeddings` and `negative_prompt_embeddings` must have the same shape when passed directly,"
                    f" but got: `main_prompt_embeddings` {main_prompt_embeddings.shape} != `negative_prompt_embeddings`"
                    f" {negative_prompt_embeddings.shape}."
                )

        if not isinstance(num_steps_inference, int):
            raise TypeError(
                f"'num_steps_inference' must be of type 'int', but got {type(num_steps_inference)}."
                " In case you want to provide explicit timesteps, please use the 'timesteps' argument."
            )

    @property
    def guidance_scale(self):
        return self._guidance_scale

    @property
    def do_classifier_free_guidance(self):
        return self._guidance_scale > 1

    @property
    def num_timesteps(self):
        return self._num_timesteps

    @torch.no_grad()

    def __call__(
        self,
        prompt: Optional[Union[str, List[str]]] = None,
        height: int = 1024,
        width: int = 1024,
        num_inference_steps: int = 60,
        timesteps: List[float] = None,
        guidance_scale: float = 8.0,
        negative_prompt: Optional[Union[str, List[str]]] = None,
        prompt_embeds: Optional[torch.FloatTensor] = None,
        negative_prompt_embeds: Optional[torch.FloatTensor] = None,
        num_images_per_prompt: Optional[int] = 1,
        generator: Optional[Union[torch.Generator, List[torch.Generator]]] = None,
        latents: Optional[torch.FloatTensor] = None,
        output_type: Optional[str] = "pt",
        return_dict: bool = True,
        callback_on_step_end: Optional[Callable[[int, int, Dict], None]] = None,
        callback_on_step_end_tensor_inputs: List[str] = ["latents"],
        **kwargs,
    ):
        

        callback = kwargs.pop("callback", None)
        callback_steps = kwargs.pop("callback_steps", None)

        if callback is not None:
            deprecate(
                "callback",
                "1.0.0",
                "Passing `callback` as an input argument to `__call__` is deprecated, consider use `callback_on_step_end`",
            )
        if callback_steps is not None:
            deprecate(
                "callback_steps",
                "1.0.0",
                "Passing `callback_steps` as an input argument to `__call__` is deprecated, consider use `callback_on_step_end`",
            )

        if callback_on_step_end_tensor_inputs is not None and not all(
            k in self._callback_tensor_inputs for k in callback_on_step_end_tensor_inputs
        ):
            raise ValueError(
                f"`callback_on_step_end_tensor_inputs` has to be in {self._callback_tensor_inputs}, but found {[k for k in callback_on_step_end_tensor_inputs if k not in self._callback_tensor_inputs]}"
            )

        # 0. Define commonly used variables
        device = self._execution_device
        self._guidance_scale = guidance_scale
        if prompt is not None and isinstance(prompt, str):
            batch_size = 1
        elif prompt is not None and isinstance(prompt, list):
            batch_size = len(prompt)
        else:
            batch_size = prompt_embeds.shape[0]

        # 1. Check inputs. Raise error if not correct
        if prompt is not None and not isinstance(prompt, list):
            if isinstance(prompt, str):
                prompt = [prompt]
            else:
                raise TypeError(f"'prompt' must be of type 'list' or 'str', but got {type(prompt)}.")

        if self.do_classifier_free_guidance:
            if negative_prompt is not None and not isinstance(negative_prompt, list):
                if isinstance(negative_prompt, str):
                    negative_prompt = [negative_prompt]
                else:
                    raise TypeError(
                        f"'negative_prompt' must be of type 'list' or 'str', but got {type(negative_prompt)}."
                    )

        self.check_inputs(
            prompt,
            negative_prompt,
            num_inference_steps,
            self.do_classifier_free_guidance,
            prompt_embeds=prompt_embeds,
            negative_prompt_embeds=negative_prompt_embeds,
        )

        # 2. Encode caption
        prompt_embeds, negative_prompt_embeds = self.encode_prompt(
            prompt=prompt,
            device=device,
            num_images_per_prompt=num_images_per_prompt,
            do_classifier_free_guidance=self.do_classifier_free_guidance,
            negative_prompt=negative_prompt,
            prompt_embeds=prompt_embeds,
            negative_prompt_embeds=negative_prompt_embeds,
        )

    
        text_encoder_hidden_states = (
            torch.cat([prompt_embeds, negative_prompt_embeds]) if negative_prompt_embeds is not None else prompt_embeds
        )

        # 3. Determine latent shape of image embeddings
        dtype = text_encoder_hidden_states.dtype
        latent_height = ceil(height / self.config.resolution_multiple)
        latent_width = ceil(width / self.config.resolution_multiple)
        num_channels = self.prior.config.c_in
        effnet_features_shape = (num_images_per_prompt * batch_size, num_channels, latent_height, latent_width)

        # 4. Prepare and set timesteps
        if timesteps is not None:
            self.scheduler.set_timesteps(timesteps=timesteps, device=device)
            timesteps = self.scheduler.timesteps
            num_inference_steps = len(timesteps)
        else:
            self.scheduler.set_timesteps(num_inference_steps, device=device)
            timesteps = self.scheduler.timesteps

        # 5. Prepare latents
        latents = self.prepare_latents(effnet_features_shape, dtype, device, generator, latents, self.scheduler)

        # 6. Run denoising loop
        self._num_timesteps = len(timesteps[:-1])
        for i, t in enumerate(self.progress_bar(timesteps[:-1])):
            ratio = t.expand(latents.size(0)).to(dtype)

            # 7. Denoise image embeddings
            predicted_image_embedding = self.prior(
                torch.cat([latents] * 2) if self.do_classifier_free_guidance else latents,
                r=torch.cat([ratio] * 2) if self.do_classifier_free_guidance else ratio,
                c=text_encoder_hidden_states,
            )

            # 8. Check for classifier free guidance and apply it
            if self.do_classifier_free_guidance:
                predicted_image_embedding_text, predicted_image_embedding_uncond = predicted_image_embedding.chunk(2)
                predicted_image_embedding = torch.lerp(
                    predicted_image_embedding_uncond, predicted_image_embedding_text, self.guidance_scale
                )

            # 9. Renoise latents to next timestep
            latents = self.scheduler.step(
                model_output=predicted_image_embedding,
                timestep=ratio,
                sample=latents,
                generator=generator,
            ).prev_sample

            if callback_on_step_end is not None:
                callback_kwargs = {}
                for k in callback_on_step_end_tensor_inputs:
                    callback_kwargs[k] = locals()[k]
                callback_outputs = callback_on_step_end(self, i, t, callback_kwargs)

                latents = callback_outputs.pop("latents", latents)
                text_encoder_hidden_states = callback_outputs.pop(
                    "text_encoder_hidden_states", text_encoder_hidden_states
                )
                negative_prompt_embeds = callback_outputs.pop("negative_prompt_embeds", negative_prompt_embeds)

            if callback is not None and i % callback_steps == 0:
                step_idx = i // getattr(self.scheduler, "order", 1)
                callback(step_idx, t, latents)

        # 10. Denormalize the latents
        latents = latents * self.config.latent_mean - self.config.latent_std

        # Offload all models
        self.maybe_free_model_hooks()

        if output_type == "np":
            latents = latents.cpu().numpy()

        if not return_dict:
            return (latents,)

        return WuerstchenPriorPipelineOutput(latents)
