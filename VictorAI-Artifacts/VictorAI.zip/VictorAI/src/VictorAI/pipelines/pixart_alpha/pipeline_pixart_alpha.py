import html
import inspect
import re
import urllib.parse as ul
from typing import Callable, List, Optional, Tuple, Union
import torch
import torch.nn.functional as F
from transformers import T5EncoderModel, T5Tokenizer
from ...image_processor import VaeImageProcessor
from ...models import AutoencoderKL, Transformer2DModel
from ...schedulers import DPMSolverMultistepScheduler
from ...utils import (
    BACKENDS_MAPPING,
    deprecate,
    is_bs4_available,
    is_ftfy_available,
    logging,
    
)
from ...utils.torch_utils import randn_tensor
from ..pipeline_utils import VictorPipeline, ImagePipelineOutput


logger = logging.get_logger(__name__) 

if is_bs4_available():
    from bs4 import BeautifulSoup

if is_ftfy_available():
    import ftfy



ASPECT_RATIO_1024_BIN = {
    "0.25": [512.0, 2048.0],
    "0.28": [512.0, 1856.0],
    "0.32": [576.0, 1792.0],
    "0.33": [576.0, 1728.0],
    "0.35": [576.0, 1664.0],
    "0.4": [640.0, 1600.0],
    "0.42": [640.0, 1536.0],
    "0.48": [704.0, 1472.0],
    "0.5": [704.0, 1408.0],
    "0.52": [704.0, 1344.0],
    "0.57": [768.0, 1344.0],
    "0.6": [768.0, 1280.0],
    "0.68": [832.0, 1216.0],
    "0.72": [832.0, 1152.0],
    "0.78": [896.0, 1152.0],
    "0.82": [896.0, 1088.0],
    "0.88": [960.0, 1088.0],
    "0.94": [960.0, 1024.0],
    "1.0": [1024.0, 1024.0],
    "1.07": [1024.0, 960.0],
    "1.13": [1088.0, 960.0],
    "1.21": [1088.0, 896.0],
    "1.29": [1152.0, 896.0],
    "1.38": [1152.0, 832.0],
    "1.46": [1216.0, 832.0],
    "1.67": [1280.0, 768.0],
    "1.75": [1344.0, 768.0],
    "2.0": [1408.0, 704.0],
    "2.09": [1472.0, 704.0],
    "2.4": [1536.0, 640.0],
    "2.5": [1600.0, 640.0],
    "3.0": [1728.0, 576.0],
    "4.0": [2048.0, 512.0],
}


class PixArtAlphaPipeline(VictorPipeline):
  

    bad_punct_regex = re.compile(
        r"["
        + "#®•©™&@·º½¾¿¡§~"
        + r"\)"
        + r"\("
        + r"\]"
        + r"\["
        + r"\}"
        + r"\{"
        + r"\|"
        + "\\"
        + r"\/"
        + r"\*"
        + r"]{1,}"
    )  # noqa

    _optional_components = ["tokenizer", "text_encoder"]
    model_cpu_offload_seq = "text_encoder->transformer->vae"

    def __init__(
        self,
        tokenizer: T5Tokenizer,
        text_encoder: T5EncoderModel,
        vae: AutoencoderKL,
        transformer: Transformer2DModel,
        scheduler: DPMSolverMultistepScheduler,
    ):
        super().__init__()

        self.register_modules(
            tokenizer=tokenizer, text_encoder=text_encoder, vae=vae, transformer=transformer, scheduler=scheduler
        )

        self.vae_scale_factor = 2 ** (len(self.vae.config.block_out_channels) - 1)
        self.image_processor = VaeImageProcessor(vae_scale_factor=self.vae_scale_factor)

   

    def mask_text_embeddings(self, input_embedding, masking_tensor):
        if input_embedding.shape[0] == 1:
            preserved_index = masking_tensor.sum().item()
            return input_embedding[:, :, :preserved_index, :], preserved_index
        else:
            masked_feature = input_embedding * masking_tensor[:, None, :, None]
            return masked_feature, input_embedding.shape[2]

    def encode_prompt(
        self,
        input_prompt: Union[str, List[str]],
        use_classifier_free_guidance: bool = True,
        exclusion_prompt: str = "",
        num_images_per_input_prompt: int = 1,
        execution_device: Optional[torch.device] = None,
        input_prompt_embeddings: Optional[torch.FloatTensor] = None,
        exclusion_prompt_embeddings: Optional[torch.FloatTensor] = None,
        input_prompt_attention_mask: Optional[torch.FloatTensor] = None,
        exclusion_prompt_attention_mask: Optional[torch.FloatTensor] = None,
        sanitize_text: bool = False,
        **kwargs,
    ):
        if "mask_feature" in kwargs:
            deprecation_message = "The use of `mask_feature` is deprecated. It is no longer used in any computation and doesn't affect the end results. It will be removed in a future version."
            deprecate("mask_feature", "1.0.0", deprecation_message, standard_warn=False)

        if execution_device is None:
            execution_device = self._execution_device

        if input_prompt is not None and isinstance(input_prompt, str):
            batch_size = 1
        elif input_prompt is not None and isinstance(input_prompt, list):
            batch_size = len(input_prompt)
        else:
            batch_size = input_prompt_embeddings.shape[0]

        # See Section 3.1. of the paper.
        max_length = 120

        if input_prompt_embeddings is None:
            input_prompt = self._text_preprocessing(input_prompt, clean_caption=sanitize_text)
            text_inputs = self.tokenizer(
                input_prompt,
                padding="max_length",
                max_length=max_length,
                truncation=True,
                add_special_tokens=True,
                return_tensors="pt",
            )
            text_input_ids = text_inputs.input_ids
            untruncated_ids = self.tokenizer(input_prompt, padding="longest", return_tensors="pt").input_ids

            if untruncated_ids.shape[-1] >= text_input_ids.shape[-1] and not torch.equal(text_input_ids, untruncated_ids):
                removed_text = self.tokenizer.batch_decode(untruncated_ids[:, max_length - 1 : -1])
                logger.warning(
                    "The following part of your input was truncated because CLIP can only handle sequences up to"
                    f" {max_length} tokens: {removed_text}"
                )

            input_prompt_attention_mask = text_inputs.attention_mask
            input_prompt_attention_mask = input_prompt_attention_mask.to(execution_device)

            input_prompt_embeddings = self.text_encoder(text_input_ids.to(execution_device), attention_mask=input_prompt_attention_mask)
            input_prompt_embeddings = input_prompt_embeddings[0]

        if self.text_encoder is not None:
            dtype = self.text_encoder.dtype
        elif self.transformer is not None:
            dtype = self.transformer.dtype
        else:
            dtype = None

        input_prompt_embeddings = input_prompt_embeddings.to(dtype=dtype, device=execution_device)

        bs_embed, seq_len, _ = input_prompt_embeddings.shape
        input_prompt_embeddings = input_prompt_embeddings.repeat(1, num_images_per_input_prompt, 1)
        input_prompt_embeddings = input_prompt_embeddings.view(bs_embed * num_images_per_input_prompt, seq_len, -1)
        input_prompt_attention_mask = input_prompt_attention_mask.view(bs_embed, -1)
        input_prompt_attention_mask = input_prompt_attention_mask.repeat(num_images_per_input_prompt, 1)

        if use_classifier_free_guidance and exclusion_prompt_embeddings is None:
            uncond_tokens = [exclusion_prompt] * batch_size
            uncond_tokens = self._text_preprocessing(uncond_tokens, clean_caption=sanitize_text)
            max_length = input_prompt_embeddings.shape[1]
            uncond_input = self.tokenizer(
                uncond_tokens,
                padding="max_length",
                max_length=max_length,
                truncation=True,
                return_attention_mask=True,
                add_special_tokens=True,
                return_tensors="pt",
            )
            exclusion_prompt_attention_mask = uncond_input.attention_mask
            exclusion_prompt_attention_mask = exclusion_prompt_attention_mask.to(execution_device)

            exclusion_prompt_embeddings = self.text_encoder(
                uncond_input.input_ids.to(execution_device), attention_mask=exclusion_prompt_attention_mask
            )
            exclusion_prompt_embeddings = exclusion_prompt_embeddings[0]

        if use_classifier_free_guidance:
            seq_len = exclusion_prompt_embeddings.shape[1]

            exclusion_prompt_embeddings = exclusion_prompt_embeddings.to(dtype=dtype, device=execution_device)

            exclusion_prompt_embeddings = exclusion_prompt_embeddings.repeat(1, num_images_per_input_prompt, 1)
            exclusion_prompt_embeddings = exclusion_prompt_embeddings.view(batch_size * num_images_per_input_prompt, seq_len, -1)

            exclusion_prompt_attention_mask = exclusion_prompt_attention_mask.view(bs_embed, -1)
            exclusion_prompt_attention_mask = exclusion_prompt_attention_mask.repeat(num_images_per_input_prompt, 1)
        else:
            exclusion_prompt_embeddings = None
            exclusion_prompt_attention_mask = None

        return input_prompt_embeddings, input_prompt_attention_mask, exclusion_prompt_embeddings, exclusion_prompt_attention_mask



    def prepare_extra_step_kwargs(self, custom_generator, learning_rate_eta):
        

        accepts_eta = "eta" in set(inspect.signature(self.scheduler.step).parameters.keys())
        extra_step_kwargs = {}
        if accepts_eta:
            extra_step_kwargs["eta"] = learning_rate_eta

        accepts_custom_generator = "generator" in set(inspect.signature(self.scheduler.step).parameters.keys())
        if accepts_custom_generator:
            extra_step_kwargs["generator"] = custom_generator
        return extra_step_kwargs




    def check_inputs(
            self,
            user_prompt,
            image_height,
            image_width,
            user_negative_prompt,
            callback_steps,
            user_prompt_embeddings=None,
            user_negative_prompt_embeddings=None,
            user_prompt_attention_mask=None,
            user_negative_prompt_attention_mask=None,
        ):
            if image_height % 8 != 0 or image_width % 8 != 0:
                raise ValueError(f"`image_height` and `image_width` have to be divisible by 8 but are {image_height} and {image_width}.")

            if (callback_steps is None) or (
                callback_steps is not None and (not isinstance(callback_steps, int) or callback_steps <= 0)
            ):
                raise ValueError(
                    f"`callback_steps` has to be a positive integer but is {callback_steps} of type"
                    f" {type(callback_steps)}."
                )

            if user_prompt is not None and user_prompt_embeddings is not None:
                raise ValueError(
                    f"Cannot forward both `user_prompt`: {user_prompt} and `user_prompt_embeddings`: {user_prompt_embeddings}. Please make sure to"
                    " only forward one of the two."
                )
            elif user_prompt is None and user_prompt_embeddings is None:
                raise ValueError(
                    "Provide either `user_prompt` or `user_prompt_embeddings`. Cannot leave both `user_prompt` and `user_prompt_embeddings` undefined."
                )
            elif user_prompt is not None and (not isinstance(user_prompt, str) and not isinstance(user_prompt, list)):
                raise ValueError(f"`user_prompt` has to be of type `str` or `list` but is {type(user_prompt)}")

            if user_prompt is not None and user_negative_prompt_embeddings is not None:
                raise ValueError(
                    f"Cannot forward both `user_prompt`: {user_prompt} and `user_negative_prompt_embeddings`:"
                    f" {user_negative_prompt_embeddings}. Please make sure to only forward one of the two."
                )

            if user_negative_prompt is not None and user_negative_prompt_embeddings is not None:
                raise ValueError(
                    f"Cannot forward both `user_negative_prompt`: {user_negative_prompt} and `user_negative_prompt_embeddings`:"
                    f" {user_negative_prompt_embeddings}. Please make sure to only forward one of the two."
                )

            if user_prompt_embeddings is not None and user_prompt_attention_mask is None:
                raise ValueError("Must provide `user_prompt_attention_mask` when specifying `user_prompt_embeddings`.")

            if user_negative_prompt_embeddings is not None and user_negative_prompt_attention_mask is None:
                raise ValueError("Must provide `user_negative_prompt_attention_mask` when specifying `user_negative_prompt_embeddings`.")

            if user_prompt_embeddings is not None and user_negative_prompt_embeddings is not None:
                if user_prompt_embeddings.shape != user_negative_prompt_embeddings.shape:
                    raise ValueError(
                        "`user_prompt_embeddings` and `user_negative_prompt_embeddings` must have the same shape when passed directly, but"
                        f" got: `user_prompt_embeddings` {user_prompt_embeddings.shape} != `user_negative_prompt_embeddings`"
                        f" {user_negative_prompt_embeddings.shape}."
                    )
                if user_prompt_attention_mask.shape != user_negative_prompt_attention_mask.shape:
                    raise ValueError(
                        "`user_prompt_attention_mask` and `user_negative_prompt_attention_mask` must have the same shape when passed directly, but"
                        f" got: `user_prompt_attention_mask` {user_prompt_attention_mask.shape} != `user_negative_prompt_attention_mask`"
                        f" {user_negative_prompt_attention_mask.shape}."
                    )

    def _text_preprocessing(self, input_text, perform_cleaning=False):
        if perform_cleaning and not is_bs4_available():
            logger.warn(BACKENDS_MAPPING["bs4"][-1].format("Setting `perform_cleaning=True`"))
            logger.warn("Setting `perform_cleaning` to False...")
            perform_cleaning = False

        if perform_cleaning and not is_ftfy_available():
            logger.warn(BACKENDS_MAPPING["ftfy"][-1].format("Setting `perform_cleaning=True`"))
            logger.warn("Setting `perform_cleaning` to False...")
            perform_cleaning = False

        if not isinstance(input_text, (tuple, list)):
            input_text = [input_text]

        def text_processing(text: str):
            if perform_cleaning:
                text = self._clean_caption(text)
                text = self._clean_caption(text)
            else:
                text = text.lower().strip()
            return text

        return [text_processing(t) for t in input_text]



    def _clean_caption(self, user_caption):
        user_caption = str(user_caption)
        user_caption = ul.unquote_plus(user_caption)
        user_caption = user_caption.strip().lower()
        user_caption = re.sub("<person>", "person", user_caption)

        # URLs:
        user_caption = re.sub(
            r"\b((?:https?:(?:\/{1,3}|[a-zA-Z0-9%])|[a-zA-Z0-9.\-]+[.](?:com|co|ru|net|org|edu|gov|it)[\w/-]*\b\/?(?!@)))",
            "",
            user_caption,
        )
        user_caption = re.sub(
            r"\b((?:www:(?:\/{1,3}|[a-zA-Z0-9%])|[a-zA-Z0-9.\-]+[.](?:com|co|ru|net|org|edu|gov|it)[\w/-]*\b\/?(?!@)))",
            "",
            user_caption,
        )

        # HTML:
        user_caption = BeautifulSoup(user_caption, features="html.parser").text

        # @<nickname>
        user_caption = re.sub(r"@[\w\d]+\b", "", user_caption)

        # CJK characters
        user_caption = re.sub(r"[\u31c0-\u9fff]+", "", user_caption)

        # Dashes:
        user_caption = re.sub(
            r"[\u002D\u058A\u05BE\u1400\u1806\u2010-\u2015\u2E17\u2E1A\u2E3A\u2E3B\u2E40\u301C\u3030\u30A0\uFE31\uFE32\uFE58\uFE63\uFF0D]+",
            "-",
            user_caption,
        )

        # Quotes:
        user_caption = re.sub(r"[`´«»“”¨]", '"', user_caption)
        user_caption = re.sub(r"[‘’]", "'", user_caption)

        # Special characters and patterns:
        user_caption = re.sub(r"&quot;?", "", user_caption)
        user_caption = re.sub(r"&amp", "", user_caption)
        user_caption = re.sub(r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}", " ", user_caption)
        user_caption = re.sub(r"\d:\d\d\s+$", "", user_caption)
        user_caption = re.sub(r"\\n", " ", user_caption)
        user_caption = re.sub(r"#\d{1,3}\b", "", user_caption)
        user_caption = re.sub(r"#\d{5,}\b", "", user_caption)
        user_caption = re.sub(r"\b\d{6,}\b", "", user_caption)
        user_caption = re.sub(r"[\S]+\.(?:png|jpg|jpeg|bmp|webp|eps|pdf|apk|mp4)", "", user_caption)
        user_caption = re.sub(r"[\"\']{2,}", r'"', user_caption)
        user_caption = re.sub(r"[\.]{2,}", r" ", user_caption)
        user_caption = re.sub(self.bad_punct_regex, r" ", user_caption)
        user_caption = re.sub(r"\s+\.\s+", r" ", user_caption)

        # Replace dashes and underscores with spaces if more than 3 occurrences:
        regex2 = re.compile(r"(?:\-|\_)")
        if len(re.findall(regex2, user_caption)) > 3:
            user_caption = re.sub(regex2, " ", user_caption)

        user_caption = ftfy.fix_text(user_caption)
        user_caption = html.unescape(html.unescape(user_caption))

        user_caption = re.sub(r"\b[a-zA-Z]{1,3}\d{3,15}\b", "", user_caption)
        user_caption = re.sub(r"\b[a-zA-Z]+\d+[a-zA-Z]+\b", "", user_caption)
        user_caption = re.sub(r"\b\d+[a-zA-Z]+\d+\b", "", user_caption)

        user_caption = re.sub(r"(worldwide\s+)?(free\s+)?shipping", "", user_caption)
        user_caption = re.sub(r"(free\s)?download(\sfree)?", "", user_caption)
        user_caption = re.sub(r"\bclick\b\s(?:for|on)\s\w+", "", user_caption)
        user_caption = re.sub(r"\b(?:png|jpg|jpeg|bmp|webp|eps|pdf|apk|mp4)(\simage[s]?)?", "", user_caption)
        user_caption = re.sub(r"\bpage\s+\d+\b", "", user_caption)

        user_caption = re.sub(r"\b\d*[a-zA-Z]+\d+[a-zA-Z]+\d+[a-zA-Z\d]*\b", r" ", user_caption)

        user_caption = re.sub(r"\b\d+\.?\d*[xх×]\d+\.?\d*\b", "", user_caption)

        user_caption = re.sub(r"\b\s+\:\s+", r": ", user_caption)
        user_caption = re.sub(r"(\D[,\./])\b", r"\1 ", user_caption)
        user_caption = re.sub(r"\s+", " ", user_caption)

        user_caption.strip()

        user_caption = re.sub(r"^[\"\']([\w\W]+)[\"\']$", r"\1", user_caption)
        user_caption = re.sub(r"^[\'\_,\-\:;]", r"", user_caption)
        user_caption = re.sub(r"[\'\_,\-\:\-\+]$", r"", user_caption)
        user_caption = re.sub(r"^\.\S+$", "", user_caption)

        return user_caption.strip()




    def prepare_latents(self, user_batch_size, user_num_channels_latents, user_height, user_width, user_dtype, user_device, user_generator, user_latents=None):
        user_shape = (user_batch_size, user_num_channels_latents, user_height // self.vae_scale_factor, user_width // self.vae_scale_factor)

        if isinstance(user_generator, list) and len(user_generator) != user_batch_size:
            raise ValueError(
                f"You have passed a list of generators of length {len(user_generator)}, but requested an effective batch"
                f" size of {user_batch_size}. Make sure the batch size matches the length of the generators."
            )

        if user_latents is None:
            user_latents = randn_tensor(user_shape, generator=user_generator, device=user_device, dtype=user_dtype)
        else:
            user_latents = user_latents.to(user_device)

        user_latents = user_latents * self.scheduler.init_noise_sigma
        return user_latents


    @staticmethod
    

    def classify_height_width_bin(user_height: int, user_width: int, user_ratios: dict) -> Tuple[int, int]:
        """Returns binned height and width."""
        aspect_ratio = float(user_height / user_width)
        closest_ratio = min(user_ratios.keys(), key=lambda ratio: abs(float(ratio) - aspect_ratio))
        default_hw = user_ratios[closest_ratio]
        return int(default_hw[0]), int(default_hw[1])

    @staticmethod
   

    def resize_and_crop_tensor(user_samples: torch.Tensor, user_new_width: int, user_new_height: int) -> torch.Tensor:
        orig_height, orig_width = user_samples.shape[2], user_samples.shape[3]

        # Check if resizing is needed
        if orig_height != user_new_height or orig_width != user_new_width:
            ratio = max(user_new_height / orig_height, user_new_width / orig_width)
            resized_width = int(orig_width * ratio)
            resized_height = int(orig_height * ratio)

            # Resize
            user_samples = F.interpolate(
                user_samples, size=(resized_height, resized_width), mode="bilinear", align_corners=False
            )

            # Center Crop
            start_x = (resized_width - user_new_width) // 2
            end_x = start_x + user_new_width
            start_y = (resized_height - user_new_height) // 2
            end_y = start_y + user_new_height
            user_samples = user_samples[:, :, start_y:end_y, start_x:end_x]

        return user_samples



    @torch.no_grad()
    
    def __call__(
        self,
        prompt: Union[str, List[str]] = None,
        negative_prompt: str = "",
        num_inference_steps: int = 20,
        timesteps: List[int] = None,
        guidance_scale: float = 4.5,
        num_images_per_prompt: Optional[int] = 1,
        height: Optional[int] = None,
        width: Optional[int] = None,
        eta: float = 0.0,
        generator: Optional[Union[torch.Generator, List[torch.Generator]]] = None,
        latents: Optional[torch.FloatTensor] = None,
        prompt_embeds: Optional[torch.FloatTensor] = None,
        prompt_attention_mask: Optional[torch.FloatTensor] = None,
        negative_prompt_embeds: Optional[torch.FloatTensor] = None,
        negative_prompt_attention_mask: Optional[torch.FloatTensor] = None,
        output_type: Optional[str] = "pil",
        return_dict: bool = True,
        callback: Optional[Callable[[int, int, torch.FloatTensor], None]] = None,
        callback_steps: int = 1,
        clean_caption: bool = True,
        use_resolution_binning: bool = True,
        **kwargs,
    ) -> Union[ImagePipelineOutput, Tuple]:
       
        if "mask_feature" in kwargs:
            deprecation_message = "The use of `mask_feature` is deprecated. It is no longer used in any computation and that doesn't affect the end results. It will be removed in a future version."
            deprecate("mask_feature", "1.0.0", deprecation_message, standard_warn=False)
        # 1. Check inputs. Raise error if not correct
        height = height or self.transformer.config.sample_size * self.vae_scale_factor
        width = width or self.transformer.config.sample_size * self.vae_scale_factor
        if use_resolution_binning:
            orig_height, orig_width = height, width
            height, width = self.classify_height_width_bin(height, width, ratios=ASPECT_RATIO_1024_BIN)

        self.check_inputs(
            prompt,
            height,
            width,
            negative_prompt,
            callback_steps,
            prompt_embeds,
            negative_prompt_embeds,
            prompt_attention_mask,
            negative_prompt_attention_mask,
        )

        # 2. Default height and width to transformer
        if prompt is not None and isinstance(prompt, str):
            batch_size = 1
        elif prompt is not None and isinstance(prompt, list):
            batch_size = len(prompt)
        else:
            batch_size = prompt_embeds.shape[0]

        device = self._execution_device

        do_classifier_free_guidance = guidance_scale > 1.0

        # 3. Encode input prompt
        (
            prompt_embeds,
            prompt_attention_mask,
            negative_prompt_embeds,
            negative_prompt_attention_mask,
        ) = self.encode_prompt(
            prompt,
            do_classifier_free_guidance,
            negative_prompt=negative_prompt,
            num_images_per_prompt=num_images_per_prompt,
            device=device,
            prompt_embeds=prompt_embeds,
            negative_prompt_embeds=negative_prompt_embeds,
            prompt_attention_mask=prompt_attention_mask,
            negative_prompt_attention_mask=negative_prompt_attention_mask,
            clean_caption=clean_caption,
        )
        if do_classifier_free_guidance:
            prompt_embeds = torch.cat([negative_prompt_embeds, prompt_embeds], dim=0)
            prompt_attention_mask = torch.cat([negative_prompt_attention_mask, prompt_attention_mask], dim=0)

        # 4. Prepare timesteps
        self.scheduler.set_timesteps(num_inference_steps, device=device)
        timesteps = self.scheduler.timesteps

        # 5. Prepare latents.
        latent_channels = self.transformer.config.in_channels
        latents = self.prepare_latents(
            batch_size * num_images_per_prompt,
            latent_channels,
            height,
            width,
            prompt_embeds.dtype,
            device,
            generator,
            latents,
        )

        extra_step_kwargs = self.prepare_extra_step_kwargs(generator, eta)

        # 6.1 Prepare micro-conditions.
        added_cond_kwargs = {"resolution": None, "aspect_ratio": None}
        if self.transformer.config.sample_size == 128:
            resolution = torch.tensor([height, width]).repeat(batch_size * num_images_per_prompt, 1)
            aspect_ratio = torch.tensor([float(height / width)]).repeat(batch_size * num_images_per_prompt, 1)
            resolution = resolution.to(dtype=prompt_embeds.dtype, device=device)
            aspect_ratio = aspect_ratio.to(dtype=prompt_embeds.dtype, device=device)
            added_cond_kwargs = {"resolution": resolution, "aspect_ratio": aspect_ratio}

        # 7. Denoising loop
        num_warmup_steps = max(len(timesteps) - num_inference_steps * self.scheduler.order, 0)

        with self.progress_bar(total=num_inference_steps) as progress_bar:
            for i, t in enumerate(timesteps):
                latent_model_input = torch.cat([latents] * 2) if do_classifier_free_guidance else latents
                latent_model_input = self.scheduler.scale_model_input(latent_model_input, t)

                current_timestep = t
                if not torch.is_tensor(current_timestep):
                    # TODO: this requires sync between CPU and GPU. So try to pass timesteps as tensors if you can
                    # This would be a good case for the `match` statement (Python 3.10+)
                    is_mps = latent_model_input.device.type == "mps"
                    if isinstance(current_timestep, float):
                        dtype = torch.float32 if is_mps else torch.float64
                    else:
                        dtype = torch.int32 if is_mps else torch.int64
                    current_timestep = torch.tensor([current_timestep], dtype=dtype, device=latent_model_input.device)
                elif len(current_timestep.shape) == 0:
                    current_timestep = current_timestep[None].to(latent_model_input.device)
                # broadcast to batch dimension in a way that's compatible with ONNX/Core ML
                current_timestep = current_timestep.expand(latent_model_input.shape[0])

                # predict noise model_output
                noise_pred = self.transformer(
                    latent_model_input,
                    encoder_hidden_states=prompt_embeds,
                    encoder_attention_mask=prompt_attention_mask,
                    timestep=current_timestep,
                    added_cond_kwargs=added_cond_kwargs,
                    return_dict=False,
                )[0]

                # perform guidance
                if do_classifier_free_guidance:
                    noise_pred_uncond, noise_pred_text = noise_pred.chunk(2)
                    noise_pred = noise_pred_uncond + guidance_scale * (noise_pred_text - noise_pred_uncond)

                # learned sigma
                if self.transformer.config.out_channels // 2 == latent_channels:
                    noise_pred = noise_pred.chunk(2, dim=1)[0]
                else:
                    noise_pred = noise_pred

                # compute previous image: x_t -> x_t-1
                latents = self.scheduler.step(noise_pred, t, latents, **extra_step_kwargs, return_dict=False)[0]

                # call the callback, if provided
                if i == len(timesteps) - 1 or ((i + 1) > num_warmup_steps and (i + 1) % self.scheduler.order == 0):
                    progress_bar.update()
                    if callback is not None and i % callback_steps == 0:
                        step_idx = i // getattr(self.scheduler, "order", 1)
                        callback(step_idx, t, latents)

        if not output_type == "latent":
            image = self.vae.decode(latents / self.vae.config.scaling_factor, return_dict=False)[0]
            if use_resolution_binning:
                image = self.resize_and_crop_tensor(image, orig_width, orig_height)
        else:
            image = latents

        if not output_type == "latent":
            image = self.image_processor.postprocess(image, output_type=output_type)

        # Offload all models
        self.maybe_free_model_hooks()

        if not return_dict:
            return (image,)

        return ImagePipelineOutput(images=image)
