import inspect
from typing import Any, Callable, Dict, List, Optional, Tuple, Union
import PIL.Image
import torch
from transformers import CLIPTextModel, CLIPTextModelWithProjection, CLIPTokenizer
from ...image_processor import PipelineImageInput, VaeImageProcessor
from ...loaders import FromSingleFileMixin, StableVictorXLLoraLoaderMixin, TextualInversionLoaderMixin
from ...models import AutoencoderKL, UNet2DConditionModel
from ...models.attention_processor import (
    AttnProcessor2_0,
    LoRAAttnProcessor2_0,
    LoRAXFormersAttnProcessor,
    XFormersAttnProcessor)
from ...models.lora import adjust_lora_scale_text_encoder
from ...schedulers import KarrasVictorSchedulers
from ...utils import (
    USE_PEFT_BACKEND,
    deprecate,
    is_invisible_watermark_available,
    is_torch_xla_available,
    logging,
    scale_lora_layers,
    unscale_lora_layers
)
from ...utils.torch_utils import randn_tensor
from ..pipeline_utils import VictorPipeline
from .pipeline_output import StableVictorXLPipelineOutput


if is_invisible_watermark_available():
    from .watermark import StableVictorXLWatermarker

if is_torch_xla_available():
    import torch_xla.core.xla_model as xm

    XLA_AVAILABLE = True
else:
    XLA_AVAILABLE = False


logger = logging.get_logger(__name__) 





def rescale_noise_cfg(config, predicted_text_noise, rescale_factor=0.0):
    text_std_dev = predicted_text_noise.std(dim=list(range(1, predicted_text_noise.ndim)), keepdim=True)
    config_std_dev = config.std(dim=list(range(1, config.ndim)), keepdim=True)
    
    # Rescale the results from guidance to fix overexposure
    rescaled_predicted_noise = config * (text_std_dev / config_std_dev)
    
    # Mix with the original results from guidance using the rescale factor to avoid "plain looking" images
    config = rescale_factor * rescaled_predicted_noise + (1 - rescale_factor) * config
    
    return config



def retrieve_latents(encoded_output, generative_model):
    if hasattr(encoded_output, "latent_dist"):
        return encoded_output.latent_dist.sample(generative_model)
    elif hasattr(encoded_output, "latents"):
        return encoded_output.latents
    else:
        raise AttributeError("Could not access latents of the provided encoded_output")



class StableVictorXLImg2ImgPipeline(
    VictorPipeline, TextualInversionLoaderMixin, FromSingleFileMixin, StableVictorXLLoraLoaderMixin
):
   

    model_cpu_offload_seq = "text_encoder->text_encoder_2->unet->vae"
    _optional_components = ["tokenizer", "tokenizer_2", "text_encoder", "text_encoder_2"]
    _callback_tensor_inputs = [
        "latents",
        "prompt_embeds",
        "negative_prompt_embeds",
        "add_text_embeds",
        "add_time_ids",
        "negative_pooled_prompt_embeds",
        "add_neg_time_ids",
    ]

    def __init__(
        self,
        vae: AutoencoderKL,
        text_encoder: CLIPTextModel,
        text_encoder_2: CLIPTextModelWithProjection,
        tokenizer: CLIPTokenizer,
        tokenizer_2: CLIPTokenizer,
        unet: UNet2DConditionModel,
        scheduler: KarrasVictorSchedulers,
        requires_aesthetics_score: bool = False,
        force_zeros_for_empty_prompt: bool = True,
        add_watermarker: Optional[bool] = None,
    ):
        super().__init__()

        self.register_modules(
            vae=vae,
            text_encoder=text_encoder,
            text_encoder_2=text_encoder_2,
            tokenizer=tokenizer,
            tokenizer_2=tokenizer_2,
            unet=unet,
            scheduler=scheduler,
        )
        self.register_to_config(force_zeros_for_empty_prompt=force_zeros_for_empty_prompt)
        self.register_to_config(requires_aesthetics_score=requires_aesthetics_score)
        self.vae_scale_factor = 2 ** (len(self.vae.config.block_out_channels) - 1)
        self.image_processor = VaeImageProcessor(vae_scale_factor=self.vae_scale_factor)

        add_watermarker = add_watermarker if add_watermarker is not None else is_invisible_watermark_available()

        if add_watermarker:
            self.watermark = StableVictorXLWatermarker()
        else:
            self.watermark = None

    def enable_vae_slicing(self):
        r"""
        Enable sliced VAE decoding. When this option is enabled, the VAE will split the input tensor in slices to
        compute decoding in several steps. This is useful to save some memory and allow larger batch sizes.
        """
        self.vae.enable_slicing()

    def disable_vae_slicing(self):
        r"""
        Disable sliced VAE decoding. If `enable_vae_slicing` was previously enabled, this method will go back to
        computing decoding in one step.
        """
        self.vae.disable_slicing()

    def enable_vae_tiling(self):
        r"""
        Enable tiled VAE decoding. When this option is enabled, the VAE will split the input tensor into tiles to
        compute decoding and encoding in several steps. This is useful for saving a large amount of memory and to allow
        processing larger images.
        """
        self.vae.enable_tiling()

    def disable_vae_tiling(self):
        r"""
        Disable tiled VAE decoding. If `enable_vae_tiling` was previously enabled, this method will go back to
        computing decoding in one step.
        """
        self.vae.disable_tiling()

    
    def encode_prompt(
            self,
            input_prompt: str,
            input_prompt_2: Optional[str] = None,
            target_device: Optional[torch.device] = None,
            num_images_per_prompt: int = 1,
            use_classifier_free_guidance: bool = True,
            exclusion_prompt: Optional[str] = None,
            exclusion_prompt_2: Optional[str] = None,
            input_prompt_embeddings: Optional[torch.FloatTensor] = None,
            exclusion_prompt_embeddings: Optional[torch.FloatTensor] = None,
            pooled_input_prompt_embeddings: Optional[torch.FloatTensor] = None,
            pooled_exclusion_prompt_embeddings: Optional[torch.FloatTensor] = None,
            scaling_factor: Optional[float] = None,
            skip_layers: Optional[int] = None,
        ):
           
            target_device = target_device or self._execution_device

            # Set the scaling factor for LoRA layers
            if scaling_factor is not None and isinstance(self, StableVictorXLLoraLoaderMixin):
                self._scaling_factor = scaling_factor

                # Dynamically adjust the LoRA scale
                if self.text_encoder is not None:
                    if not USE_PEFT_BACKEND:
                        adjust_lora_scale_text_encoder(self.text_encoder, scaling_factor)
                    else:
                        scale_lora_layers(self.text_encoder, scaling_factor)

                if self.text_encoder_2 is not None:
                    if not USE_PEFT_BACKEND:
                        adjust_lora_scale_text_encoder(self.text_encoder_2, scaling_factor)
                    else:
                        scale_lora_layers(self.text_encoder_2, scaling_factor)

            input_prompt = [input_prompt] if isinstance(input_prompt, str) else input_prompt

            if input_prompt is not None:
                batch_size = len(input_prompt)
            else:
                batch_size = input_prompt_embeddings.shape[0]

            # Define tokenizers and text encoders
            tokenizers = [self.tokenizer, self.tokenizer_2] if self.tokenizer is not None else [self.tokenizer_2]
            text_encoders = (
                [self.text_encoder, self.text_encoder_2] if self.text_encoder is not None else [self.text_encoder_2]
            )

            if input_prompt_embeddings is None:
                input_prompt_2 = input_prompt_2 or input_prompt
                input_prompt_2 = [input_prompt_2] if isinstance(input_prompt_2, str) else input_prompt_2

                # Textual inversion: process multi-vector tokens if necessary
                input_prompt_embeddings_list = []
                prompts = [input_prompt, input_prompt_2]
                for prompt, tokenizer, text_encoder in zip(prompts, tokenizers, text_encoders):
                    if isinstance(self, TextualInversionLoaderMixin):
                        prompt = self.maybe_convert_prompt(prompt, tokenizer)

                    text_inputs = tokenizer(
                        prompt,
                        padding="max_length",
                        max_length=tokenizer.model_max_length,
                        truncation=True,
                        return_tensors="pt",
                    )

                    text_input_ids = text_inputs.input_ids
                    untruncated_ids = tokenizer(prompt, padding="longest", return_tensors="pt").input_ids

                    if untruncated_ids.shape[-1] >= text_input_ids.shape[-1] and not torch.equal(
                        text_input_ids, untruncated_ids
                    ):
                        removed_text = tokenizer.batch_decode(untruncated_ids[:, tokenizer.model_max_length - 1 : -1])
                        logger.warning(
                            "The following part of your input was truncated because CLIP can only handle sequences up to"
                            f" {tokenizer.model_max_length} tokens: {removed_text}"
                        )

                    prompt_embeddings = text_encoder(text_input_ids.to(target_device), output_hidden_states=True)

                    # We are only ALWAYS interested in the pooled output of the final text encoder
                    pooled_input_prompt_embeddings = prompt_embeddings[0]
                    if skip_layers is None:
                        prompt_embeddings = prompt_embeddings.hidden_states[-2]
                    else:
                        # "2" because SDXL always indexes from the penultimate layer.
                        prompt_embeddings = prompt_embeddings.hidden_states[-(skip_layers + 2)]

                    input_prompt_embeddings_list.append(prompt_embeddings)

                input_prompt_embeddings = torch.cat(input_prompt_embeddings_list, dim=-1)

            # Get unconditional embeddings for classifier-free guidance
            zero_out_exclusion_prompt = exclusion_prompt is None and self.config.force_zeros_for_empty_prompt
            if use_classifier_free_guidance and exclusion_prompt_embeddings is None and zero_out_exclusion_prompt:
                exclusion_prompt_embeddings = torch.zeros_like(input_prompt_embeddings)
                pooled_exclusion_prompt_embeddings = torch.zeros_like(pooled_input_prompt_embeddings)
            elif use_classifier_free_guidance and exclusion_prompt_embeddings is None:
                exclusion_prompt = exclusion_prompt or ""
                exclusion_prompt_2 = exclusion_prompt_2 or exclusion_prompt

                # Normalize string to list
                exclusion_prompt = batch_size * [exclusion_prompt] if isinstance(exclusion_prompt, str) else exclusion_prompt
                exclusion_prompt_2 = (
                    batch_size * [exclusion_prompt_2] if isinstance(exclusion_prompt_2, str) else exclusion_prompt_2
                )

                unconditional_tokens: List[str]
                if input_prompt is not None and type(input_prompt) is not type(exclusion_prompt):
                    raise TypeError(
                        f"`exclusion_prompt` should be the same type as `input_prompt`, but got {type(exclusion_prompt)} !="
                        f" {type(input_prompt)}."
                    )
                elif batch_size != len(exclusion_prompt):
                    raise ValueError(
                        f"`exclusion_prompt`: {exclusion_prompt} has batch size {len(exclusion_prompt)}, but `input_prompt`:"
                        f" {input_prompt} has batch size {batch_size}. Please make sure that the passed `exclusion_prompt` matches"
                        " the batch size of `input_prompt`."
                    )
                else:
                    unconditional_tokens = [exclusion_prompt, exclusion_prompt_2]

                exclusion_prompt_embeddings_list = []
                for exclusion_prompt, tokenizer, text_encoder in zip(unconditional_tokens, tokenizers, text_encoders):
                    if isinstance(self, TextualInversionLoaderMixin):
                        exclusion_prompt = self.maybe_convert_prompt(exclusion_prompt, tokenizer)

                    max_length = input_prompt_embeddings.shape[1]
                    unconditional_input = tokenizer(
                        exclusion_prompt,
                        padding="max_length",
                        max_length=max_length,
                        truncation=True,
                        return_tensors="pt",
                    )

                    exclusion_prompt_embeddings = text_encoder(
                        unconditional_input.input_ids.to(target_device),
                        output_hidden_states=True,
                    )
                    # We are only ALWAYS interested in the pooled output of the final text encoder
                    pooled_exclusion_prompt_embeddings = exclusion_prompt_embeddings[0]
                    exclusion_prompt_embeddings = exclusion_prompt_embeddings.hidden_states[-2]

                    exclusion_prompt_embeddings_list.append(exclusion_prompt_embeddings)

                exclusion_prompt_embeddings = torch.cat(exclusion_prompt_embeddings_list, dim=-1)

            if self.text_encoder_2 is not None:
                input_prompt_embeddings = input_prompt_embeddings.to(dtype=self.text_encoder_2.dtype, device=target_device)
            else:
                input_prompt_embeddings = input_prompt_embeddings.to(dtype=self.unet.dtype, device=target_device)

            bs_embed, seq_len, _ = input_prompt_embeddings.shape
            # Duplicate text embeddings for each generation per prompt, using MPS-friendly method
            input_prompt_embeddings = input_prompt_embeddings.repeat(1, num_images_per_prompt, 1)
            input_prompt_embeddings = input_prompt_embeddings.view(bs_embed * num_images_per_prompt, seq_len, -1)

            if use_classifier_free_guidance:
                # Duplicate unconditional embeddings for each generation per prompt, using MPS-friendly method
                seq_len = exclusion_prompt_embeddings.shape[1]

                if self.text_encoder_2 is not None:
                    exclusion_prompt_embeddings = exclusion_prompt_embeddings.to(dtype=self.text_encoder_2.dtype, device=target_device)
                else:
                    exclusion_prompt_embeddings = exclusion_prompt_embeddings.to(dtype=self.unet.dtype, device=target_device)

                exclusion_prompt_embeddings = exclusion_prompt_embeddings.repeat(1, num_images_per_prompt, 1)
                exclusion_prompt_embeddings = exclusion_prompt_embeddings.view(batch_size * num_images_per_prompt, seq_len, -1)

            pooled_input_prompt_embeddings = pooled_input_prompt_embeddings.repeat(1, num_images_per_prompt).view(
                bs_embed * num_images_per_prompt, -1
            )
            if use_classifier_free_guidance:
                pooled_exclusion_prompt_embeddings = pooled_exclusion_prompt_embeddings.repeat(1, num_images_per_prompt).view(
                    bs_embed * num_images_per_prompt, -1
                )

            if self.text_encoder is not None:
                if isinstance(self, StableVictorXLLoraLoaderMixin) and USE_PEFT_BACKEND:
                    # Retrieve the original scale by scaling back the LoRA layers
                    unscale_lora_layers(self.text_encoder, scaling_factor)

            if self.text_encoder_2 is not None:
                if isinstance(self, StableVictorXLLoraLoaderMixin) and USE_PEFT_BACKEND:
                    # Retrieve the original scale by scaling back the LoRA layers
                    unscale_lora_layers(self.text_encoder_2, scaling_factor)

            return input_prompt_embeddings, exclusion_prompt_embeddings, pooled_input_prompt_embeddings, pooled_exclusion_prompt_embeddings




    def prepare_extra_step_kwargs(self, model_generator, learning_rate_scaling):
     
        accepts_learning_rate_scaling = "learning_rate_scaling" in set(inspect.signature(self.scheduler.step).parameters.keys())
        extra_step_kwargs = {}
        
        if accepts_learning_rate_scaling:
            extra_step_kwargs["learning_rate_scaling"] = learning_rate_scaling

        # Check if the scheduler accepts the generator model
        accepts_model_generator = "model_generator" in set(inspect.signature(self.scheduler.step).parameters.keys())
        if accepts_model_generator:
            extra_step_kwargs["model_generator"] = model_generator
            
        return extra_step_kwargs


    def check_inputs(
        self,
        primary_prompt,
        secondary_prompt,
        strength_value,
        num_steps_inference,
        callback_steps,
        negative_primary_prompt=None,
        negative_secondary_prompt=None,
        primary_prompt_embeddings=None,
        negative_primary_prompt_embeddings=None,
        callback_tensor_inputs=None,
    ):
        if strength_value < 0 or strength_value > 1:
            raise ValueError(f"The value of strength should be in [0.0, 1.0], but is {strength_value}")
        if num_steps_inference is None:
            raise ValueError("`num_steps_inference` cannot be None.")
        elif not isinstance(num_steps_inference, int) or num_steps_inference <= 0:
            raise ValueError(
                f"`num_steps_inference` has to be a positive integer, but is {num_steps_inference} of type"
                f" {type(num_steps_inference)}."
            )
        if callback_steps is not None and (not isinstance(callback_steps, int) or callback_steps <= 0):
            raise ValueError(
                f"`callback_steps` has to be a positive integer, but is {callback_steps} of type"
                f" {type(callback_steps)}."
            )

        if callback_tensor_inputs is not None and not all(
            key in self._callback_tensor_inputs for key in callback_tensor_inputs
        ):
            raise ValueError(
                f"`callback_tensor_inputs` has to be in {self._callback_tensor_inputs}, but found"
                f" {[key for key in callback_tensor_inputs if key not in self._callback_tensor_inputs]}"
            )

        if primary_prompt is not None and primary_prompt_embeddings is not None:
            raise ValueError(
                f"Cannot forward both `primary_prompt`: {primary_prompt} and `primary_prompt_embeddings`:"
                f" {primary_prompt_embeddings}. Please make sure to only forward one of the two."
            )
        elif secondary_prompt is not None and primary_prompt_embeddings is not None:
            raise ValueError(
                f"Cannot forward both `secondary_prompt`: {secondary_prompt} and `primary_prompt_embeddings`:"
                f" {primary_prompt_embeddings}. Please make sure to only forward one of the two."
            )
        elif primary_prompt is None and primary_prompt_embeddings is None:
            raise ValueError(
                "Provide either `primary_prompt` or `primary_prompt_embeddings`. Cannot leave both `primary_prompt` and"
                " `primary_prompt_embeddings` undefined."
            )
        elif primary_prompt is not None and (not isinstance(primary_prompt, str) and not isinstance(primary_prompt, list)):
            raise ValueError(f"`primary_prompt` has to be of type `str` or `list`, but is {type(primary_prompt)}")
        elif secondary_prompt is not None and (not isinstance(secondary_prompt, str) and not isinstance(secondary_prompt, list)):
            raise ValueError(f"`secondary_prompt` has to be of type `str` or `list`, but is {type(secondary_prompt)}")

        if negative_primary_prompt is not None and negative_primary_prompt_embeddings is not None:
            raise ValueError(
                f"Cannot forward both `negative_primary_prompt`: {negative_primary_prompt} and `negative_primary_prompt_embeddings`:"
                f" {negative_primary_prompt_embeddings}. Please make sure to only forward one of the two."
            )
        elif negative_secondary_prompt is not None and negative_primary_prompt_embeddings is not None:
            raise ValueError(
                f"Cannot forward both `negative_secondary_prompt`: {negative_secondary_prompt} and `negative_primary_prompt_embeddings`:"
                f" {negative_primary_prompt_embeddings}. Please make sure to only forward one of the two."
            )

        if primary_prompt_embeddings is not None and negative_primary_prompt_embeddings is not None:
            if primary_prompt_embeddings.shape != negative_primary_prompt_embeddings.shape:
                raise ValueError(
                    "`primary_prompt_embeddings` and `negative_primary_prompt_embeddings` must have the same shape when passed directly, but"
                    f" got: `primary_prompt_embeddings` {primary_prompt_embeddings.shape} != `negative_primary_prompt_embeddings`"
                    f" {negative_primary_prompt_embeddings.shape}."
                )


   
    def get_timesteps(self, inference_steps, strength_factor, computational_device, denoising_start_point=None):
        if denoising_start_point is None:
            initial_timestep = min(int(inference_steps * strength_factor), inference_steps)
            start_time = max(inference_steps - initial_timestep, 0)
        else:
            start_time = 0

        timesteps = self.scheduler.timesteps[start_time * self.scheduler.order :]

     
        if denoising_start_point is not None:
            discrete_timestep_cutoff = int(
                round(
                    self.scheduler.config.num_train_timesteps
                    - (denoising_start_point * self.scheduler.config.num_train_timesteps)
                )
            )

            inference_steps = (timesteps < discrete_timestep_cutoff).sum().item()
            if self.scheduler.order == 2 and inference_steps % 2 == 0:
              
                inference_steps = inference_steps + 1

            timesteps = timesteps[-inference_steps:]
            return timesteps, inference_steps

        return timesteps, inference_steps - start_time





    def prepare_latents(
        self, input_image, current_timestep, effective_batch_size, images_per_prompt, data_type, computation_device, generators=None, apply_noise=True
    ):
        if not isinstance(input_image, (torch.Tensor, PIL.Image.Image, list)):
            raise ValueError(f"`input_image` must be of type `torch.Tensor`, `PIL.Image.Image`, or list, but is {type(input_image)}")

        # Offload text encoder if `enable_model_cpu_offload` was enabled
        if hasattr(self, "final_offload_hook") and self.final_offload_hook is not None:
            self.text_encoder_2.to("cpu")
            torch.cuda.empty_cache()

        input_image = input_image.to(device=computation_device, dtype=data_type)

        effective_batch_size = effective_batch_size * images_per_prompt

        if input_image.shape[1] == 4:
            initial_latents = input_image
        else:
            # Ensure the VAE is in float32 mode, as it overflows in float16
            if self.vae.config.force_upcast:
                input_image = input_image.float()
                self.vae.to(dtype=torch.float32)

            if isinstance(generators, list) and len(generators) != effective_batch_size:
                raise ValueError(
                    f"You have passed a list of generators of length {len(generators)}, but requested an effective batch size"
                    f" of {effective_batch_size}. Ensure the batch size matches the length of the generators."
                )
            elif isinstance(generators, list):
                initial_latents = [
                    retrieve_latents(self.vae.encode(input_image[i : i + 1]), generator=generators[i])
                    for i in range(effective_batch_size)
                ]
                initial_latents = torch.cat(initial_latents, dim=0)
            else:
                initial_latents = retrieve_latents(self.vae.encode(input_image), generator=generators)

            if self.vae.config.force_upcast:
                self.vae.to(data_type)

            initial_latents = initial_latents.to(data_type)
            initial_latents = self.vae.config.scaling_factor * initial_latents

        if effective_batch_size > initial_latents.shape[0] and effective_batch_size % initial_latents.shape[0] == 0:
            # Expand initial_latents for the effective_batch_size
            additional_images_per_prompt = effective_batch_size // initial_latents.shape[0]
            initial_latents = torch.cat([initial_latents] * additional_images_per_prompt, dim=0)
        elif effective_batch_size > initial_latents.shape[0] and effective_batch_size % initial_latents.shape[0] != 0:
            raise ValueError(f"Cannot duplicate `input_image` of batch size {initial_latents.shape[0]} to {effective_batch_size} text prompts.")
        else:
            initial_latents = torch.cat([initial_latents], dim=0)

        if apply_noise:
            latent_shape = initial_latents.shape
            noise = randn_tensor(latent_shape, generator=generators, device=computation_device, dtype=data_type)
            # Get latents with added noise
            initial_latents = self.scheduler.add_noise(initial_latents, noise, current_timestep)

        latents = initial_latents

        return latents


   
    def _get_add_time_ids(
        self,
        original_dimensions,
        crop_top_left_coords,
        target_dimensions,
        aesthetics_score,
        negative_aesthetics_score,
        negative_original_dimensions,
        negative_crop_top_left_coords,
        negative_target_dimensions,
        data_type,
        text_encoder_projection_dim=None,
    ):
        if self.config.requires_aesthetics_score:
            add_time_ids = list(original_dimensions + crop_top_left_coords + (aesthetics_score,))
            add_neg_time_ids = list(
                negative_original_dimensions + negative_crop_top_left_coords + (negative_aesthetics_score,)
            )
        else:
            add_time_ids = list(original_dimensions + crop_top_left_coords + target_dimensions)
            add_neg_time_ids = list(
                negative_original_dimensions + negative_crop_top_left_coords + negative_target_dimensions
            )

        passed_add_embed_dim = (
            self.unet.config.additional_time_embed_dim * len(add_time_ids) + text_encoder_projection_dim
        )
        expected_add_embed_dim = self.unet.add_embedding.linear_1.in_features

        if (
            expected_add_embed_dim > passed_add_embed_dim
            and (expected_add_embed_dim - passed_add_embed_dim) == self.unet.config.additional_time_embed_dim
        ):
            raise ValueError(
                f"Model expects an added time embedding vector of length {expected_add_embed_dim}, but a vector of {passed_add_embed_dim} was created. Please make sure to enable `requires_aesthetics_score` with `pipe.register_to_config(requires_aesthetics_score=True)` to ensure that `aesthetics_score` {aesthetics_score} and `negative_aesthetics_score` {negative_aesthetics_score} are correctly used by the model."
            )
        elif (
            expected_add_embed_dim < passed_add_embed_dim
            and (passed_add_embed_dim - expected_add_embed_dim) == self.unet.config.additional_time_embed_dim
        ):
            raise ValueError(
                f"Model expects an added time embedding vector of length {expected_add_embed_dim}, but a vector of {passed_add_embed_dim} was created. Please make sure to disable `requires_aesthetics_score` with `pipe.register_to_config(requires_aesthetics_score=False)` to ensure that `target_dimensions` {target_dimensions} are correctly used by the model."
            )
        elif expected_add_embed_dim != passed_add_embed_dim:
            raise ValueError(
                f"Model expects an added time embedding vector of length {expected_add_embed_dim}, but a vector of {passed_add_embed_dim} was created. The model has an incorrect config. Please check `unet.config.time_embedding_type` and `text_encoder_2.config.projection_dim`."
            )

        add_time_ids = torch.tensor([add_time_ids], dtype=data_type)
        add_neg_time_ids = torch.tensor([add_neg_time_ids], dtype=data_type)

        return add_time_ids, add_neg_time_ids




  

    def upcast_vae(self):
        target_dtype = self.vae.dtype
        self.vae.to(dtype=torch.float32)
        use_torch_2_0_or_xformers = isinstance(
            self.vae.decoder.mid_block.attentions[0].processor,
            (
                AttnProcessor2_0,
                XFormersAttnProcessor,
                LoRAXFormersAttnProcessor,
                LoRAAttnProcessor2_0,
            ),
        )
       
        if use_torch_2_0_or_xformers:
            self.vae.post_quant_conv.to(target_dtype)
            self.vae.decoder.conv_in.to(target_dtype)
            self.vae.decoder.mid_block.to(target_dtype)



   


    def enable_freeu(self, scale_stage1: float, scale_stage2: float, amplify_stage1: float, amplify_stage2: float):
      
        if not hasattr(self, "unet"):
            raise ValueError("The pipeline must have `unet` for using FreeU.")
        self.unet.enable_freeu(scale_stage1=scale_stage1, scale_stage2=scale_stage2, amplify_stage1=amplify_stage1, amplify_stage2=amplify_stage2)

    def disable_freeu(self):
        """Disables the FreeU mechanism if enabled."""
        self.unet.disable_freeu()

    def get_guidance_scale_embedding(self, w, embedding_dim=512, data_type=torch.float32):
     
        assert len(w.shape) == 1
        w = w * 1000.0

        half_dim = embedding_dim // 2
        emb = torch.log(torch.tensor(10000.0)) / (half_dim - 1)
        emb = torch.exp(torch.arange(half_dim, dtype=data_type) * -emb)
        emb = w.to(data_type)[:, None] * emb[None, :]
        emb = torch.cat([torch.sin(emb), torch.cos(emb)], dim=1)
        if embedding_dim % 2 == 1:  # zero pad
            emb = torch.nn.functional.pad(emb, (0, 1))
        assert emb.shape == (w.shape[0], embedding_dim)
        return emb



    @property
    def guidance_scale(self):
        return self._guidance_scale

    @property
    def guidance_rescale(self):
        return self._guidance_rescale

    @property
    def clip_skip(self):
        return self._clip_skip

    
    @property
    def do_classifier_free_guidance(self):
        return self._guidance_scale > 1 and self.unet.config.time_cond_proj_dim is None

    @property
    def cross_attention_kwargs(self):
        return self._cross_attention_kwargs

    @property
    def denoising_end(self):
        return self._denoising_end

    @property
    def denoising_start(self):
        return self._denoising_start

    @property
    def num_timesteps(self):
        return self._num_timesteps

    @torch.no_grad()
    
    def __call__(
        self,
        prompt: Union[str, List[str]] = None,
        prompt_2: Optional[Union[str, List[str]]] = None,
        image: PipelineImageInput = None,
        strength: float = 0.3,
        num_inference_steps: int = 50,
        denoising_start: Optional[float] = None,
        denoising_end: Optional[float] = None,
        guidance_scale: float = 5.0,
        negative_prompt: Optional[Union[str, List[str]]] = None,
        negative_prompt_2: Optional[Union[str, List[str]]] = None,
        num_images_per_prompt: Optional[int] = 1,
        eta: float = 0.0,
        generator: Optional[Union[torch.Generator, List[torch.Generator]]] = None,
        latents: Optional[torch.FloatTensor] = None,
        prompt_embeds: Optional[torch.FloatTensor] = None,
        negative_prompt_embeds: Optional[torch.FloatTensor] = None,
        pooled_prompt_embeds: Optional[torch.FloatTensor] = None,
        negative_pooled_prompt_embeds: Optional[torch.FloatTensor] = None,
        output_type: Optional[str] = "pil",
        return_dict: bool = True,
        cross_attention_kwargs: Optional[Dict[str, Any]] = None,
        guidance_rescale: float = 0.0,
        original_size: Tuple[int, int] = None,
        crops_coords_top_left: Tuple[int, int] = (0, 0),
        target_size: Tuple[int, int] = None,
        negative_original_size: Optional[Tuple[int, int]] = None,
        negative_crops_coords_top_left: Tuple[int, int] = (0, 0),
        negative_target_size: Optional[Tuple[int, int]] = None,
        aesthetic_score: float = 6.0,
        negative_aesthetic_score: float = 2.5,
        clip_skip: Optional[int] = None,
        callback_on_step_end: Optional[Callable[[int, int, Dict], None]] = None,
        callback_on_step_end_tensor_inputs: List[str] = ["latents"],
        **kwargs,
    ):
       

        callback = kwargs.pop("callback", None)
        callback_steps = kwargs.pop("callback_steps", None)

        if callback is not None:
            deprecate(
                "callback",
                "1.0.0",
                "Passing `callback` as an input argument to `__call__` is deprecated, consider use `callback_on_step_end`",
            )
        if callback_steps is not None:
            deprecate(
                "callback_steps",
                "1.0.0",
                "Passing `callback_steps` as an input argument to `__call__` is deprecated, consider use `callback_on_step_end`",
            )

        self.check_inputs(
            prompt,
            prompt_2,
            strength,
            num_inference_steps,
            callback_steps,
            negative_prompt,
            negative_prompt_2,
            prompt_embeds,
            negative_prompt_embeds,
            callback_on_step_end_tensor_inputs,
        )

        self._guidance_scale = guidance_scale
        self._guidance_rescale = guidance_rescale
        self._clip_skip = clip_skip
        self._cross_attention_kwargs = cross_attention_kwargs
        self._denoising_end = denoising_end
        self._denoising_start = denoising_start

        # 2. Define call parameters
        if prompt is not None and isinstance(prompt, str):
            batch_size = 1
        elif prompt is not None and isinstance(prompt, list):
            batch_size = len(prompt)
        else:
            batch_size = prompt_embeds.shape[0]

        device = self._execution_device

        # 3. Encode input prompt
        text_encoder_lora_scale = (
            self.cross_attention_kwargs.get("scale", None) if self.cross_attention_kwargs is not None else None
        )
        (
            prompt_embeds,
            negative_prompt_embeds,
            pooled_prompt_embeds,
            negative_pooled_prompt_embeds,
        ) = self.encode_prompt(
            prompt=prompt,
            prompt_2=prompt_2,
            device=device,
            num_images_per_prompt=num_images_per_prompt,
            do_classifier_free_guidance=self.do_classifier_free_guidance,
            negative_prompt=negative_prompt,
            negative_prompt_2=negative_prompt_2,
            prompt_embeds=prompt_embeds,
            negative_prompt_embeds=negative_prompt_embeds,
            pooled_prompt_embeds=pooled_prompt_embeds,
            negative_pooled_prompt_embeds=negative_pooled_prompt_embeds,
            lora_scale=text_encoder_lora_scale,
            clip_skip=self.clip_skip,
        )

        # 4. Preprocess image
        image = self.image_processor.preprocess(image)

        # 5. Prepare timesteps
        def denoising_value_valid(dnv):
            return isinstance(self.denoising_end, float) and 0 < dnv < 1

        self.scheduler.set_timesteps(num_inference_steps, device=device)
        timesteps, num_inference_steps = self.get_timesteps(
            num_inference_steps,
            strength,
            device,
            denoising_start=self.denoising_start if denoising_value_valid else None,
        )
        latent_timestep = timesteps[:1].repeat(batch_size * num_images_per_prompt)

        add_noise = True if self.denoising_start is None else False
        # 6. Prepare latent variables
        latents = self.prepare_latents(
            image,
            latent_timestep,
            batch_size,
            num_images_per_prompt,
            prompt_embeds.dtype,
            device,
            generator,
            add_noise,
        )
        # 7. Prepare extra step kwargs.
        extra_step_kwargs = self.prepare_extra_step_kwargs(generator, eta)

        height, width = latents.shape[-2:]
        height = height * self.vae_scale_factor
        width = width * self.vae_scale_factor

        original_size = original_size or (height, width)
        target_size = target_size or (height, width)

        # 8. Prepare added time ids & embeddings
        if negative_original_size is None:
            negative_original_size = original_size
        if negative_target_size is None:
            negative_target_size = target_size

        add_text_embeds = pooled_prompt_embeds
        if self.text_encoder_2 is None:
            text_encoder_projection_dim = int(pooled_prompt_embeds.shape[-1])
        else:
            text_encoder_projection_dim = self.text_encoder_2.config.projection_dim

        add_time_ids, add_neg_time_ids = self._get_add_time_ids(
            original_size,
            crops_coords_top_left,
            target_size,
            aesthetic_score,
            negative_aesthetic_score,
            negative_original_size,
            negative_crops_coords_top_left,
            negative_target_size,
            dtype=prompt_embeds.dtype,
            text_encoder_projection_dim=text_encoder_projection_dim,
        )
        add_time_ids = add_time_ids.repeat(batch_size * num_images_per_prompt, 1)

        if self.do_classifier_free_guidance:
            prompt_embeds = torch.cat([negative_prompt_embeds, prompt_embeds], dim=0)
            add_text_embeds = torch.cat([negative_pooled_prompt_embeds, add_text_embeds], dim=0)
            add_neg_time_ids = add_neg_time_ids.repeat(batch_size * num_images_per_prompt, 1)
            add_time_ids = torch.cat([add_neg_time_ids, add_time_ids], dim=0)

        prompt_embeds = prompt_embeds.to(device)
        add_text_embeds = add_text_embeds.to(device)
        add_time_ids = add_time_ids.to(device)

        # 9. Denoising loop
        num_warmup_steps = max(len(timesteps) - num_inference_steps * self.scheduler.order, 0)

        if (
            self.denoising_end is not None
            and self.denoising_start is not None
            and denoising_value_valid(self.denoising_end)
            and denoising_value_valid(self.denoising_start)
            and self.denoising_start >= self.denoising_end
        ):
            raise ValueError(
                f"`denoising_start`: {self.denoising_start} cannot be larger than or equal to `denoising_end`: "
                + f" {self.denoising_end} when using type float."
            )
        elif self.denoising_end is not None and denoising_value_valid(self.denoising_end):
            discrete_timestep_cutoff = int(
                round(
                    self.scheduler.config.num_train_timesteps
                    - (self.denoising_end * self.scheduler.config.num_train_timesteps)
                )
            )
            num_inference_steps = len(list(filter(lambda ts: ts >= discrete_timestep_cutoff, timesteps)))
            timesteps = timesteps[:num_inference_steps]

        # 9.2 Optionally get Guidance Scale Embedding
        timestep_cond = None
        if self.unet.config.time_cond_proj_dim is not None:
            guidance_scale_tensor = torch.tensor(self.guidance_scale - 1).repeat(batch_size * num_images_per_prompt)
            timestep_cond = self.get_guidance_scale_embedding(
                guidance_scale_tensor, embedding_dim=self.unet.config.time_cond_proj_dim
            ).to(device=device, dtype=latents.dtype)

        self._num_timesteps = len(timesteps)
        with self.progress_bar(total=num_inference_steps) as progress_bar:
            for i, t in enumerate(timesteps):
                latent_model_input = torch.cat([latents] * 2) if self.do_classifier_free_guidance else latents

                latent_model_input = self.scheduler.scale_model_input(latent_model_input, t)

                # predict the noise residual
                added_cond_kwargs = {"text_embeds": add_text_embeds, "time_ids": add_time_ids}
                noise_pred = self.unet(
                    latent_model_input,
                    t,
                    encoder_hidden_states=prompt_embeds,
                    timestep_cond=timestep_cond,
                    cross_attention_kwargs=self.cross_attention_kwargs,
                    added_cond_kwargs=added_cond_kwargs,
                    return_dict=False,
                )[0]

                # perform guidance
                if self.do_classifier_free_guidance:
                    noise_pred_uncond, noise_pred_text = noise_pred.chunk(2)
                    noise_pred = noise_pred_uncond + self.guidance_scale * (noise_pred_text - noise_pred_uncond)

                if self.do_classifier_free_guidance and self.guidance_rescale > 0.0:
                    noise_pred = rescale_noise_cfg(noise_pred, noise_pred_text, guidance_rescale=self.guidance_rescale)

                # compute the previous noisy sample x_t -> x_t-1
                latents = self.scheduler.step(noise_pred, t, latents, **extra_step_kwargs, return_dict=False)[0]

                if callback_on_step_end is not None:
                    callback_kwargs = {}
                    for k in callback_on_step_end_tensor_inputs:
                        callback_kwargs[k] = locals()[k]
                    callback_outputs = callback_on_step_end(self, i, t, callback_kwargs)

                    latents = callback_outputs.pop("latents", latents)
                    prompt_embeds = callback_outputs.pop("prompt_embeds", prompt_embeds)
                    negative_prompt_embeds = callback_outputs.pop("negative_prompt_embeds", negative_prompt_embeds)
                    add_text_embeds = callback_outputs.pop("add_text_embeds", add_text_embeds)
                    negative_pooled_prompt_embeds = callback_outputs.pop(
                        "negative_pooled_prompt_embeds", negative_pooled_prompt_embeds
                    )
                    add_time_ids = callback_outputs.pop("add_time_ids", add_time_ids)
                    add_neg_time_ids = callback_outputs.pop("add_neg_time_ids", add_neg_time_ids)

                if i == len(timesteps) - 1 or ((i + 1) > num_warmup_steps and (i + 1) % self.scheduler.order == 0):
                    progress_bar.update()
                    if callback is not None and i % callback_steps == 0:
                        step_idx = i // getattr(self.scheduler, "order", 1)
                        callback(step_idx, t, latents)

                if XLA_AVAILABLE:
                    xm.mark_step()

        if not output_type == "latent":
            # make sure the VAE is in float32 mode, as it overflows in float16
            needs_upcasting = self.vae.dtype == torch.float16 and self.vae.config.force_upcast

            if needs_upcasting:
                self.upcast_vae()
                latents = latents.to(next(iter(self.vae.post_quant_conv.parameters())).dtype)

            image = self.vae.decode(latents / self.vae.config.scaling_factor, return_dict=False)[0]

            # cast back to fp16 if needed
            if needs_upcasting:
                self.vae.to(dtype=torch.float16)
        else:
            image = latents
            return StableVictorXLPipelineOutput(images=image)

        # apply watermark if available
        if self.watermark is not None:
            image = self.watermark.apply_watermark(image)

        image = self.image_processor.postprocess(image, output_type=output_type)

        # Offload all models
        self.maybe_free_model_hooks()

        if not return_dict:
            return (image,)

        return StableVictorXLPipelineOutput(images=image)
