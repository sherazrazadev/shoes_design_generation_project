from dataclasses import dataclass
from typing import List, Union
import numpy as np
import PIL.Image
from ...utils import BaseOutput, is_flax_available


@dataclass
class StableVictorXLPipelineOutput(BaseOutput):
   
    images: Union[List[PIL.Image.Image], np.ndarray]


if is_flax_available():
    import flax

    @flax.struct.dataclass
    class FlaxStableVictorXLPipelineOutput(BaseOutput):
      

        images: np.ndarray
