import inspect
from typing import Any, Callable, Dict, List, Optional, Tuple, Union
import torch
from transformers import CLIPTextModel, CLIPTextModelWithProjection, CLIPTokenizer
from ...image_processor import VaeImageProcessor
from ...loaders import (
    FromSingleFileMixin,
    StableVictorXLLoraLoaderMixin,
    TextualInversionLoaderMixin
)
from ...models import AutoencoderKL, UNet2DConditionModel
from ...models.attention_processor import (
    AttnProcessor2_0,
    LoRAAttnProcessor2_0,
    LoRAXFormersAttnProcessor,
    XFormersAttnProcessor
)
from ...models.lora import adjust_lora_scale_text_encoder
from ...schedulers import KarrasVictorSchedulers
from ...utils import (
    USE_PEFT_BACKEND,
    deprecate,
    is_invisible_watermark_available,
    is_torch_xla_available,
    logging,
    scale_lora_layers,
    unscale_lora_layers
)
from ...utils.torch_utils import randn_tensor
from ..pipeline_utils import VictorPipeline
from .pipeline_output import StableVictorXLPipelineOutput
if is_invisible_watermark_available():
    from .watermark import StableVictorXLWatermarker

if is_torch_xla_available():
    import torch_xla.core.xla_model as xm

    XLA_AVAILABLE = True
else:
    XLA_AVAILABLE = False


logger = logging.get_logger(__name__)




def rescale_noise_cfg(input_noise, input_noise_text, scaling_factor=0.0):
    std_text = input_noise_text.std(dim=list(range(1, input_noise_text.ndim)), keepdim=True)
    std_cfg = input_noise.std(dim=list(range(1, input_noise.ndim)), keepdim=True)
    noise_text_rescaled = input_noise * (std_text / std_cfg)
    input_noise = scaling_factor * noise_text_rescaled + (1 - scaling_factor) * input_noise
    return input_noise




class StableVictorXLPipeline(
    VictorPipeline, FromSingleFileMixin, StableVictorXLLoraLoaderMixin, TextualInversionLoaderMixin
):
   

    model_cpu_offload_seq = "text_encoder->text_encoder_2->unet->vae"
    _optional_components = ["tokenizer", "tokenizer_2", "text_encoder", "text_encoder_2"]
    _callback_tensor_inputs = [
        "latents",
        "prompt_embeds",
        "negative_prompt_embeds",
        "add_text_embeds",
        "add_time_ids",
        "negative_pooled_prompt_embeds",
        "negative_add_time_ids",
    ]

    def __init__(
        self,
        vae: AutoencoderKL,
        text_encoder: CLIPTextModel,
        text_encoder_2: CLIPTextModelWithProjection,
        tokenizer: CLIPTokenizer,
        tokenizer_2: CLIPTokenizer,
        unet: UNet2DConditionModel,
        scheduler: KarrasVictorSchedulers,
        force_zeros_for_empty_prompt: bool = True,
        add_watermarker: Optional[bool] = None,
    ):
        super().__init__()

        self.register_modules(
            vae=vae,
            text_encoder=text_encoder,
            text_encoder_2=text_encoder_2,
            tokenizer=tokenizer,
            tokenizer_2=tokenizer_2,
            unet=unet,
            scheduler=scheduler,
        )
        self.register_to_config(force_zeros_for_empty_prompt=force_zeros_for_empty_prompt)
        self.vae_scale_factor = 2 ** (len(self.vae.config.block_out_channels) - 1)
        self.image_processor = VaeImageProcessor(vae_scale_factor=self.vae_scale_factor)

        self.default_sample_size = self.unet.config.sample_size

        add_watermarker = add_watermarker if add_watermarker is not None else is_invisible_watermark_available()

        if add_watermarker:
            self.watermark = StableVictorXLWatermarker()
        else:
            self.watermark = None

    def enable_vae_slicing(self):
        r"""
        Enable sliced VAE decoding. When this option is enabled, the VAE will split the input tensor in slices to
        compute decoding in several steps. This is useful to save some memory and allow larger batch sizes.
        """
        self.vae.enable_slicing()

    def disable_vae_slicing(self):
        r"""
        Disable sliced VAE decoding. If `enable_vae_slicing` was previously enabled, this method will go back to
        computing decoding in one step.
        """
        self.vae.disable_slicing()

    def enable_vae_tiling(self):
        r"""
        Enable tiled VAE decoding. When this option is enabled, the VAE will split the input tensor into tiles to
        compute decoding and encoding in several steps. This is useful for saving a large amount of memory and to allow
        processing larger images.
        """
        self.vae.enable_tiling()

    def disable_vae_tiling(self):
        r"""
        Disable tiled VAE decoding. If `enable_vae_tiling` was previously enabled, this method will go back to
        computing decoding in one step.
        """
        self.vae.disable_tiling()

   
    def encode_prompt(
            self,
            input_prompt: str,
            input_prompt_2: Optional[str] = None,
            input_device: Optional[torch.device] = None,
            input_num_images_per_prompt: int = 1,
            input_do_classifier_free_guidance: bool = True,
            input_negative_prompt: Optional[str] = None,
            input_negative_prompt_2: Optional[str] = None,
            input_prompt_embeds: Optional[torch.FloatTensor] = None,
            input_negative_prompt_embeds: Optional[torch.FloatTensor] = None,
            input_pooled_prompt_embeds: Optional[torch.FloatTensor] = None,
            input_negative_pooled_prompt_embeds: Optional[torch.FloatTensor] = None,
            input_lora_scale: Optional[float] = None,
            input_clip_skip: Optional[int] = None,
        ):
           
            input_device = input_device or self._execution_device

            
            if input_lora_scale is not None and isinstance(self, StableVictorXLLoraLoaderMixin):
                self._lora_scale = input_lora_scale

                # dynamically adjust the LoRA scale
                if self.text_encoder is not None:
                    if not USE_PEFT_BACKEND:
                        adjust_lora_scale_text_encoder(self.text_encoder, input_lora_scale)
                    else:
                        scale_lora_layers(self.text_encoder, input_lora_scale)

                if self.text_encoder_2 is not None:
                    if not USE_PEFT_BACKEND:
                        adjust_lora_scale_text_encoder(self.text_encoder_2, input_lora_scale)
                    else:
                        scale_lora_layers(self.text_encoder_2, input_lora_scale)

            input_prompt = [input_prompt] if isinstance(input_prompt, str) else input_prompt

            if input_prompt is not None:
                batch_size = len(input_prompt)
            else:
                batch_size = input_prompt_embeds.shape[0]

            # Define tokenizers and text encoders
            tokenizers = [self.tokenizer, self.tokenizer_2] if self.tokenizer is not None else [self.tokenizer_2]
            text_encoders = (
                [self.text_encoder, self.text_encoder_2] if self.text_encoder is not None else [self.text_encoder_2]
            )

            if input_prompt_embeds is None:
                input_prompt_2 = input_prompt_2 or input_prompt
                input_prompt_2 = [input_prompt_2] if isinstance(input_prompt_2, str) else input_prompt_2

                # textual inversion: procecss multi-vector tokens if necessary
                prompt_embeds_list = []
                prompts = [input_prompt, input_prompt_2]
                for prompt, tokenizer, text_encoder in zip(prompts, tokenizers, text_encoders):
                    if isinstance(self, TextualInversionLoaderMixin):
                        prompt = self.maybe_convert_prompt(prompt, tokenizer)

                    text_inputs = tokenizer(
                        prompt,
                        padding="max_length",
                        max_length=tokenizer.model_max_length,
                        truncation=True,
                        return_tensors="pt",
                    )

                    text_input_ids = text_inputs.input_ids
                    untruncated_ids = tokenizer(prompt, padding="longest", return_tensors="pt").input_ids

                    if untruncated_ids.shape[-1] >= text_input_ids.shape[-1] and not torch.equal(
                        text_input_ids, untruncated_ids
                    ):
                        removed_text = tokenizer.batch_decode(untruncated_ids[:, tokenizer.model_max_length - 1 : -1])
                        logger.warning(
                            "The following part of your input was truncated because CLIP can only handle sequences up to"
                            f" {tokenizer.model_max_length} tokens: {removed_text}"
                        )

                    prompt_embeds = text_encoder(text_input_ids.to(input_device), output_hidden_states=True)

                    # We are only ALWAYS interested in the pooled output of the final text encoder
                    pooled_prompt_embeds = prompt_embeds[0]
                    if input_clip_skip is None:
                        prompt_embeds = prompt_embeds.hidden_states[-2]
                    else:
                        # "2" because SDXL always indexes from the penultimate layer.
                        prompt_embeds = prompt_embeds.hidden_states[-(input_clip_skip + 2)]

                    prompt_embeds_list.append(prompt_embeds)

                input_prompt_embeds = torch.concat(prompt_embeds_list, dim=-1)

            # get unconditional embeddings for classifier free guidance
            zero_out_negative_prompt = input_negative_prompt is None and self.config.force_zeros_for_empty_prompt
            if input_do_classifier_free_guidance and input_negative_prompt_embeds is None and zero_out_negative_prompt:
                input_negative_prompt_embeds = torch.zeros_like(input_prompt_embeds)
                input_negative_pooled_prompt_embeds = torch.zeros_like(pooled_prompt_embeds)
            elif input_do_classifier_free_guidance and input_negative_prompt_embeds is None:
                input_negative_prompt = input_negative_prompt or ""
                input_negative_prompt_2 = input_negative_prompt_2 or input_negative_prompt

                # normalize str to list
                input_negative_prompt = batch_size * [input_negative_prompt] if isinstance(input_negative_prompt, str) else input_negative_prompt
                input_negative_prompt_2 = (
                    batch_size * [input_negative_prompt_2] if isinstance(input_negative_prompt_2, str) else input_negative_prompt_2
                )

                uncond_tokens: List[str]
                if input_prompt is not None and type(input_prompt) is not type(input_negative_prompt):
                    raise TypeError(
                        f"`input_negative_prompt` should be the same type to `input_prompt`, but got {type(input_negative_prompt)} !="
                        f" {type(input_prompt)}."
                    )
                elif batch_size != len(input_negative_prompt):
                    raise ValueError(
                        f"`input_negative_prompt`: {input_negative_prompt} has batch size {len(input_negative_prompt)}, but `input_prompt`:"
                        f" {input_prompt} has batch size {batch_size}. Please make sure that passed `input_negative_prompt` matches"
                        " the batch size of `input_prompt`."
                    )
                else:
                    uncond_tokens = [input_negative_prompt, input_negative_prompt_2]

                negative_prompt_embeds_list = []
                for negative_prompt, tokenizer, text_encoder in zip(uncond_tokens, tokenizers, text_encoders):
                    if isinstance(self, TextualInversionLoaderMixin):
                        negative_prompt = self.maybe_convert_prompt(negative_prompt, tokenizer)

                    max_length = input_prompt_embeds.shape[1]
                    uncond_input = tokenizer(
                        negative_prompt,
                        padding="max_length",
                        max_length=max_length,
                        truncation=True,
                        return_tensors="pt",
                    )

                    input_negative_prompt_embeds = text_encoder(
                        uncond_input.input_ids.to(input_device),
                        output_hidden_states=True,
                    )
                    input_negative_pooled_prompt_embeds = input_negative_prompt_embeds[0]
                    input_negative_prompt_embeds = input_negative_prompt_embeds.hidden_states[-2]

                    negative_prompt_embeds_list.append(input_negative_prompt_embeds)

                input_negative_prompt_embeds = torch.concat(negative_prompt_embeds_list, dim=-1)

            if self.text_encoder_2 is not None:
                input_prompt_embeds = input_prompt_embeds.to(dtype=self.text_encoder_2.dtype, device=input_device)
            else:
                input_prompt_embeds = input_prompt_embeds.to(dtype=self.unet.dtype, device=input_device)

            bs_embed, seq_len, _ = input_prompt_embeds.shape
            input_prompt_embeds = input_prompt_embeds.repeat(1, input_num_images_per_prompt, 1)
            input_prompt_embeds = input_prompt_embeds.view(bs_embed * input_num_images_per_prompt, seq_len, -1)

            if input_do_classifier_free_guidance:
                # duplicate unconditional embeddings for each generation per prompt, using mps friendly method
                seq_len = input_negative_prompt_embeds.shape[1]

                if self.text_encoder_2 is not None:
                    input_negative_prompt_embeds = input_negative_prompt_embeds.to(dtype=self.text_encoder_2.dtype, device=input_device)
                else:
                    input_negative_prompt_embeds = input_negative_prompt_embeds.to(dtype=self.unet.dtype, device=input_device)

                input_negative_prompt_embeds = input_negative_prompt_embeds.repeat(1, input_num_images_per_prompt, 1)
                input_negative_prompt_embeds = input_negative_prompt_embeds.view(batch_size * input_num_images_per_prompt, seq_len, -1)

            pooled_prompt_embeds = pooled_prompt_embeds.repeat(1, input_num_images_per_prompt).view(
                bs_embed * input_num_images_per_prompt, -1
            )
            if input_do_classifier_free_guidance:
                input_negative_pooled_prompt_embeds = input_negative_pooled_prompt_embeds.repeat(1, input_num_images_per_prompt).view(
                    bs_embed * input_num_images_per_prompt, -1
                )

            if self.text_encoder is not None:
                if isinstance(self, StableVictorXLLoraLoaderMixin) and USE_PEFT_BACKEND:
                    # Retrieve the original scale by scaling back the LoRA layers
                    unscale_lora_layers(self.text_encoder, input_lora_scale)

            if self.text_encoder_2 is not None:
                if isinstance(self, StableVictorXLLoraLoaderMixin) and USE_PEFT_BACKEND:
                    # Retrieve the original scale by scaling back the LoRA layers
                    unscale_lora_layers(self.text_encoder_2, input_lora_scale)

            return input_prompt_embeds, input_negative_prompt_embeds, pooled_prompt_embeds, input_negative_pooled_prompt_embeds




 
    def prepare_extra_step_kwargs(self, input_generator, input_eta):
      

        accepts_eta = "eta" in set(inspect.signature(self.scheduler.step).parameters.keys())
        extra_step_kwargs = {}
        if accepts_eta:
            extra_step_kwargs["eta"] = input_eta

        accepts_generator = "generator" in set(inspect.signature(self.scheduler.step).parameters.keys())
        if accepts_generator:
            extra_step_kwargs["generator"] = input_generator
        return extra_step_kwargs

    def check_inputs(
        self,
        input_prompt,
        input_prompt_2,
        input_height,
        input_width,
        input_callback_steps,
        input_negative_prompt=None,
        input_negative_prompt_2=None,
        input_prompt_embeds=None,
        input_negative_prompt_embeds=None,
        input_pooled_prompt_embeds=None,
        input_negative_pooled_prompt_embeds=None,
        input_callback_on_step_end_tensor_inputs=None,
    ):
        if input_height % 8 != 0 or input_width % 8 != 0:
            raise ValueError(f"`input_height` and `input_width` have to be divisible by 8 but are {input_height} and {input_width}.")

        if input_callback_steps is not None and (not isinstance(input_callback_steps, int) or input_callback_steps <= 0):
            raise ValueError(
                f"`input_callback_steps` has to be a positive integer but is {input_callback_steps} of type"
                f" {type(input_callback_steps)}."
            )

        if input_callback_on_step_end_tensor_inputs is not None and not all(
            k in self._callback_tensor_inputs for k in input_callback_on_step_end_tensor_inputs
        ):
            raise ValueError(
                f"`input_callback_on_step_end_tensor_inputs` has to be in {self._callback_tensor_inputs}, but found {[k for k in input_callback_on_step_end_tensor_inputs if k not in self._callback_tensor_inputs]}"
            )

        if input_prompt is not None and input_prompt_embeds is not None:
            raise ValueError(
                f"Cannot forward both `input_prompt`: {input_prompt} and `input_prompt_embeds`: {input_prompt_embeds}. Please make sure to"
                " only forward one of the two."
            )
        elif input_prompt_2 is not None and input_prompt_embeds is not None:
            raise ValueError(
                f"Cannot forward both `input_prompt_2`: {input_prompt_2} and `input_prompt_embeds`: {input_prompt_embeds}. Please make sure to"
                " only forward one of the two."
            )
        elif input_prompt is None and input_prompt_embeds is None:
            raise ValueError(
                "Provide either `input_prompt` or `input_prompt_embeds`. Cannot leave both `input_prompt` and `input_prompt_embeds` undefined."
            )
        elif input_prompt is not None and (not isinstance(input_prompt, str) and not isinstance(input_prompt, list)):
            raise ValueError(f"`input_prompt` has to be of type `str` or `list` but is {type(input_prompt)}")
        elif input_prompt_2 is not None and (not isinstance(input_prompt_2, str) and not isinstance(input_prompt_2, list)):
            raise ValueError(f"`input_prompt_2` has to be of type `str` or `list` but is {type(input_prompt_2)}")

        if input_negative_prompt is not None and input_negative_prompt_embeds is not None:
            raise ValueError(
                f"Cannot forward both `input_negative_prompt`: {input_negative_prompt} and `input_negative_prompt_embeds`:"
                f" {input_negative_prompt_embeds}. Please make sure to only forward one of the two."
            )
        elif input_negative_prompt_2 is not None and input_negative_prompt_embeds is not None:
            raise ValueError(
                f"Cannot forward both `input_negative_prompt_2`: {input_negative_prompt_2} and `input_negative_prompt_embeds`:"
                f" {input_negative_prompt_embeds}. Please make sure to only forward one of the two."
            )

        if input_prompt_embeds is not None and input_negative_prompt_embeds is not None:
            if input_prompt_embeds.shape != input_negative_prompt_embeds.shape:
                raise ValueError(
                    "`input_prompt_embeds` and `input_negative_prompt_embeds` must have the same shape when passed directly, but"
                    f" got: `input_prompt_embeds` {input_prompt_embeds.shape} != `input_negative_prompt_embeds`"
                    f" {input_negative_prompt_embeds.shape}."
                )

        if input_prompt_embeds is not None and input_pooled_prompt_embeds is None:
            raise ValueError(
                "If `input_prompt_embeds` are provided, `input_pooled_prompt_embeds` also have to be passed. Make sure to generate `input_pooled_prompt_embeds` from the same text encoder that was used to generate `input_prompt_embeds`."
            )

        if input_negative_prompt_embeds is not None and input_negative_pooled_prompt_embeds is None:
            raise ValueError(
                "If `input_negative_prompt_embeds` are provided, `input_negative_pooled_prompt_embeds` also have to be passed. Make sure to generate `input_negative_pooled_prompt_embeds` from the same text encoder that was used to generate `input_negative_prompt_embeds`."
            )




    def prepare_latents(self, input_batch_size, input_num_channels_latents, input_height, input_width, input_dtype, input_device, input_generator, input_latents=None):
        shape = (input_batch_size, input_num_channels_latents, input_height // self.vae_scale_factor, input_width // self.vae_scale_factor)
        if isinstance(input_generator, list) and len(input_generator) != input_batch_size:
            raise ValueError(
                f"You have passed a list of generators of length {len(input_generator)}, but requested an effective batch"
                f" size of {input_batch_size}. Make sure the batch size matches the length of the generators."
            )

        if input_latents is None:
            input_latents = randn_tensor(shape, generator=input_generator, device=input_device, dtype=input_dtype)
        else:
            input_latents = input_latents.to(input_device)

        # scale the initial noise by the standard deviation required by the scheduler
        input_latents = input_latents * self.scheduler.init_noise_sigma
        return input_latents

    def _get_add_time_ids(
        self, input_original_size, input_crops_coords_top_left, input_target_size, input_dtype, input_text_encoder_projection_dim=None
    ):
        add_time_ids = list(input_original_size + input_crops_coords_top_left + input_target_size)

        passed_add_embed_dim = (
            self.unet.config.addition_time_embed_dim * len(add_time_ids) + input_text_encoder_projection_dim
        )
        expected_add_embed_dim = self.unet.add_embedding.linear_1.in_features

        if expected_add_embed_dim != passed_add_embed_dim:
            raise ValueError(
                f"Model expects an added time embedding vector of length {expected_add_embed_dim}, but a vector of {passed_add_embed_dim} was created. The model has an incorrect config. Please check `unet.config.time_embedding_type` and `text_encoder_2.config.projection_dim`."
            )

        add_time_ids = torch.tensor([add_time_ids], dtype=input_dtype)
        return add_time_ids

    def upcast_vae(self):
        dtype = self.vae.dtype
        self.vae.to(dtype=torch.float32)
        use_torch_2_0_or_xformers = isinstance(
            self.vae.decoder.mid_block.attentions[0].processor,
            (
                AttnProcessor2_0,
                XFormersAttnProcessor,
                LoRAXFormersAttnProcessor,
                LoRAAttnProcessor2_0,
            ),
        )
     
        if use_torch_2_0_or_xformers:
            self.vae.post_quant_conv.to(dtype)
            self.vae.decoder.conv_in.to(dtype)
            self.vae.decoder.mid_block.to(dtype)







    def enable_freeu(self, scaling_factor_stage1: float, scaling_factor_stage2: float, backbone_scaling_stage1: float, backbone_scaling_stage2: float):
        r"""Enables the FreeU mechanism as in https://arxiv.org/abs/2309.11497.

        The suffixes after the scaling factors represent the stages where they are being applied.

     
        """
        if not hasattr(self, "unet"):
            raise ValueError("The pipeline must have `unet` for using FreeU.")
        self.unet.enable_freeu(s1=scaling_factor_stage1, s2=scaling_factor_stage2, b1=backbone_scaling_stage1, b2=backbone_scaling_stage2)

    def disable_freeu(self):
        """Disables the FreeU mechanism if enabled."""
        self.unet.disable_freeu()

    def get_guidance_scale_embedding(self, timesteps, embedding_dim=512, dtype=torch.float32):
    
        assert len(timesteps.shape) == 1
        timesteps = timesteps * 1000.0

        half_dim = embedding_dim // 2
        emb = torch.log(torch.tensor(10000.0)) / (half_dim - 1)
        emb = torch.exp(torch.arange(half_dim, dtype=dtype) * -emb)
        emb = timesteps.to(dtype)[:, None] * emb[None, :]
        emb = torch.cat([torch.sin(emb), torch.cos(emb)], dim=1)
        if embedding_dim % 2 == 1:  # zero pad
            emb = torch.nn.functional.pad(emb, (0, 1))
        assert emb.shape == (timesteps.shape[0], embedding_dim)
        return emb

    @property
    def guidance_scale(self):
        return self._guidance_scale

    @property
    def guidance_rescale(self):
        return self._guidance_rescale

    @property
    def clip_skip(self):
        return self._clip_skip

  
    @property
    def do_classifier_free_guidance(self):
        return self._guidance_scale > 1 and self.unet.config.time_cond_proj_dim is None

    @property
    def cross_attention_kwargs(self):
        return self._cross_attention_kwargs

    @property
    def denoising_end(self):
        return self._denoising_end

    @property
    def num_timesteps(self):
        return self._num_timesteps

    @torch.no_grad()
    
    def __call__(
        self,
        prompt: Union[str, List[str]] = None,
        prompt_2: Optional[Union[str, List[str]]] = None,
        height: Optional[int] = None,
        width: Optional[int] = None,
        num_inference_steps: int = 50,
        denoising_end: Optional[float] = None,
        guidance_scale: float = 5.0,
        negative_prompt: Optional[Union[str, List[str]]] = None,
        negative_prompt_2: Optional[Union[str, List[str]]] = None,
        num_images_per_prompt: Optional[int] = 1,
        eta: float = 0.0,
        generator: Optional[Union[torch.Generator, List[torch.Generator]]] = None,
        latents: Optional[torch.FloatTensor] = None,
        prompt_embeds: Optional[torch.FloatTensor] = None,
        negative_prompt_embeds: Optional[torch.FloatTensor] = None,
        pooled_prompt_embeds: Optional[torch.FloatTensor] = None,
        negative_pooled_prompt_embeds: Optional[torch.FloatTensor] = None,
        output_type: Optional[str] = "pil",
        return_dict: bool = True,
        cross_attention_kwargs: Optional[Dict[str, Any]] = None,
        guidance_rescale: float = 0.0,
        original_size: Optional[Tuple[int, int]] = None,
        crops_coords_top_left: Tuple[int, int] = (0, 0),
        target_size: Optional[Tuple[int, int]] = None,
        negative_original_size: Optional[Tuple[int, int]] = None,
        negative_crops_coords_top_left: Tuple[int, int] = (0, 0),
        negative_target_size: Optional[Tuple[int, int]] = None,
        clip_skip: Optional[int] = None,
        callback_on_step_end: Optional[Callable[[int, int, Dict], None]] = None,
        callback_on_step_end_tensor_inputs: List[str] = ["latents"],
        **kwargs,
    ):
       
        callback = kwargs.pop("callback", None)
        callback_steps = kwargs.pop("callback_steps", None)

        if callback is not None:
            deprecate(
                "callback",
                "1.0.0",
                "Passing `callback` as an input argument to `__call__` is deprecated, consider use `callback_on_step_end`",
            )
        if callback_steps is not None:
            deprecate(
                "callback_steps",
                "1.0.0",
                "Passing `callback_steps` as an input argument to `__call__` is deprecated, consider use `callback_on_step_end`",
            )

        # 0. Default height and width to unet
        height = height or self.default_sample_size * self.vae_scale_factor
        width = width or self.default_sample_size * self.vae_scale_factor

        original_size = original_size or (height, width)
        target_size = target_size or (height, width)

        # 1. Check inputs. Raise error if not correct
        self.check_inputs(
            prompt,
            prompt_2,
            height,
            width,
            callback_steps,
            negative_prompt,
            negative_prompt_2,
            prompt_embeds,
            negative_prompt_embeds,
            pooled_prompt_embeds,
            negative_pooled_prompt_embeds,
            callback_on_step_end_tensor_inputs,
        )

        self._guidance_scale = guidance_scale
        self._guidance_rescale = guidance_rescale
        self._clip_skip = clip_skip
        self._cross_attention_kwargs = cross_attention_kwargs
        self._denoising_end = denoising_end

        # 2. Define call parameters
        if prompt is not None and isinstance(prompt, str):
            batch_size = 1
        elif prompt is not None and isinstance(prompt, list):
            batch_size = len(prompt)
        else:
            batch_size = prompt_embeds.shape[0]

        device = self._execution_device

        # 3. Encode input prompt
        lora_scale = (
            self.cross_attention_kwargs.get("scale", None) if self.cross_attention_kwargs is not None else None
        )

        (
            prompt_embeds,
            negative_prompt_embeds,
            pooled_prompt_embeds,
            negative_pooled_prompt_embeds,
        ) = self.encode_prompt(
            prompt=prompt,
            prompt_2=prompt_2,
            device=device,
            num_images_per_prompt=num_images_per_prompt,
            do_classifier_free_guidance=self.do_classifier_free_guidance,
            negative_prompt=negative_prompt,
            negative_prompt_2=negative_prompt_2,
            prompt_embeds=prompt_embeds,
            negative_prompt_embeds=negative_prompt_embeds,
            pooled_prompt_embeds=pooled_prompt_embeds,
            negative_pooled_prompt_embeds=negative_pooled_prompt_embeds,
            lora_scale=lora_scale,
            clip_skip=self.clip_skip,
        )

        # 4. Prepare timesteps
        self.scheduler.set_timesteps(num_inference_steps, device=device)

        timesteps = self.scheduler.timesteps

        # 5. Prepare latent variables
        num_channels_latents = self.unet.config.in_channels
        latents = self.prepare_latents(
            batch_size * num_images_per_prompt,
            num_channels_latents,
            height,
            width,
            prompt_embeds.dtype,
            device,
            generator,
            latents,
        )

        # 6. Prepare extra step kwargs. TODO: Logic should ideally just be moved out of the pipeline
        extra_step_kwargs = self.prepare_extra_step_kwargs(generator, eta)

        # 7. Prepare added time ids & embeddings
        add_text_embeds = pooled_prompt_embeds
        if self.text_encoder_2 is None:
            text_encoder_projection_dim = int(pooled_prompt_embeds.shape[-1])
        else:
            text_encoder_projection_dim = self.text_encoder_2.config.projection_dim

        add_time_ids = self._get_add_time_ids(
            original_size,
            crops_coords_top_left,
            target_size,
            dtype=prompt_embeds.dtype,
            text_encoder_projection_dim=text_encoder_projection_dim,
        )
        if negative_original_size is not None and negative_target_size is not None:
            negative_add_time_ids = self._get_add_time_ids(
                negative_original_size,
                negative_crops_coords_top_left,
                negative_target_size,
                dtype=prompt_embeds.dtype,
                text_encoder_projection_dim=text_encoder_projection_dim,
            )
        else:
            negative_add_time_ids = add_time_ids

        if self.do_classifier_free_guidance:
            prompt_embeds = torch.cat([negative_prompt_embeds, prompt_embeds], dim=0)
            add_text_embeds = torch.cat([negative_pooled_prompt_embeds, add_text_embeds], dim=0)
            add_time_ids = torch.cat([negative_add_time_ids, add_time_ids], dim=0)

        prompt_embeds = prompt_embeds.to(device)
        add_text_embeds = add_text_embeds.to(device)
        add_time_ids = add_time_ids.to(device).repeat(batch_size * num_images_per_prompt, 1)

        # 8. Denoising loop
        num_warmup_steps = max(len(timesteps) - num_inference_steps * self.scheduler.order, 0)

        # 8.1 Apply denoising_end
        if (
            self.denoising_end is not None
            and isinstance(self.denoising_end, float)
            and self.denoising_end > 0
            and self.denoising_end < 1
        ):
            discrete_timestep_cutoff = int(
                round(
                    self.scheduler.config.num_train_timesteps
                    - (self.denoising_end * self.scheduler.config.num_train_timesteps)
                )
            )
            num_inference_steps = len(list(filter(lambda ts: ts >= discrete_timestep_cutoff, timesteps)))
            timesteps = timesteps[:num_inference_steps]

        # 9. Optionally get Guidance Scale Embedding
        timestep_cond = None
        if self.unet.config.time_cond_proj_dim is not None:
            guidance_scale_tensor = torch.tensor(self.guidance_scale - 1).repeat(batch_size * num_images_per_prompt)
            timestep_cond = self.get_guidance_scale_embedding(
                guidance_scale_tensor, embedding_dim=self.unet.config.time_cond_proj_dim
            ).to(device=device, dtype=latents.dtype)

        self._num_timesteps = len(timesteps)
        with self.progress_bar(total=num_inference_steps) as progress_bar:
            for i, t in enumerate(timesteps):
                # expand the latents if we are doing classifier free guidance
                latent_model_input = torch.cat([latents] * 2) if self.do_classifier_free_guidance else latents

                latent_model_input = self.scheduler.scale_model_input(latent_model_input, t)

                # predict the noise residual
                added_cond_kwargs = {"text_embeds": add_text_embeds, "time_ids": add_time_ids}
                noise_pred = self.unet(
                    latent_model_input,
                    t,
                    encoder_hidden_states=prompt_embeds,
                    timestep_cond=timestep_cond,
                    cross_attention_kwargs=self.cross_attention_kwargs,
                    added_cond_kwargs=added_cond_kwargs,
                    return_dict=False,
                )[0]

                # perform guidance
                if self.do_classifier_free_guidance:
                    noise_pred_uncond, noise_pred_text = noise_pred.chunk(2)
                    noise_pred = noise_pred_uncond + self.guidance_scale * (noise_pred_text - noise_pred_uncond)

                if self.do_classifier_free_guidance and self.guidance_rescale > 0.0:
                    noise_pred = rescale_noise_cfg(noise_pred, noise_pred_text, guidance_rescale=self.guidance_rescale)

                # compute the previous noisy sample x_t -> x_t-1
                latents = self.scheduler.step(noise_pred, t, latents, **extra_step_kwargs, return_dict=False)[0]

                if callback_on_step_end is not None:
                    callback_kwargs = {}
                    for k in callback_on_step_end_tensor_inputs:
                        callback_kwargs[k] = locals()[k]
                    callback_outputs = callback_on_step_end(self, i, t, callback_kwargs)

                    latents = callback_outputs.pop("latents", latents)
                    prompt_embeds = callback_outputs.pop("prompt_embeds", prompt_embeds)
                    negative_prompt_embeds = callback_outputs.pop("negative_prompt_embeds", negative_prompt_embeds)
                    add_text_embeds = callback_outputs.pop("add_text_embeds", add_text_embeds)
                    negative_pooled_prompt_embeds = callback_outputs.pop(
                        "negative_pooled_prompt_embeds", negative_pooled_prompt_embeds
                    )
                    add_time_ids = callback_outputs.pop("add_time_ids", add_time_ids)
                    negative_add_time_ids = callback_outputs.pop("negative_add_time_ids", negative_add_time_ids)

                # call the callback, if provided
                if i == len(timesteps) - 1 or ((i + 1) > num_warmup_steps and (i + 1) % self.scheduler.order == 0):
                    progress_bar.update()
                    if callback is not None and i % callback_steps == 0:
                        step_idx = i // getattr(self.scheduler, "order", 1)
                        callback(step_idx, t, latents)

                if XLA_AVAILABLE:
                    xm.mark_step()

        if not output_type == "latent":
            needs_upcasting = self.vae.dtype == torch.float16 and self.vae.config.force_upcast

            if needs_upcasting:
                self.upcast_vae()
                latents = latents.to(next(iter(self.vae.post_quant_conv.parameters())).dtype)

            image = self.vae.decode(latents / self.vae.config.scaling_factor, return_dict=False)[0]

            # cast back to fp16 if needed
            if needs_upcasting:
                self.vae.to(dtype=torch.float16)
        else:
            image = latents

        if not output_type == "latent":
            # apply watermark if available
            if self.watermark is not None:
                image = self.watermark.apply_watermark(image)

            image = self.image_processor.postprocess(image, output_type=output_type)

        # Offload all models
        self.maybe_free_model_hooks()

        if not return_dict:
            return (image,)

        return StableVictorXLPipelineOutput(images=image)
