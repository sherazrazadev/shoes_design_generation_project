import inspect
from typing import Any, Callable, Dict, List, Optional, Tuple, Union
import numpy as np
import PIL.Image
import torch
import torch.nn.functional as F
from transformers import CLIPImageProcessor, CLIPTextModel, CLIPTokenizer
from ...image_processor import PipelineImageInput, VaeImageProcessor
from ...loaders import FromSingleFileMixin, LoraLoaderMixin, TextualInversionLoaderMixin
from ...models import AutoencoderKL, ControlNetModel, UNet2DConditionModel
from ...models.lora import adjust_lora_scale_text_encoder
from ...schedulers import KarrasVictorSchedulers
from ...utils import (
    USE_PEFT_BACKEND,
    deprecate,
    logging,
    scale_lora_layers,
    unscale_lora_layers,
)
from ...utils.torch_utils import is_compiled_module, randn_tensor
from ..pipeline_utils import VictorPipeline
from ..stable_victor import StableVictorPipelineOutput
from ..stable_victor.safety_checker import StableVictorSafetyChecker
from .multicontrolnet import MultiControlNetModel 


logger = logging.get_logger(__name__)  

def retrieve_latents(encoded_output, data_generator):
    if hasattr(encoded_output, "latent_dist"):
        return encoded_output.latent_dist.sample(data_generator)
    elif hasattr(encoded_output, "latents"):
        return encoded_output.latents
    else:
        raise AttributeError("Could not access latents of the provided encoded_output")



def prepare_image(input_image):
    if isinstance(input_image, torch.Tensor):
        # Batch single image
        if input_image.ndim == 3:
            input_image = input_image.unsqueeze(0)

        prepared_image = input_image.to(dtype=torch.float32)
    else:
        # preprocess image
        if isinstance(input_image, (PIL.Image.Image, np.ndarray)):
            input_image = [input_image]

        if isinstance(input_image, list) and isinstance(input_image[0], PIL.Image.Image):
            input_image = [np.array(i.convert("RGB"))[None, :] for i in input_image]
            input_image = np.concatenate(input_image, axis=0)
        elif isinstance(input_image, list) and isinstance(input_image[0], np.ndarray):
            input_image = np.concatenate([i[None, :] for i in input_image], axis=0)

        input_image = input_image.transpose(0, 3, 1, 2)
        prepared_image = torch.from_numpy(input_image).to(dtype=torch.float32) / 127.5 - 1.0

    return prepared_image


class StableVictorControlNetImg2ImgPipeline(
    VictorPipeline, TextualInversionLoaderMixin, LoraLoaderMixin, FromSingleFileMixin
):
    
    model_cpu_offload_seq = "text_encoder->unet->vae"
    _optional_components = ["safety_checker", "feature_extractor"]
    _exclude_from_cpu_offload = ["safety_checker"]

    def __init__(
        self,
        vae: AutoencoderKL,
        text_encoder: CLIPTextModel,
        tokenizer: CLIPTokenizer,
        unet: UNet2DConditionModel,
        controlnet: Union[ControlNetModel, List[ControlNetModel], Tuple[ControlNetModel], MultiControlNetModel],
        scheduler: KarrasVictorSchedulers,
        safety_checker: StableVictorSafetyChecker,
        feature_extractor: CLIPImageProcessor,
        requires_safety_checker: bool = True,
    ):
        super().__init__()

        if safety_checker is None and requires_safety_checker:
            logger.warning(
                f"You have disabled the safety checker for {self.__class__} by passing `safety_checker=None."
            )

        if safety_checker is not None and feature_extractor is None:
            raise ValueError(
                "Make sure to define a feature extractor when loading {self.__class__} if you want to use the safety"
            )

        if isinstance(controlnet, (list, tuple)):
            controlnet = MultiControlNetModel(controlnet)

        self.register_modules(
            vae=vae,
            text_encoder=text_encoder,
            tokenizer=tokenizer,
            unet=unet,
            controlnet=controlnet,
            scheduler=scheduler,
            safety_checker=safety_checker,
            feature_extractor=feature_extractor,
        )
        self.vae_scale_factor = 2 ** (len(self.vae.config.block_out_channels) - 1)
        self.image_processor = VaeImageProcessor(vae_scale_factor=self.vae_scale_factor, do_convert_rgb=True)
        self.control_image_processor = VaeImageProcessor(
            vae_scale_factor=self.vae_scale_factor, do_convert_rgb=True, do_normalize=False
        )
        self.register_to_config(requires_safety_checker=requires_safety_checker)

    def enable_vae_slicing(self):
      
        self.vae.enable_slicing()

    def disable_vae_slicing(self):
     
        self.vae.disable_slicing()

    def enable_vae_tiling(self):
       
        self.vae.enable_tiling()

    def disable_vae_tiling(self):
       
        self.vae.disable_tiling()

    def _encode_prompt(
        self,
        input_prompt,
        target_device,
        images_per_prompt,
        enable_free_guidance,
        negative_input_prompt=None,
        input_prompt_embeddings: Optional[torch.FloatTensor] = None,
        negative_input_prompt_embeddings: Optional[torch.FloatTensor] = None,
        lora_scaling: Optional[float] = None,
        **additional_args,
    ):
        deprecation_warning = "`_encode_prompt()` is deprecated and will be removed in a future version. Use `encode_prompt()` instead. Also, be aware that the output format changed from a concatenated tensor to a tuple."
        deprecate("_encode_prompt()", "1.0.0", deprecation_warning, standard_warn=False)

        encoded_prompt_tuple = self.encode_prompt(
            prompt=input_prompt,
            device=target_device,
            num_images_per_prompt=images_per_prompt,
            do_classifier_free_guidance=enable_free_guidance,
            negative_prompt=negative_input_prompt,
            prompt_embeds=input_prompt_embeddings,
            negative_prompt_embeds=negative_input_prompt_embeddings,
            lora_scale=lora_scaling,
            **additional_args,
        )

        
        combined_prompt_embeddings = torch.cat([encoded_prompt_tuple[1], encoded_prompt_tuple[0]])

        return combined_prompt_embeddings


    def encode_prompt(
        self,
        input_prompt,
        target_device,
        images_per_prompt,
        enable_free_guidance,
        negative_input_prompt=None,
        input_prompt_embeddings: Optional[torch.FloatTensor] = None,
        negative_input_prompt_embeddings: Optional[torch.FloatTensor] = None,
        lora_scaling: Optional[float] = None,
        clip_skip: Optional[int] = None,
    ):
        
       
        # function of text encoder can correctly access it
        if lora_scaling is not None and isinstance(self, LoraLoaderMixin):
            self._lora_scale = lora_scaling

            # dynamically adjust the LoRA scale
            if not USE_PEFT_BACKEND:
                adjust_lora_scale_text_encoder(self.text_encoder, lora_scaling)
            else:
                scale_lora_layers(self.text_encoder, lora_scaling)

        if input_prompt is not None and isinstance(input_prompt, str):
            batch_size = 1
        elif input_prompt is not None and isinstance(input_prompt, list):
            batch_size = len(input_prompt)
        else:
            batch_size = input_prompt_embeddings.shape[0]

        if input_prompt_embeddings is None:
            # textual inversion: procecss multi-vector tokens if necessary
            if isinstance(self, TextualInversionLoaderMixin):
                input_prompt = self.maybe_convert_prompt(input_prompt, self.tokenizer)

            text_inputs = self.tokenizer(
                input_prompt,
                padding="max_length",
                max_length=self.tokenizer.model_max_length,
                truncation=True,
                return_tensors="pt",
            )
            text_input_ids = text_inputs.input_ids
            untruncated_ids = self.tokenizer(input_prompt, padding="longest", return_tensors="pt").input_ids

            if untruncated_ids.shape[-1] >= text_input_ids.shape[-1] and not torch.equal(
                text_input_ids, untruncated_ids
            ):
                removed_text = self.tokenizer.batch_decode(
                    untruncated_ids[:, self.tokenizer.model_max_length - 1 : -1]
                )
                logger.warning(
                    "The following part of your input was truncated because CLIP can only handle sequences up to"
                    f" {self.tokenizer.model_max_length} tokens: {removed_text}"
                )

            if hasattr(self.text_encoder.config, "use_attention_mask") and self.text_encoder.config.use_attention_mask:
                attention_mask = text_inputs.attention_mask.to(target_device)
            else:
                attention_mask = None

            if clip_skip is None:
                input_prompt_embeddings = self.text_encoder(text_input_ids.to(target_device), attention_mask=attention_mask)
                input_prompt_embeddings = input_prompt_embeddings[0]
            else:
                input_prompt_embeddings = self.text_encoder(
                    text_input_ids.to(target_device), attention_mask=attention_mask, output_hidden_states=True
                )
              
                input_prompt_embeddings = input_prompt_embeddings[-1][-(clip_skip + 1)]
             
                input_prompt_embeddings = self.text_encoder.text_model.final_layer_norm(input_prompt_embeddings)

        if self.text_encoder is not None:
            input_prompt_embeddings_dtype = self.text_encoder.dtype
        elif self.unet is not None:
            input_prompt_embeddings_dtype = self.unet.dtype
        else:
            input_prompt_embeddings_dtype = input_prompt_embeddings.dtype

        input_prompt_embeddings = input_prompt_embeddings.to(dtype=input_prompt_embeddings_dtype, device=target_device)

        bs_embed, seq_len, _ = input_prompt_embeddings.shape
        input_prompt_embeddings = input_prompt_embeddings.repeat(1, images_per_prompt, 1)
        input_prompt_embeddings = input_prompt_embeddings.view(bs_embed * images_per_prompt, seq_len, -1)

        if enable_free_guidance and negative_input_prompt_embeddings is None:
            uncond_tokens: List[str]
            if negative_input_prompt is None:
                uncond_tokens = [""] * batch_size
            elif input_prompt is not None and type(input_prompt) is not type(negative_input_prompt):
                raise TypeError(
                    f"`negative_input_prompt` should be the same type as `input_prompt`, but got {type(negative_input_prompt)} !="
                    f" {type(input_prompt)}."
                )
            elif isinstance(negative_input_prompt, str):
                uncond_tokens = [negative_input_prompt]
            elif batch_size != len(negative_input_prompt):
                raise ValueError(
                    f"`negative_input_prompt`: {negative_input_prompt} has batch size {len(negative_input_prompt)}, but `input_prompt`:"
                    f" {input_prompt} has batch size {batch_size}. Please make sure that passed `negative_input_prompt` matches"
                    " the batch size of `input_prompt`."
                )
            else:
                uncond_tokens = negative_input_prompt

            if isinstance(self, TextualInversionLoaderMixin):
                uncond_tokens = self.maybe_convert_prompt(uncond_tokens, self.tokenizer)

            max_length = input_prompt_embeddings.shape[1]
            uncond_input = self.tokenizer(
                uncond_tokens,
                padding="max_length",
                max_length=max_length,
                truncation=True,
                return_tensors="pt",
            )

            if hasattr(self.text_encoder.config, "use_attention_mask") and self.text_encoder.config.use_attention_mask:
                attention_mask = uncond_input.attention_mask.to(target_device)
            else:
                attention_mask = None

            negative_input_prompt_embeddings = self.text_encoder(
                uncond_input.input_ids.to(target_device),
                attention_mask=attention_mask,
            )
            negative_input_prompt_embeddings = negative_input_prompt_embeddings[0]

        if enable_free_guidance:
            seq_len = negative_input_prompt_embeddings.shape[1]

            negative_input_prompt_embeddings = negative_input_prompt_embeddings.to(
                dtype=input_prompt_embeddings_dtype, device=target_device
            )

            negative_input_prompt_embeddings = negative_input_prompt_embeddings.repeat(1, images_per_prompt, 1)
            negative_input_prompt_embeddings = negative_input_prompt_embeddings.view(
                batch_size * images_per_prompt, seq_len, -1
            )

        if isinstance(self, LoraLoaderMixin) and USE_PEFT_BACKEND:
            unscale_lora_layers(self.text_encoder, lora_scaling)

        return input_prompt_embeddings, negative_input_prompt_embeddings

 
    def run_safety_checker(self, input_image, target_device, data_type):
        if self.safety_checker is None:
            has_nsfw_concept = None
        else:
            if torch.is_tensor(input_image):
                feature_extractor_input = self.image_processor.postprocess(input_image, output_type="pil")
            else:
                feature_extractor_input = self.image_processor.numpy_to_pil(input_image)
            safety_checker_input = self.feature_extractor(feature_extractor_input, return_tensors="pt").to(target_device)
            input_image, has_nsfw_concept = self.safety_checker(
                images=input_image, clip_input=safety_checker_input.pixel_values.to(data_type)
            )
        return input_image, has_nsfw_concept


    def decode_latents(self, input_latents):
        deprecation_message = "The decode_latents method is deprecated and will be removed in 1.0.0. Please use VaeImageProcessor.postprocess(...) instead"
        deprecate("decode_latents", "1.0.0", deprecation_message, standard_warn=False)

        processed_latents = 1 / self.vae.config.scaling_factor * input_latents
        decoded_image = self.vae.decode(processed_latents, return_dict=False)[0]
        decoded_image = (decoded_image / 2 + 0.5).clamp(0, 1)
        decoded_image = decoded_image.cpu().permute(0, 2, 3, 1).float().numpy()
        return decoded_image

    def prepare_extra_step_kwargs(self, input_generator, input_eta):
       

        accepts_eta = "eta" in set(inspect.signature(self.scheduler.step).parameters.keys())
        extra_step_kwargs = {}
        if accepts_eta:
            extra_step_kwargs["eta"] = input_eta

        # Check if the scheduler accepts generator
        accepts_generator = "generator" in set(inspect.signature(self.scheduler.step).parameters.keys())
        if accepts_generator:
            extra_step_kwargs["generator"] = input_generator
        return extra_step_kwargs


    def check_inputs(
        self,
        input_prompt,
        input_image,
        input_callback_steps,
        input_negative_prompt=None,
        input_prompt_embeds=None,
        input_negative_prompt_embeds=None,
        input_controlnet_conditioning_scale=1.0,
        input_control_guidance_start=0.0,
        input_control_guidance_end=1.0,
    ):
        if (input_callback_steps is None) or (
            input_callback_steps is not None and (not isinstance(input_callback_steps, int) or input_callback_steps <= 0)
        ):
            raise ValueError(
                f"`input_callback_steps` has to be a positive integer but is {input_callback_steps} of type"
                f" {type(input_callback_steps)}."
            )

        if input_prompt is not None and input_prompt_embeds is not None:
            raise ValueError(
                f"Cannot forward both `input_prompt`: {input_prompt} and `input_prompt_embeds`: {input_prompt_embeds}."
                " Please make sure to only forward one of the two."
            )
        elif input_prompt is None and input_prompt_embeds is None:
            raise ValueError(
                "Provide either `input_prompt` or `input_prompt_embeds`. Cannot leave both `input_prompt` and"
                " `input_prompt_embeds` undefined."
            )
        elif input_prompt is not None and (not isinstance(input_prompt, str) and not isinstance(input_prompt, list)):
            raise ValueError(f"`input_prompt` has to be of type `str` or `list` but is {type(input_prompt)}")

        if input_negative_prompt is not None and input_negative_prompt_embeds is not None:
            raise ValueError(
                f"Cannot forward both `input_negative_prompt`: {input_negative_prompt} and `input_negative_prompt_embeds`:"
                f" {input_negative_prompt_embeds}. Please make sure to only forward one of the two."
            )

        if input_prompt_embeds is not None and input_negative_prompt_embeds is not None:
            if input_prompt_embeds.shape != input_negative_prompt_embeds.shape:
                raise ValueError(
                    "`input_prompt_embeds` and `input_negative_prompt_embeds` must have the same shape when passed"
                    f" directly, but got: `input_prompt_embeds` {input_prompt_embeds.shape} != `input_negative_prompt_embeds`"
                    f" {input_negative_prompt_embeds.shape}."
                )

        # `input_prompt` needs more sophisticated handling when there are multiple conditionings.
        if isinstance(self.controlnet, MultiControlNetModel):
            if isinstance(input_prompt, list):
                logger.warning(
                    f"You have {len(self.controlnet.nets)} ControlNets and you have passed {len(input_prompt)}"
                    " prompts. The conditionings will be fixed across the prompts."
                )

        # Check `input_image`
        is_compiled = hasattr(F, "scaled_dot_product_attention") and isinstance(
            self.controlnet, torch._dynamo.eval_frame.OptimizedModule
        )
        if (
            isinstance(self.controlnet, ControlNetModel)
            or is_compiled
            and isinstance(self.controlnet._orig_mod, ControlNetModel)
        ):
            self.check_image(input_image, input_prompt, input_prompt_embeds)
        elif (
            isinstance(self.controlnet, MultiControlNetModel)
            or is_compiled
            and isinstance(self.controlnet._orig_mod, MultiControlNetModel)
        ):
            if not isinstance(input_image, list):
                raise TypeError("For multiple controlnets: `input_image` must be type `list`")

            # When `input_image` is a nested list:
            # (e.g. [[canny_image_1, pose_image_1], [canny_image_2, pose_image_2]])
            elif any(isinstance(i, list) for i in input_image):
                raise ValueError("A single batch of multiple conditionings is supported at the moment.")
            elif len(input_image) != len(self.controlnet.nets):
                raise ValueError(
                    f"For multiple controlnets: `input_image` must have the same length as the number of controlnets, but"
                    f" got {len(input_image)} images and {len(self.controlnet.nets)} ControlNets."
                )

            for image_ in input_image:
                self.check_image(image_, input_prompt, input_prompt_embeds)
        else:
            assert False

        if (
            isinstance(self.controlnet, ControlNetModel)
            or is_compiled
            and isinstance(self.controlnet._orig_mod, ControlNetModel)
        ):
            if not isinstance(input_controlnet_conditioning_scale, float):
                raise TypeError("For single controlnet: `input_controlnet_conditioning_scale` must be type `float`.")
        elif (
            isinstance(self.controlnet, MultiControlNetModel)
            or is_compiled
            and isinstance(self.controlnet._orig_mod, MultiControlNetModel)
        ):
            if isinstance(input_controlnet_conditioning_scale, list):
                if any(isinstance(i, list) for i in input_controlnet_conditioning_scale):
                    raise ValueError("A single batch of multiple conditionings is supported at the moment.")
            elif isinstance(input_controlnet_conditioning_scale, list) and len(input_controlnet_conditioning_scale) != len(
                self.controlnet.nets
            ):
                raise ValueError(
                    "For multiple controlnets: When `input_controlnet_conditioning_scale` is specified as `list`, it must"
                    " have the same length as the number of controlnets."
                )
        else:
            assert False

        if len(input_control_guidance_start) != len(input_control_guidance_end):
            raise ValueError(
                f"`input_control_guidance_start` has {len(input_control_guidance_start)} elements, but"
                f" `input_control_guidance_end` has {len(input_control_guidance_end)} elements. Make sure to provide the same"
                " number of elements to each list."
            )

        if isinstance(self.controlnet, MultiControlNetModel):
            if len(input_control_guidance_start) != len(self.controlnet.nets):
                raise ValueError(
                    f"`input_control_guidance_start`: {input_control_guidance_start} has {len(input_control_guidance_start)}"
                    " elements but there are {len(self.controlnet.nets)} controlnets available. Make sure to provide"
                    f" {len(self.controlnet.nets)}."
                )

        for start, end in zip(input_control_guidance_start, input_control_guidance_end):
            if start >= end:
                raise ValueError(
                    f"Control guidance start: {start} cannot be larger or equal to control guidance end: {end}."
                )
            if start < 0.0:
                raise ValueError(f"Control guidance start: {start} can't be smaller than 0.")
            if end > 1.0:
                raise ValueError(f"Control guidance end: {end} can't be larger than 1.0.")


    


    def check_image(self, input_image, input_prompt, input_prompt_embeds):
        image_is_pil = isinstance(input_image, PIL.Image.Image)
        image_is_tensor = isinstance(input_image, torch.Tensor)
        image_is_np = isinstance(input_image, np.ndarray)
        image_is_pil_list = isinstance(input_image, list) and isinstance(input_image[0], PIL.Image.Image)
        image_is_tensor_list = isinstance(input_image, list) and isinstance(input_image[0], torch.Tensor)
        image_is_np_list = isinstance(input_image, list) and isinstance(input_image[0], np.ndarray)

        if (
            not image_is_pil
            and not image_is_tensor
            and not image_is_np
            and not image_is_pil_list
            and not image_is_tensor_list
            and not image_is_np_list
        ):
            raise TypeError(
                f"Input image must be passed and be one of PIL image, numpy array, torch tensor, list of PIL images, list of numpy arrays, or list of torch tensors, but is {type(input_image)}"
            )

        if image_is_pil:
            input_image_batch_size = 1
        else:
            input_image_batch_size = len(input_image)

        if input_prompt is not None and isinstance(input_prompt, str):
            input_prompt_batch_size = 1
        elif input_prompt is not None and isinstance(input_prompt, list):
            input_prompt_batch_size = len(input_prompt)
        elif input_prompt_embeds is not None:
            input_prompt_batch_size = input_prompt_embeds.shape[0]

        if input_image_batch_size != 1 and input_image_batch_size != input_prompt_batch_size:
            raise ValueError(
                f"If input image batch size is not 1, input image batch size must be the same as input prompt batch size."
                f" input image batch size: {input_image_batch_size}, input prompt batch size: {input_prompt_batch_size}"
            )

    def prepare_control_image(
        self,
        input_image,
        input_width,
        input_height,
        input_batch_size,
        input_num_images_per_prompt,
        input_device,
        input_dtype,
        input_do_classifier_free_guidance=False,
        input_guess_mode=False,
    ):
        image = self.control_image_processor.preprocess(input_image, height=input_height, width=input_width).to(
            dtype=torch.float32
        )
        image_batch_size = image.shape[0]

        if image_batch_size == 1:
            repeat_by = input_batch_size
        else:
            # image batch size is the same as prompt batch size
            repeat_by = input_num_images_per_prompt

        image = image.repeat_interleave(repeat_by, dim=0)

        image = image.to(device=input_device, dtype=input_dtype)

        if input_do_classifier_free_guidance and not input_guess_mode:
            image = torch.cat([image] * 2)

        return image


    def get_timesteps(self, num_steps, strength, input_device):
        init_steps = min(int(num_steps * strength), num_steps)
        start_step = max(num_steps - init_steps, 0)
        timesteps = self.scheduler.timesteps[start_step * self.scheduler.order :]
        return timesteps, num_steps - start_step


    def prepare_latents(self, input_image, timestep, input_batch_size, input_num_images_per_prompt, input_dtype, input_device, input_generator=None):
        if not isinstance(input_image, (torch.Tensor, PIL.Image.Image, list)):
            raise ValueError(f"`image` has to be of type `torch.Tensor`, `PIL.Image.Image`, or list but is {type(input_image)}")

        image = input_image.to(device=input_device, dtype=input_dtype)

        batch_size = input_batch_size * input_num_images_per_prompt

        if image.shape[1] == 4:
            init_latents = image
        else:
            if isinstance(input_generator, list) and len(input_generator) != batch_size:
                raise ValueError(
                    f"You have passed a list of generators of length {len(input_generator)}, but requested an effective batch"
                    f" size of {batch_size}. Make sure the batch size matches the length of the generators."
                )
            elif isinstance(input_generator, list):
                init_latents = [
                    retrieve_latents(self.vae.encode(image[i : i + 1]), generator=input_generator[i]) for i in range(batch_size)
                ]
                init_latents = torch.cat(init_latents, dim=0)
            else:
                init_latents = retrieve_latents(self.vae.encode(image), generator=input_generator)

            init_latents = self.vae.config.scaling_factor * init_latents

        if batch_size > init_latents.shape[0] and batch_size % init_latents.shape[0] == 0:
            deprecation_message = (
                f"You have passed {batch_size} text prompts (`prompt`), but only {init_latents.shape[0]} initial"
                " images (`image`). Initial images are now duplicating to match the number of text prompts. Note"
                " that this behavior is deprecated and will be removed in a version 1.0.0. Please make sure to update"
                " your script to pass as many initial images as text prompts to suppress this warning."
            )
            deprecate("len(prompt) != len(image)", "1.0.0", deprecation_message, standard_warn=False)
            additional_image_per_prompt = batch_size // init_latents.shape[0]
            init_latents = torch.cat([init_latents] * additional_image_per_prompt, dim=0)
        elif batch_size > init_latents.shape[0] and batch_size % init_latents.shape[0] != 0:
            raise ValueError(f"Cannot duplicate `image` of batch size {init_latents.shape[0]} to {batch_size} text prompts.")
        else:
            init_latents = torch.cat([init_latents], dim=0)

        shape = init_latents.shape
        noise = randn_tensor(shape, generator=input_generator, device=input_device, dtype=input_dtype)

        init_latents = self.scheduler.add_noise(init_latents, noise, timestep)
        latents = init_latents

        return latents


   

    def enable_freeu(self, scale_stage1: float, scale_stage2: float, backbone_scale1: float, backbone_scale2: float):
    
        if not hasattr(self, "unet"):
            raise ValueError("The pipeline must have `unet` for using FreeU.")
        self.unet.enable_freeu(s1=scale_stage1, s2=scale_stage2, b1=backbone_scale1, b2=backbone_scale2)


    def disable_freeu(self):
        """Disables the FreeU mechanism if enabled."""
        self.unet.disable_freeu()

    @torch.no_grad()
    
    def __call__(
        self,
        prompt: Union[str, List[str]] = None,
        image: PipelineImageInput = None,
        control_image: PipelineImageInput = None,
        height: Optional[int] = None,
        width: Optional[int] = None,
        strength: float = 0.8,
        num_inference_steps: int = 50,
        guidance_scale: float = 7.5,
        negative_prompt: Optional[Union[str, List[str]]] = None,
        num_images_per_prompt: Optional[int] = 1,
        eta: float = 0.0,
        generator: Optional[Union[torch.Generator, List[torch.Generator]]] = None,
        latents: Optional[torch.FloatTensor] = None,
        prompt_embeds: Optional[torch.FloatTensor] = None,
        negative_prompt_embeds: Optional[torch.FloatTensor] = None,
        output_type: Optional[str] = "pil",
        return_dict: bool = True,
        callback: Optional[Callable[[int, int, torch.FloatTensor], None]] = None,
        callback_steps: int = 1,
        cross_attention_kwargs: Optional[Dict[str, Any]] = None,
        controlnet_conditioning_scale: Union[float, List[float]] = 0.8,
        guess_mode: bool = False,
        control_guidance_start: Union[float, List[float]] = 0.0,
        control_guidance_end: Union[float, List[float]] = 1.0,
        clip_skip: Optional[int] = None,
    ):

        controlnet = self.controlnet._orig_mod if is_compiled_module(self.controlnet) else self.controlnet

        # align format for control guidance
        if not isinstance(control_guidance_start, list) and isinstance(control_guidance_end, list):
            control_guidance_start = len(control_guidance_end) * [control_guidance_start]
        elif not isinstance(control_guidance_end, list) and isinstance(control_guidance_start, list):
            control_guidance_end = len(control_guidance_start) * [control_guidance_end]
        elif not isinstance(control_guidance_start, list) and not isinstance(control_guidance_end, list):
            mult = len(controlnet.nets) if isinstance(controlnet, MultiControlNetModel) else 1
            control_guidance_start, control_guidance_end = (
                mult * [control_guidance_start],
                mult * [control_guidance_end],
            )

        # 1. Check inputs. Raise error if not correct
        self.check_inputs(
            prompt,
            control_image,
            callback_steps,
            negative_prompt,
            prompt_embeds,
            negative_prompt_embeds,
            controlnet_conditioning_scale,
            control_guidance_start,
            control_guidance_end,
        )

        # 2. Define call parameters
        if prompt is not None and isinstance(prompt, str):
            batch_size = 1
        elif prompt is not None and isinstance(prompt, list):
            batch_size = len(prompt)
        else:
            batch_size = prompt_embeds.shape[0]

        device = self._execution_device
      
        do_classifier_free_guidance = guidance_scale > 1.0

        if isinstance(controlnet, MultiControlNetModel) and isinstance(controlnet_conditioning_scale, float):
            controlnet_conditioning_scale = [controlnet_conditioning_scale] * len(controlnet.nets)

        global_pool_conditions = (
            controlnet.config.global_pool_conditions
            if isinstance(controlnet, ControlNetModel)
            else controlnet.nets[0].config.global_pool_conditions
        )
        guess_mode = guess_mode or global_pool_conditions

        # 3. Encode input prompt
        text_encoder_lora_scale = (
            cross_attention_kwargs.get("scale", None) if cross_attention_kwargs is not None else None
        )
        prompt_embeds, negative_prompt_embeds = self.encode_prompt(
            prompt,
            device,
            num_images_per_prompt,
            do_classifier_free_guidance,
            negative_prompt,
            prompt_embeds=prompt_embeds,
            negative_prompt_embeds=negative_prompt_embeds,
            lora_scale=text_encoder_lora_scale,
            clip_skip=clip_skip,
        )
  
        if do_classifier_free_guidance:
            prompt_embeds = torch.cat([negative_prompt_embeds, prompt_embeds])

        image = self.image_processor.preprocess(image, height=height, width=width).to(dtype=torch.float32)

        # 5. Prepare controlnet_conditioning_image
        if isinstance(controlnet, ControlNetModel):
            control_image = self.prepare_control_image(
                image=control_image,
                width=width,
                height=height,
                batch_size=batch_size * num_images_per_prompt,
                num_images_per_prompt=num_images_per_prompt,
                device=device,
                dtype=controlnet.dtype,
                do_classifier_free_guidance=do_classifier_free_guidance,
                guess_mode=guess_mode,
            )
        elif isinstance(controlnet, MultiControlNetModel):
            control_images = []

            for control_image_ in control_image:
                control_image_ = self.prepare_control_image(
                    image=control_image_,
                    width=width,
                    height=height,
                    batch_size=batch_size * num_images_per_prompt,
                    num_images_per_prompt=num_images_per_prompt,
                    device=device,
                    dtype=controlnet.dtype,
                    do_classifier_free_guidance=do_classifier_free_guidance,
                    guess_mode=guess_mode,
                )

                control_images.append(control_image_)

            control_image = control_images
        else:
            assert False

        # 5. Prepare timesteps
        self.scheduler.set_timesteps(num_inference_steps, device=device)
        timesteps, num_inference_steps = self.get_timesteps(num_inference_steps, strength, device)
        latent_timestep = timesteps[:1].repeat(batch_size * num_images_per_prompt)

        # 6. Prepare latent variables
        latents = self.prepare_latents(
            image,
            latent_timestep,
            batch_size,
            num_images_per_prompt,
            prompt_embeds.dtype,
            device,
            generator,
        )

        # 7. Prepare extra step kwargs. TODO: Logic should ideally just be moved out of the pipeline
        extra_step_kwargs = self.prepare_extra_step_kwargs(generator, eta)

        # 7.1 Create tensor stating which controlnets to keep
        controlnet_keep = []
        for i in range(len(timesteps)):
            keeps = [
                1.0 - float(i / len(timesteps) < s or (i + 1) / len(timesteps) > e)
                for s, e in zip(control_guidance_start, control_guidance_end)
            ]
            controlnet_keep.append(keeps[0] if isinstance(controlnet, ControlNetModel) else keeps)

        # 8. Denoising loop
        num_warmup_steps = len(timesteps) - num_inference_steps * self.scheduler.order
        with self.progress_bar(total=num_inference_steps) as progress_bar:
            for i, t in enumerate(timesteps):
                # expand the latents if we are doing classifier free guidance
                latent_model_input = torch.cat([latents] * 2) if do_classifier_free_guidance else latents
                latent_model_input = self.scheduler.scale_model_input(latent_model_input, t)

                # controlnet(s) inference
                if guess_mode and do_classifier_free_guidance:
                    # Infer ControlNet only for the conditional batch.
                    control_model_input = latents
                    control_model_input = self.scheduler.scale_model_input(control_model_input, t)
                    controlnet_prompt_embeds = prompt_embeds.chunk(2)[1]
                else:
                    control_model_input = latent_model_input
                    controlnet_prompt_embeds = prompt_embeds

                if isinstance(controlnet_keep[i], list):
                    cond_scale = [c * s for c, s in zip(controlnet_conditioning_scale, controlnet_keep[i])]
                else:
                    controlnet_cond_scale = controlnet_conditioning_scale
                    if isinstance(controlnet_cond_scale, list):
                        controlnet_cond_scale = controlnet_cond_scale[0]
                    cond_scale = controlnet_cond_scale * controlnet_keep[i]

                down_block_res_samples, mid_block_res_sample = self.controlnet(
                    control_model_input,
                    t,
                    encoder_hidden_states=controlnet_prompt_embeds,
                    controlnet_cond=control_image,
                    conditioning_scale=cond_scale,
                    guess_mode=guess_mode,
                    return_dict=False,
                )

                if guess_mode and do_classifier_free_guidance:
                    # Infered ControlNet only for the conditional batch.
                    
                    down_block_res_samples = [torch.cat([torch.zeros_like(d), d]) for d in down_block_res_samples]
                    mid_block_res_sample = torch.cat([torch.zeros_like(mid_block_res_sample), mid_block_res_sample])

                # predict the noise residual
                noise_pred = self.unet(
                    latent_model_input,
                    t,
                    encoder_hidden_states=prompt_embeds,
                    cross_attention_kwargs=cross_attention_kwargs,
                    down_block_additional_residuals=down_block_res_samples,
                    mid_block_additional_residual=mid_block_res_sample,
                    return_dict=False,
                )[0]

                # perform guidance
                if do_classifier_free_guidance:
                    noise_pred_uncond, noise_pred_text = noise_pred.chunk(2)
                    noise_pred = noise_pred_uncond + guidance_scale * (noise_pred_text - noise_pred_uncond)

                # compute the previous noisy sample x_t -> x_t-1
                latents = self.scheduler.step(noise_pred, t, latents, **extra_step_kwargs, return_dict=False)[0]

                # call the callback, if provided
                if i == len(timesteps) - 1 or ((i + 1) > num_warmup_steps and (i + 1) % self.scheduler.order == 0):
                    progress_bar.update()
                    if callback is not None and i % callback_steps == 0:
                        step_idx = i // getattr(self.scheduler, "order", 1)
                        callback(step_idx, t, latents)


        # manually for max memory savings
        if hasattr(self, "final_offload_hook") and self.final_offload_hook is not None:
            self.unet.to("cpu")
            self.controlnet.to("cpu")
            torch.cuda.empty_cache()

        if not output_type == "latent":
            image = self.vae.decode(latents / self.vae.config.scaling_factor, return_dict=False, generator=generator)[
                0
            ]
            image, has_nsfw_concept = self.run_safety_checker(image, device, prompt_embeds.dtype)
        else:
            image = latents
            has_nsfw_concept = None

        if has_nsfw_concept is None:
            do_denormalize = [True] * image.shape[0]
        else:
            do_denormalize = [not has_nsfw for has_nsfw in has_nsfw_concept]

        image = self.image_processor.postprocess(image, output_type=output_type, do_denormalize=do_denormalize)

        # Offload all models
        self.maybe_free_model_hooks()

        if not return_dict:
            return (image, has_nsfw_concept)

        return StableVictorPipelineOutput(images=image, nsfw_content_detected=has_nsfw_concept)
