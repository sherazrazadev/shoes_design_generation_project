import inspect
from typing import Any, Callable, Dict, List, Optional, Tuple, Union
import numpy as np
import PIL.Image
import torch
import torch.nn.functional as F
from transformers import CLIPTextModel, CLIPTextModelWithProjection, CLIPTokenizer
from VictorAI.utils.import_utils import is_invisible_watermark_available
from ...image_processor import PipelineImageInput, VaeImageProcessor
from ...loaders import StableVictorXLLoraLoaderMixin, TextualInversionLoaderMixin
from ...models import AutoencoderKL, ControlNetModel, UNet2DConditionModel
from ...models.attention_processor import (
    AttnProcessor2_0,
    LoRAAttnProcessor2_0,
    LoRAXFormersAttnProcessor,
    XFormersAttnProcessor,
)
from ...models.lora import adjust_lora_scale_text_encoder
from ...schedulers import KarrasVictorSchedulers
from ...utils import (
    USE_PEFT_BACKEND,
    logging,
    
    scale_lora_layers,
    unscale_lora_layers,
)
from ...utils.torch_utils import is_compiled_module, randn_tensor
from ..pipeline_utils import VictorPipeline
from ..stable_victor_xl.pipeline_output import StableVictorXLPipelineOutput


if is_invisible_watermark_available():
    from ..stable_victor_xl.watermark import StableVictorXLWatermarker

from .multicontrolnet import MultiControlNetModel


logger = logging.get_logger(__name__)  # pylint: disable=invalid-name






def retrieve_latents(encoded_output, gen):
    if hasattr(encoded_output, "latent_dist"):
        return encoded_output.latent_dist.sample(gen)
    elif hasattr(encoded_output, "latents"):
        return encoded_output.latents
    else:
        raise AttributeError("Could not access latents of provided encoded_output")



class StableVictorXLControlNetImg2ImgPipeline(
    VictorPipeline, TextualInversionLoaderMixin, StableVictorXLLoraLoaderMixin
):
   

    model_cpu_offload_seq = "text_encoder->text_encoder_2->unet->vae"
    _optional_components = ["tokenizer", "tokenizer_2", "text_encoder", "text_encoder_2"]

    def __init__(
        self,
        vae: AutoencoderKL,
        text_encoder: CLIPTextModel,
        text_encoder_2: CLIPTextModelWithProjection,
        tokenizer: CLIPTokenizer,
        tokenizer_2: CLIPTokenizer,
        unet: UNet2DConditionModel,
        controlnet: Union[ControlNetModel, List[ControlNetModel], Tuple[ControlNetModel], MultiControlNetModel],
        scheduler: KarrasVictorSchedulers,
        requires_aesthetics_score: bool = False,
        force_zeros_for_empty_prompt: bool = True,
        add_watermarker: Optional[bool] = None,
    ):
        super().__init__()

        if isinstance(controlnet, (list, tuple)):
            controlnet = MultiControlNetModel(controlnet)

        self.register_modules(
            vae=vae,
            text_encoder=text_encoder,
            text_encoder_2=text_encoder_2,
            tokenizer=tokenizer,
            tokenizer_2=tokenizer_2,
            unet=unet,
            controlnet=controlnet,
            scheduler=scheduler,
        )
        self.vae_scale_factor = 2 ** (len(self.vae.config.block_out_channels) - 1)
        self.image_processor = VaeImageProcessor(vae_scale_factor=self.vae_scale_factor, do_convert_rgb=True)
        self.control_image_processor = VaeImageProcessor(
            vae_scale_factor=self.vae_scale_factor, do_convert_rgb=True, do_normalize=False
        )
        add_watermarker = add_watermarker if add_watermarker is not None else is_invisible_watermark_available()

        if add_watermarker:
            self.watermark = StableVictorXLWatermarker()
        else:
            self.watermark = None

        self.register_to_config(force_zeros_for_empty_prompt=force_zeros_for_empty_prompt)
        self.register_to_config(requires_aesthetics_score=requires_aesthetics_score)

    def enable_vae_slicing(self):
        r"""
        Enable sliced VAE decoding. When this option is enabled, the VAE will split the input tensor in slices to
        compute decoding in several steps. This is useful to save some memory and allow larger batch sizes.
        """
        self.vae.enable_slicing()

    def disable_vae_slicing(self):
        r"""
        Disable sliced VAE decoding. If `enable_vae_slicing` was previously enabled, this method will go back to
        computing decoding in one step.
        """
        self.vae.disable_slicing()

    def enable_vae_tiling(self):
        r"""
        Enable tiled VAE decoding. When this option is enabled, the VAE will split the input tensor into tiles to
        compute decoding and encoding in several steps. This is useful for saving a large amount of memory and to allow
        processing larger images.
        """
        self.vae.enable_tiling()

    def disable_vae_tiling(self):
        r"""
        Disable tiled VAE decoding. If `enable_vae_tiling` was previously enabled, this method will go back to
        computing decoding in one step.
        """
        self.vae.disable_tiling()




    def encode_prompt(
            self,
            input_prompt: str,
            input_prompt_2: Optional[str] = None,
            used_device: Optional[torch.device] = None,
            images_per_input_prompt: int = 1,
            apply_classifier_free_guidance: bool = True,
            input_negative_prompt: Optional[str] = None,
            input_negative_prompt_2: Optional[str] = None,
            input_prompt_embeddings: Optional[torch.FloatTensor] = None,
            input_negative_prompt_embeddings: Optional[torch.FloatTensor] = None,
            input_pooled_prompt_embeddings: Optional[torch.FloatTensor] = None,
            input_negative_pooled_prompt_embeddings: Optional[torch.FloatTensor] = None,
            used_lora_scale: Optional[float] = None,
            skip_clip_layers: Optional[int] = None,
        ):
           
            used_device = used_device or self._execution_device

            # Set the LoRA scale so that monkey patched LoRA function of text encoder can correctly access it
            if used_lora_scale is not None and isinstance(self, StableVictorXLLoraLoaderMixin):
                self._lora_scale = used_lora_scale

                # Dynamically adjust the LoRA scale
                if self.text_encoder is not None:
                    if not USE_PEFT_BACKEND:
                        adjust_lora_scale_text_encoder(self.text_encoder, used_lora_scale)
                    else:
                        scale_lora_layers(self.text_encoder, used_lora_scale)

                if self.text_encoder_2 is not None:
                    if not USE_PEFT_BACKEND:
                        adjust_lora_scale_text_encoder(self.text_encoder_2, used_lora_scale)
                    else:
                        scale_lora_layers(self.text_encoder_2, used_lora_scale)

            input_prompt = [input_prompt] if isinstance(input_prompt, str) else input_prompt

            if input_prompt is not None:
                batch_size_used = len(input_prompt)
            else:
                batch_size_used = input_prompt_embeddings.shape[0]

            # Define tokenizers and text encoders
            tokenizers_used = [self.tokenizer, self.tokenizer_2] if self.tokenizer is not None else [self.tokenizer_2]
            text_encoders_used = (
                [self.text_encoder, self.text_encoder_2] if self.text_encoder is not None else [self.text_encoder_2]
            )

            if input_prompt_embeddings is None:
                input_prompt_2 = input_prompt_2 or input_prompt
                input_prompt_2 = [input_prompt_2] if isinstance(input_prompt_2, str) else input_prompt_2

                prompt_embeddings_list_used = []
                prompts_used = [input_prompt, input_prompt_2]
                for input_prompt, tokenizer, text_encoder in zip(prompts_used, tokenizers_used, text_encoders_used):
                    if isinstance(self, TextualInversionLoaderMixin):
                        input_prompt = self.maybe_convert_prompt(input_prompt, tokenizer)

                    text_inputs_used = tokenizer(
                        input_prompt,
                        padding="max_length",
                        max_length=tokenizer.model_max_length,
                        truncation=True,
                        return_tensors="pt",
                    )

                    text_input_ids_used = text_inputs_used.input_ids
                    untruncated_ids_used = tokenizer(input_prompt, padding="longest", return_tensors="pt").input_ids

                    if untruncated_ids_used.shape[-1] >= text_input_ids_used.shape[-1] and not torch.equal(
                        text_input_ids_used, untruncated_ids_used
                    ):
                        removed_text_used = tokenizer.batch_decode(
                            untruncated_ids_used[:, tokenizer.model_max_length - 1 : -1]
                        )
                        logger.warning(
                            "The following part of your input was truncated because CLIP can only handle sequences up to"
                            f" {tokenizer.model_max_length} tokens: {removed_text_used}"
                        )

                    prompt_embeddings_used = text_encoder(text_input_ids_used.to(used_device), output_hidden_states=True)

                    # We are only ALWAYS interested in the pooled output of the final text encoder
                    pooled_prompt_embeddings_used = prompt_embeddings_used[0]
                    if skip_clip_layers is None:
                        prompt_embeddings_used = prompt_embeddings_used.hidden_states[-2]
                    else:
                        prompt_embeddings_used = prompt_embeddings_used.hidden_states[-(skip_clip_layers + 2)]

                    prompt_embeddings_list_used.append(prompt_embeddings_used)

                input_prompt_embeddings = torch.concat(prompt_embeddings_list_used, dim=-1)

            zero_out_negative_prompt_used = input_negative_prompt is None and self.config.force_zeros_for_empty_prompt
            if apply_classifier_free_guidance and input_negative_prompt_embeddings is None and zero_out_negative_prompt_used:
                input_negative_prompt_embeddings = torch.zeros_like(input_prompt_embeddings)
                input_negative_pooled_prompt_embeddings = torch.zeros_like(pooled_prompt_embeddings_used)
            elif apply_classifier_free_guidance and input_negative_prompt_embeddings is None:
                input_negative_prompt = input_negative_prompt or ""
                input_negative_prompt_2 = input_negative_prompt_2 or input_negative_prompt

                input_negative_prompt = (
                    batch_size_used * [input_negative_prompt] if isinstance(input_negative_prompt, str) else input_negative_prompt
                )
                input_negative_prompt_2 = (
                    batch_size_used * [input_negative_prompt_2] if isinstance(input_negative_prompt_2, str) else input_negative_prompt_2
                )

                uncond_tokens_used: List[str]
                if input_prompt is not None and type(input_prompt) is not type(input_negative_prompt):
                    raise TypeError(
                        f"`input_negative_prompt` should be the same type as `input_prompt`, but got {type(input_negative_prompt)} !="
                        f" {type(input_prompt)}."
                    )
                elif batch_size_used != len(input_negative_prompt):
                    raise ValueError(
                        f"`input_negative_prompt`: {input_negative_prompt} has batch size {len(input_negative_prompt)}, but `input_prompt`:"
                        f" {input_prompt} has batch size {batch_size_used}. Please make sure that passed `input_negative_prompt` matches"
                        " the batch size of `input_prompt`."
                    )
                else:
                    uncond_tokens_used = [input_negative_prompt, input_negative_prompt_2]

                negative_prompt_embeddings_list_used = []
                for input_negative_prompt, tokenizer, text_encoder in zip(uncond_tokens_used, tokenizers_used, text_encoders_used):
                    if isinstance(self, TextualInversionLoaderMixin):
                        input_negative_prompt = self.maybe_convert_prompt(input_negative_prompt, tokenizer)

                    max_length_used = input_prompt_embeddings.shape[1]
                    uncond_input_used = tokenizer(
                        input_negative_prompt,
                        padding="max_length",
                        max_length=max_length_used,
                        truncation=True,
                        return_tensors="pt",
                    )

                    negative_prompt_embeddings_used = text_encoder(
                        uncond_input_used.input_ids.to(used_device),
                        output_hidden_states=True,
                    )
                    # We are only ALWAYS interested in the pooled output of the final text encoder
                    negative_pooled_prompt_embeddings_used = negative_prompt_embeddings_used[0]
                    negative_prompt_embeddings_used = negative_prompt_embeddings_used.hidden_states[-2]

                    negative_prompt_embeddings_list_used.append(negative_prompt_embeddings_used)

                input_negative_prompt_embeddings = torch.concat(negative_prompt_embeddings_list_used, dim=-1)

            if self.text_encoder_2 is not None:
                input_prompt_embeddings = input_prompt_embeddings.to(dtype=self.text_encoder_2.dtype, device=used_device)
            else:
                input_prompt_embeddings = input_prompt_embeddings.to(dtype=self.unet.dtype, device=used_device)

            bs_embed_used, seq_len_used, _ = input_prompt_embeddings.shape
            input_prompt_embeddings = input_prompt_embeddings.repeat(1, images_per_input_prompt, 1)
            input_prompt_embeddings = input_prompt_embeddings.view(bs_embed_used * images_per_input_prompt, seq_len_used, -1)

            if apply_classifier_free_guidance:
                # Duplicate unconditional embeddings for each generation per input prompt, using mps friendly method
                seq_len_used = input_negative_prompt_embeddings.shape[1]

                if self.text_encoder_2 is not None:
                    input_negative_prompt_embeddings = input_negative_prompt_embeddings.to(dtype=self.text_encoder_2.dtype, device=used_device)
                else:
                    input_negative_prompt_embeddings = input_negative_prompt_embeddings.to(dtype=self.unet.dtype, device=used_device)

                input_negative_prompt_embeddings = input_negative_prompt_embeddings.repeat(1, images_per_input_prompt, 1)
                input_negative_prompt_embeddings = input_negative_prompt_embeddings.view(
                    batch_size_used * images_per_input_prompt, seq_len_used, -1
                )

            pooled_prompt_embeddings_used = pooled_prompt_embeddings_used.repeat(1, images_per_input_prompt).view(
                bs_embed_used * images_per_input_prompt, -1
            )
            if apply_classifier_free_guidance:
                negative_pooled_prompt_embeddings_used = negative_pooled_prompt_embeddings_used.repeat(1, images_per_input_prompt).view(
                    bs_embed_used * images_per_input_prompt, -1
                )

            if self.text_encoder is not None:
                if isinstance(self, StableVictorXLLoraLoaderMixin) and USE_PEFT_BACKEND:
                    # Retrieve the original scale by scaling back the LoRA layers
                    unscale_lora_layers(self.text_encoder, used_lora_scale)

            if self.text_encoder_2 is not None:
                if isinstance(self, StableVictorXLLoraLoaderMixin) and USE_PEFT_BACKEND:
                    # Retrieve the original scale by scaling back the LoRA layers
                    unscale_lora_layers(self.text_encoder_2, used_lora_scale)

            return input_prompt_embeddings, input_negative_prompt_embeddings, pooled_prompt_embeddings_used, negative_pooled_prompt_embeddings_used


    def prepare_extra_step_kwargs(self, input_generator, learning_rate_parameter):
       
        accepts_learning_rate = "learning_rate" in set(inspect.signature(self.scheduler.step).parameters.keys())
        extra_step_kwargs = {}
        if accepts_learning_rate:
            extra_step_kwargs["learning_rate"] = learning_rate_parameter

        # Check if the scheduler accepts a generator input.
        accepts_input_generator = "input_generator" in set(inspect.signature(self.scheduler.step).parameters.keys())
        if accepts_input_generator:
            extra_step_kwargs["input_generator"] = input_generator
        return extra_step_kwargs



    def check_inputs(
            self,
            user_input,
            user_input_2,
            input_image,
            input_strength,
            num_steps,
            callback_steps,
            neg_user_input=None,
            neg_user_input_2=None,
            user_input_embeddings=None,
            neg_user_input_embeddings=None,
            pooled_user_input_embeddings=None,
            neg_pooled_user_input_embeddings=None,
            controlnet_scale=1.0,
            control_guidance_start=0.0,
            control_guidance_end=1.0,
        ):
            if input_strength < 0 or input_strength > 1:
                raise ValueError(f"The value of input_strength should be in [0.0, 1.0] but is {input_strength}")
            if num_steps is None:
                raise ValueError("`num_steps` cannot be None.")
            elif not isinstance(num_steps, int) or num_steps <= 0:
                raise ValueError(
                    f"`num_steps` has to be a positive integer but is {num_steps} of type {type(num_steps)}."
                )
            if (callback_steps is None) or (
                callback_steps is not None and (not isinstance(callback_steps, int) or callback_steps <= 0)
            ):
                raise ValueError(
                    f"`callback_steps` has to be a positive integer but is {callback_steps} of type {type(callback_steps)}."
                )

            if user_input is not None and user_input_embeddings is not None:
                raise ValueError(
                    f"Cannot forward both `user_input`: {user_input} and `user_input_embeddings`: {user_input_embeddings}."
                    " Please make sure to only forward one of the two."
                )
            elif user_input_2 is not None and user_input_embeddings is not None:
                raise ValueError(
                    f"Cannot forward both `user_input_2`: {user_input_2} and `user_input_embeddings`: {user_input_embeddings}."
                    " Please make sure to only forward one of the two."
                )
            elif user_input is None and user_input_embeddings is None:
                raise ValueError(
                    "Provide either `user_input` or `user_input_embeddings`. Cannot leave both `user_input` and"
                    " `user_input_embeddings` undefined."
                )
            elif user_input is not None and (not isinstance(user_input, str) and not isinstance(user_input, list)):
                raise ValueError(f"`user_input` has to be of type `str` or `list` but is {type(user_input)}")
            elif user_input_2 is not None and (not isinstance(user_input_2, str) and not isinstance(user_input_2, list)):
                raise ValueError(f"`user_input_2` has to be of type `str` or `list` but is {type(user_input_2)}")

            if neg_user_input is not None and neg_user_input_embeddings is not None:
                raise ValueError(
                    f"Cannot forward both `neg_user_input`: {neg_user_input} and `neg_user_input_embeddings`:"
                    f" {neg_user_input_embeddings}. Please make sure to only forward one of the two."
                )
            elif neg_user_input_2 is not None and neg_user_input_embeddings is not None:
                raise ValueError(
                    f"Cannot forward both `neg_user_input_2`: {neg_user_input_2} and `neg_user_input_embeddings`:"
                    f" {neg_user_input_embeddings}. Please make sure to only forward one of the two."
                )

            if user_input_embeddings is not None and neg_user_input_embeddings is not None:
                if user_input_embeddings.shape != neg_user_input_embeddings.shape:
                    raise ValueError(
                        "`user_input_embeddings` and `neg_user_input_embeddings` must have the same shape when passed directly,"
                        f" but got: `user_input_embeddings` {user_input_embeddings.shape} != `neg_user_input_embeddings`"
                        f" {neg_user_input_embeddings.shape}."
                    )

            if user_input_embeddings is not None and pooled_user_input_embeddings is None:
                raise ValueError(
                    "If `user_input_embeddings` are provided, `pooled_user_input_embeddings` also has to be passed."
                    " Make sure to generate `pooled_user_input_embeddings` from the same text encoder that was used to"
                    " generate `user_input_embeddings`."
                )

            if neg_user_input_embeddings is not None and neg_pooled_user_input_embeddings is None:
                raise ValueError(
                    "If `neg_user_input_embeddings` are provided, `neg_pooled_user_input_embeddings` also has to be passed."
                    " Make sure to generate `neg_pooled_user_input_embeddings` from the same text encoder that was used to"
                    " generate `neg_user_input_embeddings`."
                )

            if isinstance(self.controlnet, MultiControlNetModel):
                if isinstance(user_input, list):
                    logger.warning(
                        f"You have {len(self.controlnet.nets)} ControlNets and you have passed {len(user_input)}"
                        " user_inputs. The conditionings will be fixed across the user_inputs."
                    )

            # Check `input_image`
            is_compiled = hasattr(F, "scaled_dot_product_attention") and isinstance(
                self.controlnet, torch._dynamo.eval_frame.OptimizedModule
            )
            if (
                isinstance(self.controlnet, ControlNetModel)
                or is_compiled
                and isinstance(self.controlnet._orig_mod, ControlNetModel)
            ):
                self.check_image(input_image, user_input, user_input_embeddings)
            elif (
                isinstance(self.controlnet, MultiControlNetModel)
                or is_compiled
                and isinstance(self.controlnet._orig_mod, MultiControlNetModel)
            ):
                if not isinstance(input_image, list):
                    raise TypeError("For multiple controlnets: `input_image` must be of type `list`")

                # When `input_image` is a nested list:
                # (e.g. [[canny_image_1, pose_image_1], [canny_image_2, pose_image_2]])
                elif any(isinstance(i, list) for i in input_image):
                    raise ValueError("A single batch of multiple conditionings is supported at the moment.")
                elif len(input_image) != len(self.controlnet.nets):
                    raise ValueError(
                        f"For multiple controlnets: `input_image` must have the same length as the number of controlnets,"
                        f" but got {len(input_image)} images and {len(self.controlnet.nets)} ControlNets."
                    )

                for img in input_image:
                    self.check_image(img, user_input, user_input_embeddings)
            else:
                assert False

            # Check `controlnet_scale`
            if (
                isinstance(self.controlnet, ControlNetModel)
                or is_compiled
                and isinstance(self.controlnet._orig_mod, ControlNetModel)
            ):
                if not isinstance(controlnet_scale, float):
                    raise TypeError("For single controlnet: `controlnet_scale` must be of type `float`.")
            elif (
                isinstance(self.controlnet, MultiControlNetModel)
                or is_compiled
                and isinstance(self.controlnet._orig_mod, MultiControlNetModel)
            ):
                if isinstance(controlnet_scale, list):
                    if any(isinstance(i, list) for i in controlnet_scale):
                        raise ValueError("A single batch of multiple conditionings is supported at the moment.")
                elif isinstance(controlnet_scale, list) and len(controlnet_scale) != len(self.controlnet.nets):
                    raise ValueError(
                        "For multiple controlnets: When `controlnet_scale` is specified as `list`, it must have the same"
                        " length as the number of controlnets."
                    )
            else:
                assert False

            if not isinstance(control_guidance_start, (tuple, list)):
                control_guidance_start = [control_guidance_start]

            if not isinstance(control_guidance_end, (tuple, list)):
                control_guidance_end = [control_guidance_end]

            if len(control_guidance_start) != len(control_guidance_end):
                raise ValueError(
                    f"`control_guidance_start` has {len(control_guidance_start)} elements, but `control_guidance_end` has"
                    f" {len(control_guidance_end)} elements. Make sure to provide the same number of elements to each list."
                )

            if isinstance(self.controlnet, MultiControlNetModel):
                if len(control_guidance_start) != len(self.controlnet.nets):
                    raise ValueError(
                        f"`control_guidance_start`: {control_guidance_start} has {len(control_guidance_start)} elements but"
                        f" there are {len(self.controlnet.nets)} controlnets available. Make sure to provide {len(self.controlnet.nets)}."
                    )

            for start, end in zip(control_guidance_start, control_guidance_end):
                if start >= end:
                    raise ValueError(f"Control guidance start: {start} cannot be larger or equal to control guidance end: {end}.")
                if start < 0.0:
                    raise ValueError(f"Control guidance start: {start} cannot be smaller than 0.")
                if end > 1.0:
                    raise ValueError(f"Control guidance end: {end} cannot be larger than 1.0.")


    def check_image(self, image, prompt, prompt_embeds):
        image_is_pil = isinstance(image, PIL.Image.Image)
        image_is_tensor = isinstance(image, torch.Tensor)
        image_is_np = isinstance(image, np.ndarray)
        image_is_pil_list = isinstance(image, list) and isinstance(image[0], PIL.Image.Image)
        image_is_tensor_list = isinstance(image, list) and isinstance(image[0], torch.Tensor)
        image_is_np_list = isinstance(image, list) and isinstance(image[0], np.ndarray)

        if (
            not image_is_pil
            and not image_is_tensor
            and not image_is_np
            and not image_is_pil_list
            and not image_is_tensor_list
            and not image_is_np_list
        ):
            raise TypeError(
                f"image must be passed and be one of PIL image, numpy array, torch tensor, list of PIL images, list of numpy arrays or list of torch tensors, but is {type(image)}"
            )

        if image_is_pil:
            image_batch_size = 1
        else:
            image_batch_size = len(image)

        if prompt is not None and isinstance(prompt, str):
            prompt_batch_size = 1
        elif prompt is not None and isinstance(prompt, list):
            prompt_batch_size = len(prompt)
        elif prompt_embeds is not None:
            prompt_batch_size = prompt_embeds.shape[0]

        if image_batch_size != 1 and image_batch_size != prompt_batch_size:
            raise ValueError(
                f"If image batch size is not 1, image batch size must be same as prompt batch size. image batch size: {image_batch_size}, prompt batch size: {prompt_batch_size}"
            )

   
    def prepare_control_image(
        self,
        input_image,
        target_width,
        target_height,
        target_batch_size,
        images_per_prompt,
        computation_device,
        data_type,
        enable_classifier_guidance=False,
        enable_guess_mode=False,
    ):
        processed_image = self.control_image_processor.preprocess(input_image, height=target_height, width=target_width).to(dtype=torch.float32)
        processed_image_batch_size = processed_image.shape[0]

        if processed_image_batch_size == 1:
            repetition_factor = target_batch_size
        else:
            # Image batch size is the same as prompt batch size
            repetition_factor = images_per_prompt

        processed_image = processed_image.repeat_interleave(repetition_factor, dim=0)

        processed_image = processed_image.to(device=computation_device, dtype=data_type)

        if enable_classifier_guidance and not enable_guess_mode:
            processed_image = torch.cat([processed_image] * 2)

        return processed_image



    def get_timesteps(self, total_inference_steps, strength_factor, computation_device):
        # Get the original timestep using initial_timestep
        initial_timestep = min(int(total_inference_steps * strength_factor), total_inference_steps)

        time_start = max(total_inference_steps - initial_timestep, 0)
        calculated_timesteps = self.scheduler.timesteps[time_start * self.scheduler.order :]

        return calculated_timesteps, total_inference_steps - time_start

    
    def prepare_latents(
            self, input_image, current_timestep, batch_size_param, images_per_prompt_count, data_type, execution_device, custom_generator=None, apply_noise=True
        ):
        if not isinstance(input_image, (torch.Tensor, PIL.Image.Image, list)):
            raise ValueError(
                f"`input_image` has to be of type `torch.Tensor`, `PIL.Image.Image` or list but is {type(input_image)}"
            )

        if hasattr(self, "final_offload_hook") and self.final_offload_hook is not None:
            self.text_encoder_2.to("cpu")
            torch.cuda.empty_cache()

        input_image = input_image.to(device=execution_device, dtype=data_type)

        effective_batch_size = batch_size_param * images_per_prompt_count

        if input_image.shape[1] == 4:
            initial_latents = input_image

        else:
            if self.vae.config.force_upcast:
                input_image = input_image.float()
                self.vae.to(dtype=torch.float32)

            if isinstance(custom_generator, list) and len(custom_generator) != effective_batch_size:
                raise ValueError(
                    f"You have passed a list of generators of length {len(custom_generator)}, but requested an effective batch"
                    f" size of {effective_batch_size}. Make sure the batch size matches the length of the generators."
                )

            elif isinstance(custom_generator, list):
                initial_latents = [
                    retrieve_latents(self.vae.encode(input_image[i : i + 1]), generator=custom_generator[i])
                    for i in range(effective_batch_size)
                ]
                initial_latents = torch.cat(initial_latents, dim=0)
            else:
                initial_latents = retrieve_latents(self.vae.encode(input_image), generator=custom_generator)

            if self.vae.config.force_upcast:
                self.vae.to(data_type)

            initial_latents = initial_latents.to(data_type)
            initial_latents = self.vae.config.scaling_factor * initial_latents

        if effective_batch_size > initial_latents.shape[0] and effective_batch_size % initial_latents.shape[0] == 0:
            # expand initial_latents for effective_batch_size
            additional_images_per_prompt = effective_batch_size // initial_latents.shape[0]
            initial_latents = torch.cat([initial_latents] * additional_images_per_prompt, dim=0)
        elif effective_batch_size > initial_latents.shape[0] and effective_batch_size % initial_latents.shape[0] != 0:
            raise ValueError(
                f"Cannot duplicate `input_image` of batch size {initial_latents.shape[0]} to {effective_batch_size} text prompts."
            )
        else:
            initial_latents = torch.cat([initial_latents], dim=0)

        if apply_noise:
            shape = initial_latents.shape
            noise = randn_tensor(shape, generator=custom_generator, device=execution_device, dtype=data_type)
            # get latents
            initial_latents = self.scheduler.add_noise(initial_latents, noise, current_timestep)

        latents_result = initial_latents

        return latents_result


    
    def _get_add_time_ids(
            self,
            orig_size,
            crops_coords_tl,
            tgt_size,
            aesthetic_score,
            neg_aesthetic_score,
            neg_orig_size,
            neg_crops_coords_tl,
            neg_tgt_size,
            data_type,
            text_encoder_proj_dim=None,
        ):
        if self.config.requires_aesthetics_score:
            add_time_ids = list(orig_size + crops_coords_tl + (aesthetic_score,))
            add_neg_time_ids = list(
                neg_orig_size + neg_crops_coords_tl + (neg_aesthetic_score,)
            )
        else:
            add_time_ids = list(orig_size + crops_coords_tl + tgt_size)
            add_neg_time_ids = list(neg_orig_size + crops_coords_tl + neg_tgt_size)

        passed_add_embed_dim = (
            self.unet.config.addition_time_embed_dim * len(add_time_ids) + text_encoder_proj_dim
        )
        expected_add_embed_dim = self.unet.add_embedding.linear_1.in_features

        if (
            expected_add_embed_dim > passed_add_embed_dim
            and (expected_add_embed_dim - passed_add_embed_dim) == self.unet.config.addition_time_embed_dim
        ):
            raise ValueError(
                f"Model expects an added time embedding vector of length {expected_add_embed_dim}, but a vector of {passed_add_embed_dim} was created. Please make sure to enable `requires_aesthetics_score` with `pipe.register_to_config(requires_aesthetics_score=True)` to make sure `aesthetic_score` {aesthetic_score} and `neg_aesthetic_score` {neg_aesthetic_score} is correctly used by the model."
            )
        elif (
            expected_add_embed_dim < passed_add_embed_dim
            and (passed_add_embed_dim - expected_add_embed_dim) == self.unet.config.addition_time_embed_dim
        ):
            raise ValueError(
                f"Model expects an added time embedding vector of length {expected_add_embed_dim}, but a vector of {passed_add_embed_dim} was created. Please make sure to disable `requires_aesthetics_score` with `pipe.register_to_config(requires_aesthetics_score=False)` to make sure `tgt_size` {tgt_size} is correctly used by the model."
            )
        elif expected_add_embed_dim != passed_add_embed_dim:
            raise ValueError(
                f"Model expects an added time embedding vector of length {expected_add_embed_dim}, but a vector of {passed_add_embed_dim} was created. The model has an incorrect config. Please check `unet.config.time_embedding_type` and `text_encoder_2.config.projection_dim`."
            )

        add_time_ids = torch.tensor([add_time_ids], dtype=data_type)
        add_neg_time_ids = torch.tensor([add_neg_time_ids], dtype=data_type)

        return add_time_ids, add_neg_time_ids


    
    def upcast_vae(self):
        data_type = self.vae.data_type
        self.vae.to(dtype=torch.float32)
        use_torch_2_0_or_xformers = isinstance(
            self.vae.decoder.mid_block.attentions[0].processor,
            (
                AttnProcessor2_0,
                XFormersAttnProcessor,
                LoRAXFormersAttnProcessor,
                LoRAAttnProcessor2_0,
            ),
        )
      
        if use_torch_2_0_or_xformers:
            self.vae.post_quant_conv.to(data_type)
            self.vae.decoder.conv_in.to(data_type)
            self.vae.decoder.mid_block.to(data_type)


 

    def enable_freeu(self, scale_stage1: float, scale_stage2: float, backbone_scale1: float, backbone_scale2: float):
      
        if not hasattr(self, "unet"):
            raise ValueError("The pipeline must have `unet` for using FreeU.")
        self.unet.enable_freeu(s1=scale_stage1, s2=scale_stage2, b1=backbone_scale1, b2=backbone_scale2)



    def disable_freeu(self):
        """Disables the FreeU mechanism if enabled."""
        self.unet.disable_freeu()

    @torch.no_grad()
    
    def __call__(
        self,
        prompt: Union[str, List[str]] = None,
        prompt_2: Optional[Union[str, List[str]]] = None,
        image: PipelineImageInput = None,
        control_image: PipelineImageInput = None,
        height: Optional[int] = None,
        width: Optional[int] = None,
        strength: float = 0.8,
        num_inference_steps: int = 50,
        guidance_scale: float = 5.0,
        negative_prompt: Optional[Union[str, List[str]]] = None,
        negative_prompt_2: Optional[Union[str, List[str]]] = None,
        num_images_per_prompt: Optional[int] = 1,
        eta: float = 0.0,
        generator: Optional[Union[torch.Generator, List[torch.Generator]]] = None,
        latents: Optional[torch.FloatTensor] = None,
        prompt_embeds: Optional[torch.FloatTensor] = None,
        negative_prompt_embeds: Optional[torch.FloatTensor] = None,
        pooled_prompt_embeds: Optional[torch.FloatTensor] = None,
        negative_pooled_prompt_embeds: Optional[torch.FloatTensor] = None,
        output_type: Optional[str] = "pil",
        return_dict: bool = True,
        callback: Optional[Callable[[int, int, torch.FloatTensor], None]] = None,
        callback_steps: int = 1,
        cross_attention_kwargs: Optional[Dict[str, Any]] = None,
        controlnet_conditioning_scale: Union[float, List[float]] = 0.8,
        guess_mode: bool = False,
        control_guidance_start: Union[float, List[float]] = 0.0,
        control_guidance_end: Union[float, List[float]] = 1.0,
        original_size: Tuple[int, int] = None,
        crops_coords_top_left: Tuple[int, int] = (0, 0),
        target_size: Tuple[int, int] = None,
        negative_original_size: Optional[Tuple[int, int]] = None,
        negative_crops_coords_top_left: Tuple[int, int] = (0, 0),
        negative_target_size: Optional[Tuple[int, int]] = None,
        aesthetic_score: float = 6.0,
        negative_aesthetic_score: float = 2.5,
        clip_skip: Optional[int] = None,
    ):
    
        controlnet = self.controlnet._orig_mod if is_compiled_module(self.controlnet) else self.controlnet

        # align format for control guidance
        if not isinstance(control_guidance_start, list) and isinstance(control_guidance_end, list):
            control_guidance_start = len(control_guidance_end) * [control_guidance_start]
        elif not isinstance(control_guidance_end, list) and isinstance(control_guidance_start, list):
            control_guidance_end = len(control_guidance_start) * [control_guidance_end]
        elif not isinstance(control_guidance_start, list) and not isinstance(control_guidance_end, list):
            mult = len(controlnet.nets) if isinstance(controlnet, MultiControlNetModel) else 1
            control_guidance_start, control_guidance_end = (
                mult * [control_guidance_start],
                mult * [control_guidance_end],
            )

        self.check_inputs(
            prompt,
            prompt_2,
            control_image,
            strength,
            num_inference_steps,
            callback_steps,
            negative_prompt,
            negative_prompt_2,
            prompt_embeds,
            negative_prompt_embeds,
            pooled_prompt_embeds,
            negative_pooled_prompt_embeds,
            controlnet_conditioning_scale,
            control_guidance_start,
            control_guidance_end,
        )

        # 2. Define call parameters
        if prompt is not None and isinstance(prompt, str):
            batch_size = 1
        elif prompt is not None and isinstance(prompt, list):
            batch_size = len(prompt)
        else:
            batch_size = prompt_embeds.shape[0]

        device = self._execution_device
   
        do_classifier_free_guidance = guidance_scale > 1.0

        if isinstance(controlnet, MultiControlNetModel) and isinstance(controlnet_conditioning_scale, float):
            controlnet_conditioning_scale = [controlnet_conditioning_scale] * len(controlnet.nets)

        global_pool_conditions = (
            controlnet.config.global_pool_conditions
            if isinstance(controlnet, ControlNetModel)
            else controlnet.nets[0].config.global_pool_conditions
        )
        guess_mode = guess_mode or global_pool_conditions

        # 3. Encode input prompt
        text_encoder_lora_scale = (
            cross_attention_kwargs.get("scale", None) if cross_attention_kwargs is not None else None
        )
        (
            prompt_embeds,
            negative_prompt_embeds,
            pooled_prompt_embeds,
            negative_pooled_prompt_embeds,
        ) = self.encode_prompt(
            prompt,
            prompt_2,
            device,
            num_images_per_prompt,
            do_classifier_free_guidance,
            negative_prompt,
            negative_prompt_2,
            prompt_embeds=prompt_embeds,
            negative_prompt_embeds=negative_prompt_embeds,
            pooled_prompt_embeds=pooled_prompt_embeds,
            negative_pooled_prompt_embeds=negative_pooled_prompt_embeds,
            lora_scale=text_encoder_lora_scale,
            clip_skip=clip_skip,
        )

        image = self.image_processor.preprocess(image, height=height, width=width).to(dtype=torch.float32)

        if isinstance(controlnet, ControlNetModel):
            control_image = self.prepare_control_image(
                image=control_image,
                width=width,
                height=height,
                batch_size=batch_size * num_images_per_prompt,
                num_images_per_prompt=num_images_per_prompt,
                device=device,
                dtype=controlnet.dtype,
                do_classifier_free_guidance=do_classifier_free_guidance,
                guess_mode=guess_mode,
            )
            height, width = control_image.shape[-2:]
        elif isinstance(controlnet, MultiControlNetModel):
            control_images = []

            for control_image_ in control_image:
                control_image_ = self.prepare_control_image(
                    image=control_image_,
                    width=width,
                    height=height,
                    batch_size=batch_size * num_images_per_prompt,
                    num_images_per_prompt=num_images_per_prompt,
                    device=device,
                    dtype=controlnet.dtype,
                    do_classifier_free_guidance=do_classifier_free_guidance,
                    guess_mode=guess_mode,
                )

                control_images.append(control_image_)

            control_image = control_images
            height, width = control_image[0].shape[-2:]
        else:
            assert False

        self.scheduler.set_timesteps(num_inference_steps, device=device)
        timesteps, num_inference_steps = self.get_timesteps(num_inference_steps, strength, device)
        latent_timestep = timesteps[:1].repeat(batch_size * num_images_per_prompt)

        # 6. Prepare latent variables
        latents = self.prepare_latents(
            image,
            latent_timestep,
            batch_size,
            num_images_per_prompt,
            prompt_embeds.dtype,
            device,
            generator,
            True,
        )

        extra_step_kwargs = self.prepare_extra_step_kwargs(generator, eta)

        controlnet_keep = []
        for i in range(len(timesteps)):
            keeps = [
                1.0 - float(i / len(timesteps) < s or (i + 1) / len(timesteps) > e)
                for s, e in zip(control_guidance_start, control_guidance_end)
            ]
            controlnet_keep.append(keeps[0] if isinstance(controlnet, ControlNetModel) else keeps)

        if isinstance(control_image, list):
            original_size = original_size or control_image[0].shape[-2:]
        else:
            original_size = original_size or control_image.shape[-2:]
        target_size = target_size or (height, width)

        if negative_original_size is None:
            negative_original_size = original_size
        if negative_target_size is None:
            negative_target_size = target_size
        add_text_embeds = pooled_prompt_embeds

        if self.text_encoder_2 is None:
            text_encoder_projection_dim = int(pooled_prompt_embeds.shape[-1])
        else:
            text_encoder_projection_dim = self.text_encoder_2.config.projection_dim

        add_time_ids, add_neg_time_ids = self._get_add_time_ids(
            original_size,
            crops_coords_top_left,
            target_size,
            aesthetic_score,
            negative_aesthetic_score,
            negative_original_size,
            negative_crops_coords_top_left,
            negative_target_size,
            dtype=prompt_embeds.dtype,
            text_encoder_projection_dim=text_encoder_projection_dim,
        )
        add_time_ids = add_time_ids.repeat(batch_size * num_images_per_prompt, 1)

        if do_classifier_free_guidance:
            prompt_embeds = torch.cat([negative_prompt_embeds, prompt_embeds], dim=0)
            add_text_embeds = torch.cat([negative_pooled_prompt_embeds, add_text_embeds], dim=0)
            add_neg_time_ids = add_neg_time_ids.repeat(batch_size * num_images_per_prompt, 1)
            add_time_ids = torch.cat([add_neg_time_ids, add_time_ids], dim=0)

        prompt_embeds = prompt_embeds.to(device)
        add_text_embeds = add_text_embeds.to(device)
        add_time_ids = add_time_ids.to(device)

        # 8. Denoising loop
        num_warmup_steps = len(timesteps) - num_inference_steps * self.scheduler.order
        with self.progress_bar(total=num_inference_steps) as progress_bar:
            for i, t in enumerate(timesteps):
                # expand the latents if we are doing classifier free guidance
                latent_model_input = torch.cat([latents] * 2) if do_classifier_free_guidance else latents
                latent_model_input = self.scheduler.scale_model_input(latent_model_input, t)

                added_cond_kwargs = {"text_embeds": add_text_embeds, "time_ids": add_time_ids}

                # controlnet(s) inference
                if guess_mode and do_classifier_free_guidance:
                    # Infer ControlNet only for the conditional batch.
                    control_model_input = latents
                    control_model_input = self.scheduler.scale_model_input(control_model_input, t)
                    controlnet_prompt_embeds = prompt_embeds.chunk(2)[1]
                    controlnet_added_cond_kwargs = {
                        "text_embeds": add_text_embeds.chunk(2)[1],
                        "time_ids": add_time_ids.chunk(2)[1],
                    }
                else:
                    control_model_input = latent_model_input
                    controlnet_prompt_embeds = prompt_embeds
                    controlnet_added_cond_kwargs = added_cond_kwargs

                if isinstance(controlnet_keep[i], list):
                    cond_scale = [c * s for c, s in zip(controlnet_conditioning_scale, controlnet_keep[i])]
                else:
                    controlnet_cond_scale = controlnet_conditioning_scale
                    if isinstance(controlnet_cond_scale, list):
                        controlnet_cond_scale = controlnet_cond_scale[0]
                    cond_scale = controlnet_cond_scale * controlnet_keep[i]

                down_block_res_samples, mid_block_res_sample = self.controlnet(
                    control_model_input,
                    t,
                    encoder_hidden_states=controlnet_prompt_embeds,
                    controlnet_cond=control_image,
                    conditioning_scale=cond_scale,
                    guess_mode=guess_mode,
                    added_cond_kwargs=controlnet_added_cond_kwargs,
                    return_dict=False,
                )

                if guess_mode and do_classifier_free_guidance:
                    
                    down_block_res_samples = [torch.cat([torch.zeros_like(d), d]) for d in down_block_res_samples]
                    mid_block_res_sample = torch.cat([torch.zeros_like(mid_block_res_sample), mid_block_res_sample])

                # predict the noise residual
                noise_pred = self.unet(
                    latent_model_input,
                    t,
                    encoder_hidden_states=prompt_embeds,
                    cross_attention_kwargs=cross_attention_kwargs,
                    down_block_additional_residuals=down_block_res_samples,
                    mid_block_additional_residual=mid_block_res_sample,
                    added_cond_kwargs=added_cond_kwargs,
                    return_dict=False,
                )[0]

                # perform guidance
                if do_classifier_free_guidance:
                    noise_pred_uncond, noise_pred_text = noise_pred.chunk(2)
                    noise_pred = noise_pred_uncond + guidance_scale * (noise_pred_text - noise_pred_uncond)

                # compute the previous noisy sample x_t -> x_t-1
                latents = self.scheduler.step(noise_pred, t, latents, **extra_step_kwargs, return_dict=False)[0]

                # call the callback, if provided
                if i == len(timesteps) - 1 or ((i + 1) > num_warmup_steps and (i + 1) % self.scheduler.order == 0):
                    progress_bar.update()
                    if callback is not None and i % callback_steps == 0:
                        step_idx = i // getattr(self.scheduler, "order", 1)
                        callback(step_idx, t, latents)

        if hasattr(self, "final_offload_hook") and self.final_offload_hook is not None:
            self.unet.to("cpu")
            self.controlnet.to("cpu")
            torch.cuda.empty_cache()

        if not output_type == "latent":
            # make sure the VAE is in float32 mode, as it overflows in float16
            needs_upcasting = self.vae.dtype == torch.float16 and self.vae.config.force_upcast

            if needs_upcasting:
                self.upcast_vae()
                latents = latents.to(next(iter(self.vae.post_quant_conv.parameters())).dtype)

            image = self.vae.decode(latents / self.vae.config.scaling_factor, return_dict=False)[0]

            # cast back to fp16 if needed
            if needs_upcasting:
                self.vae.to(dtype=torch.float16)
        else:
            image = latents
            return StableVictorXLPipelineOutput(images=image)

        if self.watermark is not None:
            image = self.watermark.apply_watermark(image)

        image = self.image_processor.postprocess(image, output_type=output_type)

        # Offload all models
        self.maybe_free_model_hooks()

        if not return_dict:
            return (image,)

        return StableVictorXLPipelineOutput(images=image)
