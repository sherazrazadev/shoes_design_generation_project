import inspect
from typing import Any, Callable, Dict, List, Optional, Tuple, Union
import numpy as np
import PIL.Image
import torch
import torch.nn.functional as F
from transformers import CLIPImageProcessor, CLIPTextModel, CLIPTokenizer
from ...image_processor import PipelineImageInput, VaeImageProcessor
from ...loaders import FromSingleFileMixin, LoraLoaderMixin, TextualInversionLoaderMixin
from ...models import AutoencoderKL, ControlNetModel, UNet2DConditionModel
from ...models.lora import adjust_lora_scale_text_encoder
from ...schedulers import KarrasVictorSchedulers
from ...utils import (
    USE_PEFT_BACKEND,
    deprecate,
    logging,
    scale_lora_layers,
    unscale_lora_layers,
)
from ...utils.torch_utils import is_compiled_module, randn_tensor
from ..pipeline_utils import VictorPipeline
from ..stable_victor import StableVictorPipelineOutput
from ..stable_victor.safety_checker import StableVictorSafetyChecker
from .multicontrolnet import MultiControlNetModel


logger = logging.get_logger(__name__)  # pylint: disable=invalid-name



def retrieve_latents(encoded_output, custom_generator):
    if hasattr(encoded_output, "latent_dist"):
        return encoded_output.latent_dist.sample(custom_generator)
    elif hasattr(encoded_output, "latents"):
        return encoded_output.latents
    else:
        raise AttributeError("Could not access latents of provided encoded_output")



def prepare_mask_and_masked_image(input_image, input_mask, input_height, input_width, return_original=False):
    
    deprecation_message = "The prepare_mask_and_masked_image method is deprecated and will be removed in a future version. Please use VaeImageProcessor.preprocess instead"
    deprecate(
        "prepare_mask_and_masked_image",
        "0.30.0",
        deprecation_message,
    )
    if input_image is None:
        raise ValueError("`input_image` input cannot be undefined.")

    if input_mask is None:
        raise ValueError("`input_mask` input cannot be undefined.")

    if isinstance(input_image, torch.Tensor):
        if not isinstance(input_mask, torch.Tensor):
            raise TypeError(f"`input_image` is a torch.Tensor but `input_mask` (type: {type(input_mask)} is not")

        # Batch single image
        if input_image.ndim == 3:
            assert input_image.shape[0] == 3, "Image outside a batch should be of shape (3, H, W)"
            input_image = input_image.unsqueeze(0)

        # Batch and add channel dim for single mask
        if input_mask.ndim == 2:
            input_mask = input_mask.unsqueeze(0).unsqueeze(0)

        # Batch single mask or add channel dim
        if input_mask.ndim == 3:
            # Single batched mask, no channel dim or single mask not batched but channel dim
            if input_mask.shape[0] == 1:
                input_mask = input_mask.unsqueeze(0)

            # Batched masks no channel dim
            else:
                input_mask = input_mask.unsqueeze(1)

        assert input_image.ndim == 4 and input_mask.ndim == 4, "Image and Mask must have 4 dimensions"
        assert input_image.shape[-2:] == input_mask.shape[-2:], "Image and Mask must have the same spatial dimensions"
        assert input_image.shape[0] == input_mask.shape[0], "Image and Mask must have the same batch size"

        # Check image is in [-1, 1]
        if input_image.min() < -1 or input_image.max() > 1:
            raise ValueError("Image should be in [-1, 1] range")

        # Check mask is in [0, 1]
        if input_mask.min() < 0 or input_mask.max() > 1:
            raise ValueError("Mask should be in [0, 1] range")

        # Binarize mask
        input_mask[input_mask < 0.5] = 0
        input_mask[input_mask >= 0.5] = 1

        # Image as float32
        input_image = input_image.to(dtype=torch.float32)
    elif isinstance(input_mask, torch.Tensor):
        raise TypeError(f"`input_mask` is a torch.Tensor but `input_image` (type: {type(input_image)} is not")
    else:
        # preprocess image
        if isinstance(input_image, (PIL.Image.Image, np.ndarray)):
            input_image = [input_image]
        if isinstance(input_image, list) and isinstance(input_image[0], PIL.Image.Image):
            # resize all images w.r.t passed height an width
            input_image = [i.resize((input_width, input_height), resample=PIL.Image.LANCZOS) for i in input_image]
            input_image = [np.array(i.convert("RGB"))[None, :] for i in input_image]
            input_image = np.concatenate(input_image, axis=0)
        elif isinstance(input_image, list) and isinstance(input_image[0], np.ndarray):
            input_image = np.concatenate([i[None, :] for i in input_image], axis=0)

        input_image = input_image.transpose(0, 3, 1, 2)
        input_image = torch.from_numpy(input_image).to(dtype=torch.float32) / 127.5 - 1.0

        # preprocess mask
        if isinstance(input_mask, (PIL.Image.Image, np.ndarray)):
            input_mask = [input_mask]

        if isinstance(input_mask, list) and isinstance(input_mask[0], PIL.Image.Image):
            input_mask = [i.resize((input_width, input_height), resample=PIL.Image.LANCZOS) for i in input_mask]
            input_mask = np.concatenate([np.array(m.convert("L"))[None, None, :] for m in input_mask], axis=0)
            input_mask = input_mask.astype(np.float32) / 255.0
        elif isinstance(input_mask, list) and isinstance(input_mask[0], np.ndarray):
            input_mask = np.concatenate([m[None, None, :] for m in input_mask], axis=0)

        input_mask[input_mask < 0.5] = 0
        input_mask[input_mask >= 0.5] = 1
        input_mask = torch.from_numpy(input_mask)

    masked_input_image = input_image * (input_mask < 0.5)

    # n.b. ensure backwards compatibility as old function does not return input_image
    if return_original:
        return input_mask, masked_input_image, input_image

    return input_mask, masked_input_image





class StableVictorControlNetInpaintPipeline(
    VictorPipeline, TextualInversionLoaderMixin, LoraLoaderMixin, FromSingleFileMixin
):
  
    model_cpu_offload_seq = "text_encoder->unet->vae"
    _optional_components = ["safety_checker", "feature_extractor"]
    _exclude_from_cpu_offload = ["safety_checker"]

    def __init__(
        self,
        vae: AutoencoderKL,
        text_encoder: CLIPTextModel,
        tokenizer: CLIPTokenizer,
        unet: UNet2DConditionModel,
        controlnet: Union[ControlNetModel, List[ControlNetModel], Tuple[ControlNetModel], MultiControlNetModel],
        scheduler: KarrasVictorSchedulers,
        safety_checker: StableVictorSafetyChecker,
        feature_extractor: CLIPImageProcessor,
        requires_safety_checker: bool = True,
    ):
        super().__init__()

        if safety_checker is None and requires_safety_checker:
            logger.warning(
                f"You have disabled the safety checker for {self.__class__} by passing `safety_checker=None"
            )

        if safety_checker is not None and feature_extractor is None:
            raise ValueError(
                "Make sure to define a feature extractor when loading {self.__class__} if you want to use the safety"
                
            )

        if isinstance(controlnet, (list, tuple)):
            controlnet = MultiControlNetModel(controlnet)

        self.register_modules(
            vae=vae,
            text_encoder=text_encoder,
            tokenizer=tokenizer,
            unet=unet,
            controlnet=controlnet,
            scheduler=scheduler,
            safety_checker=safety_checker,
            feature_extractor=feature_extractor,
        )
        self.vae_scale_factor = 2 ** (len(self.vae.config.block_out_channels) - 1)
        self.image_processor = VaeImageProcessor(vae_scale_factor=self.vae_scale_factor)
        self.mask_processor = VaeImageProcessor(
            vae_scale_factor=self.vae_scale_factor, do_normalize=False, do_binarize=True, do_convert_grayscale=True
        )
        self.control_image_processor = VaeImageProcessor(
            vae_scale_factor=self.vae_scale_factor, do_convert_rgb=True, do_normalize=False
        )
        self.register_to_config(requires_safety_checker=requires_safety_checker)

    def enable_vae_slicing(self):
       
        self.vae.enable_slicing()

    def disable_vae_slicing(self):
      
        self.vae.disable_slicing()

    def enable_vae_tiling(self):
       
        self.vae.enable_tiling()

    def disable_vae_tiling(self):
       
        self.vae.disable_tiling()

   
    def _encode_prompt(
        self,
        input_prompt,
        input_device,
        input_num_images_per_prompt,
        input_do_classifier_free_guidance,
        input_negative_prompt=None,
        input_prompt_embeds: Optional[torch.FloatTensor] = None,
        input_negative_prompt_embeds: Optional[torch.FloatTensor] = None,
        input_lora_scale: Optional[float] = None,
        **additional_kwargs,
    ):
        deprecation_message = "`_encode_prompt()` is deprecated and it will be removed in a future version. Use `encode_prompt()` instead. Also, be aware that the output format changed from a concatenated tensor to a tuple."
        deprecate("_encode_prompt()", "1.0.0", deprecation_message, standard_warn=False)

        prompt_embeds_tuple = self.encode_prompt(
            prompt=input_prompt,
            device=input_device,
            num_images_per_prompt=input_num_images_per_prompt,
            do_classifier_free_guidance=input_do_classifier_free_guidance,
            negative_prompt=input_negative_prompt,
            prompt_embeds=input_prompt_embeds,
            negative_prompt_embeds=input_negative_prompt_embeds,
            lora_scale=input_lora_scale,
            **additional_kwargs,
        )

        # concatenate for backwards comp
        result_prompt_embeds = torch.cat([prompt_embeds_tuple[1], prompt_embeds_tuple[0]])

        return result_prompt_embeds


    def encode_prompt(
            self,
            input_prompt,
            input_device,
            input_num_images_per_prompt,
            input_do_classifier_free_guidance,
            input_negative_prompt=None,
            input_prompt_embeds: Optional[torch.FloatTensor] = None,
            input_negative_prompt_embeds: Optional[torch.FloatTensor] = None,
            input_lora_scale: Optional[float] = None,
            input_clip_skip: Optional[int] = None,
        ):
           
            # function of text encoder can correctly access it
            if input_lora_scale is not None and isinstance(self, LoraLoaderMixin):
                self._lora_scale = input_lora_scale

                # dynamically adjust the LoRA scale
                if not USE_PEFT_BACKEND:
                    adjust_lora_scale_text_encoder(self.text_encoder, input_lora_scale)
                else:
                    scale_lora_layers(self.text_encoder, input_lora_scale)

            if input_prompt is not None and isinstance(input_prompt, str):
                batch_size = 1
            elif input_prompt is not None and isinstance(input_prompt, list):
                batch_size = len(input_prompt)
            else:
                batch_size = input_prompt_embeds.shape[0]

            if input_prompt_embeds is None:
                if isinstance(self, TextualInversionLoaderMixin):
                    input_prompt = self.maybe_convert_prompt(input_prompt, self.tokenizer)

                text_inputs = self.tokenizer(
                    input_prompt,
                    padding="max_length",
                    max_length=self.tokenizer.model_max_length,
                    truncation=True,
                    return_tensors="pt",
                )
                text_input_ids = text_inputs.input_ids
                untruncated_ids = self.tokenizer(input_prompt, padding="longest", return_tensors="pt").input_ids

                if untruncated_ids.shape[-1] >= text_input_ids.shape[-1] and not torch.equal(
                    text_input_ids, untruncated_ids
                ):
                    removed_text = self.tokenizer.batch_decode(
                        untruncated_ids[:, self.tokenizer.model_max_length - 1 : -1]
                    )
                    logger.warning(
                        "The following part of your input was truncated because CLIP can only handle sequences up to"
                        f" {self.tokenizer.model_max_length} tokens: {removed_text}"
                    )

                if hasattr(self.text_encoder.config, "use_attention_mask") and self.text_encoder.config.use_attention_mask:
                    attention_mask = text_inputs.attention_mask.to(input_device)
                else:
                    attention_mask = None

                if input_clip_skip is None:
                    input_prompt_embeds = self.text_encoder(text_input_ids.to(input_device), attention_mask=attention_mask)
                    input_prompt_embeds = input_prompt_embeds[0]
                else:
                    input_prompt_embeds = self.text_encoder(
                        text_input_ids.to(input_device), attention_mask=attention_mask, output_hidden_states=True
                    )
                    
                    input_prompt_embeds = input_prompt_embeds[-1][-(input_clip_skip + 1)]
                    # We also need to apply the final LayerNorm here to not mess with the
                   
                    input_prompt_embeds = self.text_encoder.text_model.final_layer_norm(input_prompt_embeds)

            if self.text_encoder is not None:
                input_prompt_embeds_dtype = self.text_encoder.dtype
            elif self.unet is not None:
                input_prompt_embeds_dtype = self.unet.dtype
            else:
                input_prompt_embeds_dtype = input_prompt_embeds.dtype

            input_prompt_embeds = input_prompt_embeds.to(dtype=input_prompt_embeds_dtype, device=input_device)

            bs_embed, seq_len, _ = input_prompt_embeds.shape
            # duplicate text embeddings for each generation per prompt, using mps friendly method
            input_prompt_embeds = input_prompt_embeds.repeat(1, input_num_images_per_prompt, 1)
            input_prompt_embeds = input_prompt_embeds.view(bs_embed * input_num_images_per_prompt, seq_len, -1)

            # get unconditional embeddings for classifier free guidance
            if input_do_classifier_free_guidance and input_negative_prompt_embeds is None:
                uncond_tokens: List[str]
                if input_negative_prompt is None:
                    uncond_tokens = [""] * batch_size
                elif input_prompt is not None and type(input_prompt) is not type(input_negative_prompt):
                    raise TypeError(
                        f"`input_negative_prompt` should be the same type to `input_prompt`, but got {type(input_negative_prompt)} !="
                        f" {type(input_prompt)}."
                    )
                elif isinstance(input_negative_prompt, str):
                    uncond_tokens = [input_negative_prompt]
                elif batch_size != len(input_negative_prompt):
                    raise ValueError(
                        f"`input_negative_prompt`: {input_negative_prompt} has batch size {len(input_negative_prompt)}, but `input_prompt`:"
                        f" {input_prompt} has batch size {batch_size}. Please make sure that passed `input_negative_prompt` matches"
                        " the batch size of `input_prompt`."
                    )
                else:
                    uncond_tokens = input_negative_prompt

                # textual inversion: procecss multi-vector tokens if necessary
                if isinstance(self, TextualInversionLoaderMixin):
                    uncond_tokens = self.maybe_convert_prompt(uncond_tokens, self.tokenizer)

                max_length = input_prompt_embeds.shape[1]
                uncond_input = self.tokenizer(
                    uncond_tokens,
                    padding="max_length",
                    max_length=max_length,
                    truncation=True,
                    return_tensors="pt",
                )

                if hasattr(self.text_encoder.config, "use_attention_mask") and self.text_encoder.config.use_attention_mask:
                    attention_mask = uncond_input.attention_mask.to(input_device)
                else:
                    attention_mask = None

                input_negative_prompt_embeds = self.text_encoder(
                    uncond_input.input_ids.to(input_device),
                    attention_mask=attention_mask,
                )
                input_negative_prompt_embeds = input_negative_prompt_embeds[0]

            if input_do_classifier_free_guidance:
                # duplicate unconditional embeddings for each generation per prompt, using mps friendly method
                seq_len = input_negative_prompt_embeds.shape[1]

                input_negative_prompt_embeds = input_negative_prompt_embeds.to(dtype=input_prompt_embeds_dtype, device=input_device)

                input_negative_prompt_embeds = input_negative_prompt_embeds.repeat(1, input_num_images_per_prompt, 1)
                input_negative_prompt_embeds = input_negative_prompt_embeds.view(batch_size * input_num_images_per_prompt, seq_len, -1)

            if isinstance(self, LoraLoaderMixin) and USE_PEFT_BACKEND:
                # Retrieve the original scale by scaling back the LoRA layers
                unscale_lora_layers(self.text_encoder, input_lora_scale)

            return input_prompt_embeds, input_negative_prompt_embeds



 

    def run_safety_checker(self, input_image, input_device, input_dtype):
            if self.safety_checker is None:
                result_has_nsfw_concept = None
            else:
                if torch.is_tensor(input_image):
                    feature_extractor_input = self.image_processor.postprocess(input_image, output_type="pil")
                else:
                    feature_extractor_input = self.image_processor.numpy_to_pil(input_image)
                safety_checker_input = self.feature_extractor(feature_extractor_input, return_tensors="pt").to(input_device)
                processed_image, result_has_nsfw_concept = self.safety_checker(
                    images=input_image, clip_input=safety_checker_input.pixel_values.to(input_dtype)
                )
            return processed_image, result_has_nsfw_concept


  
    def decode_latents(self, input_latents):
            deprecation_warning = "The decode_latents method is deprecated and will be removed in 1.0.0. Please use VaeImageProcessor.postprocess(...) instead"
            deprecate("decode_latents", "1.0.0", deprecation_warning, standard_warn=False)

            processed_latents = 1 / self.vae.config.scaling_factor * input_latents
            decoded_image = self.vae.decode(processed_latents, return_dict=False)[0]
            decoded_image = (decoded_image / 2 + 0.5).clamp(0, 1)
            # Casting to float32 for compatibility
            decoded_image = decoded_image.cpu().permute(0, 2, 3, 1).float().numpy()
            return decoded_image



  

    def prepare_extra_step_kwargs(self, input_generator, input_eta):
       
        accepts_eta = "eta" in set(inspect.signature(self.scheduler.step).parameters.keys())
        extra_step_kwargs = {}
        if accepts_eta:
            extra_step_kwargs["eta"] = input_eta

        # Check if the scheduler accepts a generator
        accepts_generator = "generator" in set(inspect.signature(self.scheduler.step).parameters.keys())
        if accepts_generator:
            extra_step_kwargs["generator"] = input_generator
        return extra_step_kwargs

 

    def get_timesteps(self, num_steps, impact, target_device):
        initial_step = min(int(num_steps * impact), num_steps)

        start_step = max(num_steps - initial_step, 0)
        steps = self.scheduler.timesteps[start_step * self.scheduler.order :]

        return steps, num_steps - start_step




    def check_inputs(
            self,
            user_prompt,
            input_image,
            target_height,
            target_width,
            step_callback_interval,
            negative_user_prompt=None,
            user_prompt_embeddings=None,
            negative_user_prompt_embeddings=None,
            conditioning_scale=1.0,
            guidance_start=0.0,
            guidance_end=1.0,
        ):
            if target_height is not None and target_height % 8 != 0 or target_width is not None and target_width % 8 != 0:
                raise ValueError(f"`target_height` and `target_width` have to be divisible by 8 but are {target_height} and {target_width}.")

            if (step_callback_interval is None) or (
                step_callback_interval is not None and (not isinstance(step_callback_interval, int) or step_callback_interval <= 0)
            ):
                raise ValueError(
                    f"`step_callback_interval` has to be a positive integer but is {step_callback_interval} of type"
                    f" {type(step_callback_interval)}."
                )

            if user_prompt is not None and user_prompt_embeddings is not None:
                raise ValueError(
                    f"Cannot forward both `user_prompt`: {user_prompt} and `user_prompt_embeddings`: {user_prompt_embeddings}. Please make sure to"
                    " only forward one of the two."
                )
            elif user_prompt is None and user_prompt_embeddings is None:
                raise ValueError(
                    "Provide either `user_prompt` or `user_prompt_embeddings`. Cannot leave both `user_prompt` and `user_prompt_embeddings` undefined."
                )
            elif user_prompt is not None and (not isinstance(user_prompt, str) and not isinstance(user_prompt, list)):
                raise ValueError(f"`user_prompt` has to be of type `str` or `list` but is {type(user_prompt)}")

            if negative_user_prompt is not None and negative_user_prompt_embeddings is not None:
                raise ValueError(
                    f"Cannot forward both `negative_user_prompt`: {negative_user_prompt} and `negative_user_prompt_embeddings`:"
                    f" {negative_user_prompt_embeddings}. Please make sure to only forward one of the two."
                )

            if user_prompt_embeddings is not None and negative_user_prompt_embeddings is not None:
                if user_prompt_embeddings.shape != negative_user_prompt_embeddings.shape:
                    raise ValueError(
                        "`user_prompt_embeddings` and `negative_user_prompt_embeddings` must have the same shape when passed directly, but"
                        f" got: `user_prompt_embeddings` {user_prompt_embeddings.shape} != `negative_user_prompt_embeddings`"
                        f" {negative_user_prompt_embeddings.shape}."
                    )

            # `user_prompt` needs more sophisticated handling when there are multiple
            # conditionings.
            if isinstance(self.guidance_net, MultiGuidanceNetModel):
                if isinstance(user_prompt, list):
                    logger.warning(
                        f"You have {len(self.guidance_net.nets)} GuidanceNets and you have passed {len(user_prompt)}"
                        " prompts. The conditionings will be fixed across the prompts."
                    )

            # Check `input_image`
            is_compiled = hasattr(F, "scaled_dot_product_attention") and isinstance(
                self.guidance_net, torch._dynamo.eval_frame.OptimizedModule
            )
            if (
                isinstance(self.guidance_net, GuidanceNetModel)
                or is_compiled
                and isinstance(self.guidance_net._orig_mod, GuidanceNetModel)
            ):
                self.check_image(input_image, user_prompt, user_prompt_embeddings)
            elif (
                isinstance(self.guidance_net, MultiGuidanceNetModel)
                or is_compiled
                and isinstance(self.guidance_net._orig_mod, MultiGuidanceNetModel)
            ):
                if not isinstance(input_image, list):
                    raise TypeError("For multiple guidancenets: `input_image` must be type `list`")

               
                elif any(isinstance(i, list) for i in input_image):
                    raise ValueError("A single batch of multiple conditionings are supported at the moment.")
                elif len(input_image) != len(self.guidance_net.nets):
                    raise ValueError(
                        f"For multiple guidancenets: `input_image` must have the same length as the number of guidancenets, but got {len(input_image)} images and {len(self.guidance_net.nets)} GuidanceNets."
                    )

                for image_ in input_image:
                    self.check_image(image_, user_prompt, user_prompt_embeddings)
            else:
                assert False

            # Check `conditioning_scale`
            if (
                isinstance(self.guidance_net, GuidanceNetModel)
                or is_compiled
                and isinstance(self.guidance_net._orig_mod, GuidanceNetModel)
            ):
                if not isinstance(conditioning_scale, float):
                    raise TypeError("For single guidancenet: `conditioning_scale` must be type `float`.")
            elif (
                isinstance(self.guidance_net, MultiGuidanceNetModel)
                or is_compiled
                and isinstance(self.guidance_net._orig_mod, MultiGuidanceNetModel)
            ):
                if isinstance(conditioning_scale, list):
                    if any(isinstance(i, list) for i in conditioning_scale):
                        raise ValueError("A single batch of multiple conditionings are supported at the moment.")
                elif isinstance(conditioning_scale, list) and len(conditioning_scale) != len(
                    self.guidance_net.nets
                ):
                    raise ValueError(
                        "For multiple guidancenets: When `conditioning_scale` is specified as `list`, it must have"
                        " the same length as the number of guidancenets"
                    )
            else:
                assert False

            if len(guidance_start) != len(guidance_end):
                raise ValueError(
                    f"`guidance_start` has {len(guidance_start)} elements, but `guidance_end` has {len(guidance_end)} elements. Make sure to provide the same number of elements to each list."
                )

            if isinstance(self.guidance_net, MultiGuidanceNetModel):
                if len(guidance_start) != len(self.guidance_net.nets):
                    raise ValueError(
                        f"`guidance_start`: {guidance_start} has {len(guidance_start)} elements but there are {len(self.guidance_net.nets)} guidancenets available. Make sure to provide {len(self.guidance_net.nets)}."
                    )

            for start, end in zip(guidance_start, guidance_end):
                if start >= end:
                    raise ValueError(
                        f"guidance start: {start} cannot be larger or equal to guidance end: {end}."
                    )
                if start < 0.0:
                    raise ValueError(f"guidance start: {start} can't be smaller than 0.")
                if end > 1.0:
                    raise ValueError(f"guidance end: {end} can't be larger than 1.0.")




    def check_image(self, input_image, user_prompt, user_prompt_embeddings):
        image_is_pil = isinstance(input_image, PIL.Image.Image)
        image_is_tensor = isinstance(input_image, torch.Tensor)
        image_is_np = isinstance(input_image, np.ndarray)
        image_is_pil_list = isinstance(input_image, list) and isinstance(input_image[0], PIL.Image.Image)
        image_is_tensor_list = isinstance(input_image, list) and isinstance(input_image[0], torch.Tensor)
        image_is_np_list = isinstance(input_image, list) and isinstance(input_image[0], np.ndarray)

        if (
            not image_is_pil
            and not image_is_tensor
            and not image_is_np
            and not image_is_pil_list
            and not image_is_tensor_list
            and not image_is_np_list
        ):
            raise TypeError(
                f"input_image must be passed and be one of PIL image, numpy array, torch tensor, list of PIL images, list of numpy arrays, or list of torch tensors, but is {type(input_image)}"
            )

        if image_is_pil:
            image_batch_size = 1
        else:
            image_batch_size = len(input_image)

        if user_prompt is not None and isinstance(user_prompt, str):
            prompt_batch_size = 1
        elif user_prompt is not None and isinstance(user_prompt, list):
            prompt_batch_size = len(user_prompt)
        elif user_prompt_embeddings is not None:
            prompt_batch_size = user_prompt_embeddings.shape[0]

        if image_batch_size != 1 and image_batch_size != prompt_batch_size:
            raise ValueError(
                f"If image batch size is not 1, image batch size must be the same as prompt batch size. image batch size: {image_batch_size}, prompt batch size: {prompt_batch_size}"
            )


    

    def prepare_control_image(
        self,
        input_image,
        target_width,
        target_height,
        target_batch_size,
        images_per_prompt,
        target_device,
        target_dtype,
        enable_classifier_free_guidance=False,
        enable_guess_mode=False,
    ):
        processed_image = self.control_image_processor.preprocess(
            input_image, height=target_height, width=target_width
        ).to(dtype=torch.float32)
        processed_batch_size = processed_image.shape[0]

        if processed_batch_size == 1:
            repeat_factor = target_batch_size
        else:
            # Processed image batch size is the same as prompt batch size
            repeat_factor = images_per_prompt

        repeated_image = processed_image.repeat_interleave(repeat_factor, dim=0)

        repeated_image = repeated_image.to(device=target_device, dtype=target_dtype)

        if enable_classifier_free_guidance and not enable_guess_mode:
            repeated_image = torch.cat([repeated_image] * 2)

        return repeated_image


    def prepare_latents(
        self,
        target_batch_size,
        num_latents_channels,
        target_height,
        target_width,
        target_dtype,
        target_device,
        noise_generator,
        provided_latents=None,
        input_image=None,
        input_timestep=None,
        is_max_strength=True,
        include_noise=False,
        include_image_latents=False,
    ):
        latents_shape = (
            target_batch_size,
            num_latents_channels,
            target_height // self.vae_scale_factor,
            target_width // self.vae_scale_factor,
        )

        if isinstance(noise_generator, list) and len(noise_generator) != target_batch_size:
            raise ValueError(
                f"You provided a list of generators with length {len(noise_generator)}, but the requested effective batch"
                f" size is {target_batch_size}. Ensure the batch size matches the length of the generators."
            )

        if (input_image is None or input_timestep is None) and not is_max_strength:
            raise ValueError(
                "For strength < 1. initial latents are initialized as a combination of Image + Noise. However, either"
                " the image or the noise timestep has not been provided."
            )

        if include_image_latents or (provided_latents is None and not is_max_strength):
            input_image = input_image.to(device=target_device, dtype=target_dtype)

            if input_image.shape[1] == 4:
                image_latents = input_image
            else:
                image_latents = self._encode_vae_image(image=input_image, generator=noise_generator)
                image_latents = image_latents.repeat(target_batch_size // image_latents.shape[0], 1, 1, 1)

        if provided_latents is None:
            generated_noise = randn_tensor(latents_shape, generator=noise_generator, device=target_device, dtype=target_dtype)
            latents = (
                generated_noise if is_max_strength else self.scheduler.add_noise(image_latents, generated_noise, input_timestep)
            )
            latents = latents * self.scheduler.init_noise_sigma if is_max_strength else latents
        else:
            generated_noise = provided_latents.to(target_device)
            latents = generated_noise * self.scheduler.init_noise_sigma

        output_tuple = (latents,)

        if include_noise:
            output_tuple += (generated_noise,)

        if include_image_latents:
            output_tuple += (image_latents,)

        return output_tuple


    def prepare_mask_latents(
        self, input_mask, input_masked_image, target_batch_size, target_height, target_width, target_dtype, target_device, noise_generator, include_classifier_free_guidance
    ):
        # Resize the mask to match the latents shape as we concatenate the mask to the latents.
        resized_mask = torch.nn.functional.interpolate(
            input_mask, size=(target_height // self.vae_scale_factor, target_width // self.vae_scale_factor)
        )
        resized_mask = resized_mask.to(device=target_device, dtype=target_dtype)

        input_masked_image = input_masked_image.to(device=target_device, dtype=target_dtype)

        if input_masked_image.shape[1] == 4:
            masked_image_latents = input_masked_image
        else:
            masked_image_latents = self._encode_vae_image(input_masked_image, generator=noise_generator)

        # Duplicate mask and masked_image_latents for each generation per prompt using a memory-friendly method.
        if resized_mask.shape[0] < target_batch_size:
            if not target_batch_size % resized_mask.shape[0] == 0:
                raise ValueError(
                    "The passed mask and the required batch size don't match. Masks are supposed to be duplicated to"
                    f" a total batch size of {target_batch_size}, but {resized_mask.shape[0]} masks were passed. Make sure"
                    " the number of masks that you pass is divisible by the total requested batch size."
                )
            resized_mask = resized_mask.repeat(target_batch_size // resized_mask.shape[0], 1, 1, 1)

        if masked_image_latents.shape[0] < target_batch_size:
            if not target_batch_size % masked_image_latents.shape[0] == 0:
                raise ValueError(
                    "The passed images and the required batch size don't match. Images are supposed to be duplicated"
                    f" to a total batch size of {target_batch_size}, but {masked_image_latents.shape[0]} images were passed."
                    " Make sure the number of images that you pass is divisible by the total requested batch size."
                )
            masked_image_latents = masked_image_latents.repeat(target_batch_size // masked_image_latents.shape[0], 1, 1, 1)

        resized_mask = torch.cat([resized_mask] * 2) if include_classifier_free_guidance else resized_mask
        masked_image_latents = torch.cat([masked_image_latents] * 2) if include_classifier_free_guidance else masked_image_latents

        masked_image_latents = masked_image_latents.to(device=target_device, dtype=target_dtype)
        return resized_mask, masked_image_latents




    def _encode_vae_image(self, input_image: torch.Tensor, noise_generator: torch.Generator):
        if isinstance(noise_generator, list):
            encoded_latents = [
                retrieve_latents(self.vae.encode(input_image[i : i + 1]), generator=noise_generator[i])
                for i in range(input_image.shape[0])
            ]
            encoded_latents = torch.cat(encoded_latents, dim=0)
        else:
            encoded_latents = retrieve_latents(self.vae.encode(input_image), generator=noise_generator)

        scaled_latents = self.vae.config.scaling_factor * encoded_latents

        return scaled_latents


    def enable_freeu(self, scaling_factor_stage1: float, scaling_factor_stage2: float, backbone_factor_stage1: float, backbone_factor_stage2: float):
       
        if not hasattr(self, "unet"):
            raise ValueError("The pipeline must have `unet` for using FreeU.")
        self.unet.enable_freeu(s1=scaling_factor_stage1, s2=scaling_factor_stage2, b1=backbone_factor_stage1, b2=backbone_factor_stage2)

    def disable_freeu(self):
        """Disables the FreeU mechanism if enabled."""
        self.unet.disable_freeu()

    @torch.no_grad()
    def __call__(
        self,
        prompt: Union[str, List[str]] = None,
        image: PipelineImageInput = None,
        mask_image: PipelineImageInput = None,
        control_image: PipelineImageInput = None,
        height: Optional[int] = None,
        width: Optional[int] = None,
        strength: float = 1.0,
        num_inference_steps: int = 50,
        guidance_scale: float = 7.5,
        negative_prompt: Optional[Union[str, List[str]]] = None,
        num_images_per_prompt: Optional[int] = 1,
        eta: float = 0.0,
        generator: Optional[Union[torch.Generator, List[torch.Generator]]] = None,
        latents: Optional[torch.FloatTensor] = None,
        prompt_embeds: Optional[torch.FloatTensor] = None,
        negative_prompt_embeds: Optional[torch.FloatTensor] = None,
        output_type: Optional[str] = "pil",
        return_dict: bool = True,
        callback: Optional[Callable[[int, int, torch.FloatTensor], None]] = None,
        callback_steps: int = 1,
        cross_attention_kwargs: Optional[Dict[str, Any]] = None,
        controlnet_conditioning_scale: Union[float, List[float]] = 0.5,
        guess_mode: bool = False,
        control_guidance_start: Union[float, List[float]] = 0.0,
        control_guidance_end: Union[float, List[float]] = 1.0,
        clip_skip: Optional[int] = None,
    ):
       
        controlnet = self.controlnet._orig_mod if is_compiled_module(self.controlnet) else self.controlnet

        # align format for control guidance
        if not isinstance(control_guidance_start, list) and isinstance(control_guidance_end, list):
            control_guidance_start = len(control_guidance_end) * [control_guidance_start]
        elif not isinstance(control_guidance_end, list) and isinstance(control_guidance_start, list):
            control_guidance_end = len(control_guidance_start) * [control_guidance_end]
        elif not isinstance(control_guidance_start, list) and not isinstance(control_guidance_end, list):
            mult = len(controlnet.nets) if isinstance(controlnet, MultiControlNetModel) else 1
            control_guidance_start, control_guidance_end = (
                mult * [control_guidance_start],
                mult * [control_guidance_end],
            )

        # 1. Check inputs. Raise error if not correct
        self.check_inputs(
            prompt,
            control_image,
            height,
            width,
            callback_steps,
            negative_prompt,
            prompt_embeds,
            negative_prompt_embeds,
            controlnet_conditioning_scale,
            control_guidance_start,
            control_guidance_end,
        )

        # 2. Define call parameters
        if prompt is not None and isinstance(prompt, str):
            batch_size = 1
        elif prompt is not None and isinstance(prompt, list):
            batch_size = len(prompt)
        else:
            batch_size = prompt_embeds.shape[0]

        device = self._execution_device
        
        do_classifier_free_guidance = guidance_scale > 1.0

        if isinstance(controlnet, MultiControlNetModel) and isinstance(controlnet_conditioning_scale, float):
            controlnet_conditioning_scale = [controlnet_conditioning_scale] * len(controlnet.nets)

        global_pool_conditions = (
            controlnet.config.global_pool_conditions
            if isinstance(controlnet, ControlNetModel)
            else controlnet.nets[0].config.global_pool_conditions
        )
        guess_mode = guess_mode or global_pool_conditions

        # 3. Encode input prompt
        text_encoder_lora_scale = (
            cross_attention_kwargs.get("scale", None) if cross_attention_kwargs is not None else None
        )
        prompt_embeds, negative_prompt_embeds = self.encode_prompt(
            prompt,
            device,
            num_images_per_prompt,
            do_classifier_free_guidance,
            negative_prompt,
            prompt_embeds=prompt_embeds,
            negative_prompt_embeds=negative_prompt_embeds,
            lora_scale=text_encoder_lora_scale,
            clip_skip=clip_skip,
        )
        # For classifier free guidance, we need to do two forward passes.
       
        if do_classifier_free_guidance:
            prompt_embeds = torch.cat([negative_prompt_embeds, prompt_embeds])

        # 4. Prepare image
        if isinstance(controlnet, ControlNetModel):
            control_image = self.prepare_control_image(
                image=control_image,
                width=width,
                height=height,
                batch_size=batch_size * num_images_per_prompt,
                num_images_per_prompt=num_images_per_prompt,
                device=device,
                dtype=controlnet.dtype,
                do_classifier_free_guidance=do_classifier_free_guidance,
                guess_mode=guess_mode,
            )
        elif isinstance(controlnet, MultiControlNetModel):
            control_images = []

            for control_image_ in control_image:
                control_image_ = self.prepare_control_image(
                    image=control_image_,
                    width=width,
                    height=height,
                    batch_size=batch_size * num_images_per_prompt,
                    num_images_per_prompt=num_images_per_prompt,
                    device=device,
                    dtype=controlnet.dtype,
                    do_classifier_free_guidance=do_classifier_free_guidance,
                    guess_mode=guess_mode,
                )

                control_images.append(control_image_)

            control_image = control_images
        else:
            assert False

        init_image = self.image_processor.preprocess(image, height=height, width=width)
        init_image = init_image.to(dtype=torch.float32)

        mask = self.mask_processor.preprocess(mask_image, height=height, width=width)

        masked_image = init_image * (mask < 0.5)
        _, _, height, width = init_image.shape

        # 5. Prepare timesteps
        self.scheduler.set_timesteps(num_inference_steps, device=device)
        timesteps, num_inference_steps = self.get_timesteps(
            num_inference_steps=num_inference_steps, strength=strength, device=device
        )
        # at which timestep to set the initial noise (n.b. 50% if strength is 0.5)
        latent_timestep = timesteps[:1].repeat(batch_size * num_images_per_prompt)
        # create a boolean to check if the strength is set to 1. if so then initialise the latents with pure noise
        is_strength_max = strength == 1.0

        num_channels_latents = self.vae.config.latent_channels
        num_channels_unet = self.unet.config.in_channels
        return_image_latents = num_channels_unet == 4
        latents_outputs = self.prepare_latents(
            batch_size * num_images_per_prompt,
            num_channels_latents,
            height,
            width,
            prompt_embeds.dtype,
            device,
            generator,
            latents,
            image=init_image,
            timestep=latent_timestep,
            is_strength_max=is_strength_max,
            return_noise=True,
            return_image_latents=return_image_latents,
        )

        if return_image_latents:
            latents, noise, image_latents = latents_outputs
        else:
            latents, noise = latents_outputs

        # 7. Prepare mask latent variables
        mask, masked_image_latents = self.prepare_mask_latents(
            mask,
            masked_image,
            batch_size * num_images_per_prompt,
            height,
            width,
            prompt_embeds.dtype,
            device,
            generator,
            do_classifier_free_guidance,
        )

        # 7. Prepare extra step kwargs. TODO: Logic should ideally just be moved out of the pipeline
        extra_step_kwargs = self.prepare_extra_step_kwargs(generator, eta)

        controlnet_keep = []
        for i in range(len(timesteps)):
            keeps = [
                1.0 - float(i / len(timesteps) < s or (i + 1) / len(timesteps) > e)
                for s, e in zip(control_guidance_start, control_guidance_end)
            ]
            controlnet_keep.append(keeps[0] if isinstance(controlnet, ControlNetModel) else keeps)

        # 8. Denoising loop
        num_warmup_steps = len(timesteps) - num_inference_steps * self.scheduler.order
        with self.progress_bar(total=num_inference_steps) as progress_bar:
            for i, t in enumerate(timesteps):
                # expand the latents if we are doing classifier free guidance
                latent_model_input = torch.cat([latents] * 2) if do_classifier_free_guidance else latents
                latent_model_input = self.scheduler.scale_model_input(latent_model_input, t)

                # controlnet(s) inference
                if guess_mode and do_classifier_free_guidance:
                    # Infer ControlNet only for the conditional batch.
                    control_model_input = latents
                    control_model_input = self.scheduler.scale_model_input(control_model_input, t)
                    controlnet_prompt_embeds = prompt_embeds.chunk(2)[1]
                else:
                    control_model_input = latent_model_input
                    controlnet_prompt_embeds = prompt_embeds

                if isinstance(controlnet_keep[i], list):
                    cond_scale = [c * s for c, s in zip(controlnet_conditioning_scale, controlnet_keep[i])]
                else:
                    controlnet_cond_scale = controlnet_conditioning_scale
                    if isinstance(controlnet_cond_scale, list):
                        controlnet_cond_scale = controlnet_cond_scale[0]
                    cond_scale = controlnet_cond_scale * controlnet_keep[i]

                down_block_res_samples, mid_block_res_sample = self.controlnet(
                    control_model_input,
                    t,
                    encoder_hidden_states=controlnet_prompt_embeds,
                    controlnet_cond=control_image,
                    conditioning_scale=cond_scale,
                    guess_mode=guess_mode,
                    return_dict=False,
                )

                if guess_mode and do_classifier_free_guidance:
                    # Infered ControlNet only for the conditional batch.
                   
                    down_block_res_samples = [torch.cat([torch.zeros_like(d), d]) for d in down_block_res_samples]
                    mid_block_res_sample = torch.cat([torch.zeros_like(mid_block_res_sample), mid_block_res_sample])

                # predict the noise residual
                if num_channels_unet == 9:
                    latent_model_input = torch.cat([latent_model_input, mask, masked_image_latents], dim=1)

                noise_pred = self.unet(
                    latent_model_input,
                    t,
                    encoder_hidden_states=prompt_embeds,
                    cross_attention_kwargs=cross_attention_kwargs,
                    down_block_additional_residuals=down_block_res_samples,
                    mid_block_additional_residual=mid_block_res_sample,
                    return_dict=False,
                )[0]

                # perform guidance
                if do_classifier_free_guidance:
                    noise_pred_uncond, noise_pred_text = noise_pred.chunk(2)
                    noise_pred = noise_pred_uncond + guidance_scale * (noise_pred_text - noise_pred_uncond)

                # compute the previous noisy sample x_t -> x_t-1
                latents = self.scheduler.step(noise_pred, t, latents, **extra_step_kwargs, return_dict=False)[0]

                if num_channels_unet == 4:
                    init_latents_proper = image_latents
                    if do_classifier_free_guidance:
                        init_mask, _ = mask.chunk(2)
                    else:
                        init_mask = mask

                    if i < len(timesteps) - 1:
                        noise_timestep = timesteps[i + 1]
                        init_latents_proper = self.scheduler.add_noise(
                            init_latents_proper, noise, torch.tensor([noise_timestep])
                        )

                    latents = (1 - init_mask) * init_latents_proper + init_mask * latents

                # call the callback, if provided
                if i == len(timesteps) - 1 or ((i + 1) > num_warmup_steps and (i + 1) % self.scheduler.order == 0):
                    progress_bar.update()
                    if callback is not None and i % callback_steps == 0:
                        step_idx = i // getattr(self.scheduler, "order", 1)
                        callback(step_idx, t, latents)

       
        if hasattr(self, "final_offload_hook") and self.final_offload_hook is not None:
            self.unet.to("cpu")
            self.controlnet.to("cpu")
            torch.cuda.empty_cache()

        if not output_type == "latent":
            image = self.vae.decode(latents / self.vae.config.scaling_factor, return_dict=False, generator=generator)[
                0
            ]
            image, has_nsfw_concept = self.run_safety_checker(image, device, prompt_embeds.dtype)
        else:
            image = latents
            has_nsfw_concept = None

        if has_nsfw_concept is None:
            do_denormalize = [True] * image.shape[0]
        else:
            do_denormalize = [not has_nsfw for has_nsfw in has_nsfw_concept]

        image = self.image_processor.postprocess(image, output_type=output_type, do_denormalize=do_denormalize)

        # Offload all models
        self.maybe_free_model_hooks()

        if not return_dict:
            return (image, has_nsfw_concept)

        return StableVictorPipelineOutput(images=image, nsfw_content_detected=has_nsfw_concept)
