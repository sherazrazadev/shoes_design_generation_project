import inspect
from typing import Any, Callable, Dict, List, Optional, Tuple, Union
import numpy as np
import PIL.Image
import torch
import torch.nn.functional as F
from transformers import CLIPTextModel, CLIPTextModelWithProjection, CLIPTokenizer
from VictorAI.utils.import_utils import is_invisible_watermark_available
from ...image_processor import PipelineImageInput, VaeImageProcessor
from ...loaders import FromSingleFileMixin, StableVictorXLLoraLoaderMixin, TextualInversionLoaderMixin
from ...models import AutoencoderKL, ControlNetModel, UNet2DConditionModel
from ...models.attention_processor import (
    AttnProcessor2_0,
    LoRAAttnProcessor2_0,
    LoRAXFormersAttnProcessor,
    XFormersAttnProcessor,
)
from ...models.lora import adjust_lora_scale_text_encoder
from ...schedulers import KarrasVictorSchedulers
from ...utils import USE_PEFT_BACKEND, logging,  scale_lora_layers, unscale_lora_layers
from ...utils.torch_utils import is_compiled_module, is_torch_version, randn_tensor
from ..pipeline_utils import VictorPipeline
from ..stable_victor_xl.pipeline_output import StableVictorXLPipelineOutput


if is_invisible_watermark_available():
    from ..stable_victor_xl.watermark import StableVictorXLWatermarker

from .multicontrolnet import MultiControlNetModel


logger = logging.get_logger(__name__) 



class StableVictorXLControlNetPipeline(
    VictorPipeline, TextualInversionLoaderMixin, StableVictorXLLoraLoaderMixin, FromSingleFileMixin
):
    
    
    model_cpu_offload_seq = "text_encoder->text_encoder_2->unet->vae"
    _optional_components = ["tokenizer", "tokenizer_2", "text_encoder", "text_encoder_2"]

    def __init__(
        self,
        vae: AutoencoderKL,
        text_encoder: CLIPTextModel,
        text_encoder_2: CLIPTextModelWithProjection,
        tokenizer: CLIPTokenizer,
        tokenizer_2: CLIPTokenizer,
        unet: UNet2DConditionModel,
        controlnet: Union[ControlNetModel, List[ControlNetModel], Tuple[ControlNetModel], MultiControlNetModel],
        scheduler: KarrasVictorSchedulers,
        force_zeros_for_empty_prompt: bool = True,
        add_watermarker: Optional[bool] = None,
    ):
        super().__init__()

        if isinstance(controlnet, (list, tuple)):
            controlnet = MultiControlNetModel(controlnet)

        self.register_modules(
            vae=vae,
            text_encoder=text_encoder,
            text_encoder_2=text_encoder_2,
            tokenizer=tokenizer,
            tokenizer_2=tokenizer_2,
            unet=unet,
            controlnet=controlnet,
            scheduler=scheduler,
        )
        self.vae_scale_factor = 2 ** (len(self.vae.config.block_out_channels) - 1)
        self.image_processor = VaeImageProcessor(vae_scale_factor=self.vae_scale_factor, do_convert_rgb=True)
        self.control_image_processor = VaeImageProcessor(
            vae_scale_factor=self.vae_scale_factor, do_convert_rgb=True, do_normalize=False
        )
        add_watermarker = add_watermarker if add_watermarker is not None else is_invisible_watermark_available()

        if add_watermarker:
            self.watermark = StableVictorXLWatermarker()
        else:
            self.watermark = None

        self.register_to_config(force_zeros_for_empty_prompt=force_zeros_for_empty_prompt)

    def enable_vae_slicing(self):
       
        self.vae.enable_slicing()

    def disable_vae_slicing(self):
        r"""
        Disable sliced VAE decoding. If `enable_vae_slicing` was previously enabled, this method will go back to
        computing decoding in one step.
        """
        self.vae.disable_slicing()

    def enable_vae_tiling(self):
       
        self.vae.enable_tiling()

    def disable_vae_tiling(self):
        r"""
        Disable tiled VAE decoding. If `enable_vae_tiling` was previously enabled, this method will go back to
        computing decoding in one step.
        """
        self.vae.disable_tiling()

    def encode_prompt(
        self,
        user_input: str,
        user_input_2: Optional[str] = None,
        target_device: Optional[torch.device] = None,
        images_per_input: int = 1,
        enable_classifier_free_guidance: bool = True,
        exclusion_input: Optional[str] = None,
        exclusion_input_2: Optional[str] = None,
        user_input_embeddings: Optional[torch.FloatTensor] = None,
        exclusion_input_embeddings: Optional[torch.FloatTensor] = None,
        pooled_user_input_embeddings: Optional[torch.FloatTensor] = None,
        pooled_exclusion_input_embeddings: Optional[torch.FloatTensor] = None,
        custom_lora_scaling: Optional[float] = None,
        skip_clip_layers: Optional[int] = None,
    ):
       
        target_device = target_device or self._execution_device

        # Set the custom lora scaling factor so that the monkey-patched LoRA function of the text encoder can correctly access it
        if custom_lora_scaling is not None and isinstance(self, LoraLoaderMixin):
            self._custom_lora_scaling = custom_lora_scaling

            # Dynamically adjust the LoRA scaling factor
            if self.text_encoder is not None:
                if not USE_PEFT_BACKEND:
                    adjust_lora_scaling_text_encoder(self.text_encoder, custom_lora_scaling)
                else:
                    scale_lora_layers(self.text_encoder, custom_lora_scaling)

            if self.text_encoder_2 is not None:
                if not USE_PEFT_BACKEND:
                    adjust_lora_scaling_text_encoder(self.text_encoder_2, custom_lora_scaling)
                else:
                    scale_lora_layers(self.text_encoder_2, custom_lora_scaling)

        user_input = [user_input] if isinstance(user_input, str) else user_input

        if user_input is not None:
            batch_size = len(user_input)
        else:
            batch_size = user_input_embeddings.shape[0]

        tokenizers = [self.tokenizer, self.tokenizer_2] if self.tokenizer is not None else [self.tokenizer_2]
        text_encoders = (
            [self.text_encoder, self.text_encoder_2] if self.text_encoder is not None else [self.text_encoder_2]
        )

        if user_input_embeddings is None:
            user_input_2 = user_input_2 or user_input
            user_input_2 = [user_input_2] if isinstance(user_input_2, str) else user_input_2

            user_input_embeddings_list = []
            user_inputs = [user_input, user_input_2]
            for user_input, tokenizer, text_encoder in zip(user_inputs, tokenizers, text_encoders):
                if isinstance(self, TextualInversionLoaderMixin):
                    user_input = self.maybe_convert_user_input(user_input, tokenizer)

                text_inputs = tokenizer(
                    user_input,
                    padding="max_length",
                    max_length=tokenizer.model_max_length,
                    truncation=True,
                    return_tensors="pt",
                )

                text_input_ids = text_inputs.input_ids
                untruncated_ids = tokenizer(user_input, padding="longest", return_tensors="pt").input_ids

                if untruncated_ids.shape[-1] >= text_input_ids.shape[-1] and not torch.equal(
                    text_input_ids, untruncated_ids
                ):
                    removed_text = tokenizer.batch_decode(untruncated_ids[:, tokenizer.model_max_length - 1 : -1])
                    logger.warning(
                        "The following part of your input was truncated because CLIP can only handle sequences up to"
                        f" {tokenizer.model_max_length} tokens: {removed_text}"
                    )

                user_input_embeddings = text_encoder(text_input_ids.to(target_device), output_hidden_states=True)

                # We are only ALWAYS interested in the pooled output of the final text encoder
                pooled_user_input_embeddings = user_input_embeddings[0]
                if skip_clip_layers is None:
                    user_input_embeddings = user_input_embeddings.hidden_states[-2]
                else:
                    # "2" because SDXL always indexes from the penultimate layer
                    user_input_embeddings = user_input_embeddings.hidden_states[-(skip_clip_layers + 2)]

                user_input_embeddings_list.append(user_input_embeddings)

            user_input_embeddings = torch.cat(user_input_embeddings_list, dim=-1)

        # Get unconditional embeddings for classifier-free guidance
        zero_out_exclusion_input = exclusion_input is None and self.config.force_zeros_for_empty_input
        if enable_classifier_free_guidance and exclusion_input_embeddings is None and zero_out_exclusion_input:
            exclusion_input_embeddings = torch.zeros_like(user_input_embeddings)
            pooled_exclusion_input_embeddings = torch.zeros_like(pooled_user_input_embeddings)
        elif enable_classifier_free_guidance and exclusion_input_embeddings is None:
            exclusion_input = exclusion_input or ""
            exclusion_input_2 = exclusion_input_2 or exclusion_input

            # Normalize str to list
            exclusion_input = batch_size * [exclusion_input] if isinstance(exclusion_input, str) else exclusion_input
            exclusion_input_2 = (
                batch_size * [exclusion_input_2] if isinstance(exclusion_input_2, str) else exclusion_input_2
            )

            unconditional_tokens: List[str]
            if user_input is not None and type(user_input) is not type(exclusion_input):
                raise TypeError(
                    f"`exclusion_input` should be of the same type as `user_input`, but got {type(exclusion_input)} "
                    f"!= {type(user_input)}."
                )
            elif batch_size != len(exclusion_input):
                raise ValueError(
                    f"`exclusion_input`: {exclusion_input} has batch size {len(exclusion_input)}, but `user_input`:"
                    f" {user_input} has batch size {batch_size}. Please make sure that passed `exclusion_input` matches"
                    " the batch size of `user_input`."
                )
            else:
                unconditional_tokens = [exclusion_input, exclusion_input_2]

            exclusion_input_embeddings_list = []
            for exclusion_input, tokenizer, text_encoder in zip(unconditional_tokens, tokenizers, text_encoders):
                if isinstance(self, TextualInversionLoaderMixin):
                    exclusion_input = self.maybe_convert_user_input(exclusion_input, tokenizer)

                max_length = user_input_embeddings.shape[1]
                unconditional_input = tokenizer(
                    exclusion_input,
                    padding="max_length",
                    max_length=max_length,
                    truncation=True,
                    return_tensors="pt",
                )

                exclusion_input_embeddings = text_encoder(
                    unconditional_input.input_ids.to(target_device),
                    output_hidden_states=True,
                )
                # We are only ALWAYS interested in the pooled output of the final text encoder
                pooled_exclusion_input_embeddings = exclusion_input_embeddings[0]
                exclusion_input_embeddings = exclusion_input_embeddings.hidden_states[-2]

                exclusion_input_embeddings_list.append(exclusion_input_embeddings)

            exclusion_input_embeddings = torch.cat(exclusion_input_embeddings_list, dim=-1)

        if self.text_encoder_2 is not None:
            user_input_embeddings = user_input_embeddings.to(dtype=self.text_encoder_2.dtype, device=target_device)
        else:
            user_input_embeddings = user_input_embeddings.to(dtype=self.unet.dtype, device=target_device)

        bs_embed, seq_len, _ = user_input_embeddings.shape
        # Duplicate text embeddings for each generation per user input, using a memory-efficient method
        user_input_embeddings = user_input_embeddings.repeat(1, images_per_input, 1)
        user_input_embeddings = user_input_embeddings.view(bs_embed * images_per_input, seq_len, -1)

        if enable_classifier_free_guidance:
            # Duplicate unconditional embeddings for each generation per user input, using a memory-efficient method
            seq_len = exclusion_input_embeddings.shape[1]

            if self.text_encoder_2 is not None:
                exclusion_input_embeddings = exclusion_input_embeddings.to(
                    dtype=self.text_encoder_2.dtype, device=target_device
                )
            else:
                exclusion_input_embeddings = exclusion_input_embeddings.to(dtype=self.unet.dtype, device=target_device)

            exclusion_input_embeddings = exclusion_input_embeddings.repeat(1, images_per_input, 1)
            exclusion_input_embeddings = exclusion_input_embeddings.view(batch_size * images_per_input, seq_len, -1)

        pooled_user_input_embeddings = pooled_user_input_embeddings.repeat(1, images_per_input).view(
            bs_embed * images_per_input, -1
        )
        if enable_classifier_free_guidance:
            pooled_exclusion_input_embeddings = pooled_exclusion_input_embeddings.repeat(1, images_per_input).view(
                bs_embed * images_per_input, -1
            )

        if self.text_encoder is not None:
            if isinstance(self, LoraLoaderMixin) and USE_PEFT_BACKEND:
                # Retrieve the original scaling factor by scaling back the LoRA layers
                unscale_lora_layers(self.text_encoder, custom_lora_scaling)

        if self.text_encoder_2 is not None:
            if isinstance(self, LoraLoaderMixin) and USE_PEFT_BACKEND:
                unscale_lora_layers(self.text_encoder_2, custom_lora_scaling)

        return user_input_embeddings, exclusion_input_embeddings, pooled_user_input_embeddings, pooled_exclusion_input_embeddings


    def prepare_extra_step_kwargs(self, gen_instance, eta_value):
    

        accepts_eta = "eta" in set(inspect.signature(self.scheduler.step).parameters.keys())
        extra_step_kwargs = {}
        if accepts_eta:
            extra_step_kwargs["eta"] = eta_value

        # Check if the scheduler accepts 'gen_instance'
        accepts_gen_instance = "generator" in set(inspect.signature(self.scheduler.step).parameters.keys())
        if accepts_gen_instance:
            extra_step_kwargs["generator"] = gen_instance
        return extra_step_kwargs


 
    def check_inputs(
        self,
        user_prompt,
        user_prompt_2,
        input_image,
        callback_steps_count,
        neg_user_prompt=None,
        neg_user_prompt_2=None,
        user_prompt_embeddings=None,
        neg_user_prompt_embeddings=None,
        pooled_user_prompt_embeddings=None,
        neg_pooled_user_prompt_embeddings=None,
        control_conditioning_scale=1.0,
        control_start_guidance=0.0,
        control_end_guidance=1.0,
    ):
        if (callback_steps_count is None) or (
            callback_steps_count is not None and (not isinstance(callback_steps_count, int) or callback_steps_count <= 0)
        ):
            raise ValueError(
                f"`callback_steps_count` has to be a positive integer but is {callback_steps_count} of type"
                f" {type(callback_steps_count)}."
            )

        if user_prompt is not None and user_prompt_embeddings is not None:
            raise ValueError(
                f"Cannot forward both `user_prompt`: {user_prompt} and `user_prompt_embeddings`: {user_prompt_embeddings}."
                f" Please make sure to only forward one of the two."
            )
        elif user_prompt_2 is not None and user_prompt_embeddings is not None:
            raise ValueError(
                f"Cannot forward both `user_prompt_2`: {user_prompt_2} and `user_prompt_embeddings`: {user_prompt_embeddings}."
                f" Please make sure to only forward one of the two."
            )
        elif user_prompt is None and user_prompt_embeddings is None:
            raise ValueError(
                "Provide either `user_prompt` or `user_prompt_embeddings`. Cannot leave both `user_prompt` and"
                " `user_prompt_embeddings` undefined."
            )
        elif user_prompt is not None and (not isinstance(user_prompt, str) and not isinstance(user_prompt, list)):
            raise ValueError(f"`user_prompt` has to be of type `str` or `list` but is {type(user_prompt)}")
        elif user_prompt_2 is not None and (not isinstance(user_prompt_2, str) and not isinstance(user_prompt_2, list)):
            raise ValueError(f"`user_prompt_2` has to be of type `str` or `list` but is {type(user_prompt_2)}")

        if neg_user_prompt is not None and neg_user_prompt_embeddings is not None:
            raise ValueError(
                f"Cannot forward both `neg_user_prompt`: {neg_user_prompt} and `neg_user_prompt_embeddings`:"
                f" {neg_user_prompt_embeddings}. Please make sure to only forward one of the two."
            )
        elif neg_user_prompt_2 is not None and neg_user_prompt_embeddings is not None:
            raise ValueError(
                f"Cannot forward both `neg_user_prompt_2`: {neg_user_prompt_2} and `neg_user_prompt_embeddings`:"
                f" {neg_user_prompt_embeddings}. Please make sure to only forward one of the two."
            )

        if user_prompt_embeddings is not None and neg_user_prompt_embeddings is not None:
            if user_prompt_embeddings.shape != neg_user_prompt_embeddings.shape:
                raise ValueError(
                    "`user_prompt_embeddings` and `neg_user_prompt_embeddings` must have the same shape when passed directly,"
                    f" but got: `user_prompt_embeddings` {user_prompt_embeddings.shape} != `neg_user_prompt_embeddings`"
                    f" {neg_user_prompt_embeddings.shape}."
                )

        if user_prompt_embeddings is not None and pooled_user_prompt_embeddings is None:
            raise ValueError(
                "If `user_prompt_embeddings` are provided, `pooled_user_prompt_embeddings` also has to be passed."
                " Make sure to generate `pooled_user_prompt_embeddings` from the same text encoder that was used to"
                " generate `user_prompt_embeddings`."
            )

        if neg_user_prompt_embeddings is not None and neg_pooled_user_prompt_embeddings is None:
            raise ValueError(
                "If `neg_user_prompt_embeddings` are provided, `neg_pooled_user_prompt_embeddings` also has to be passed."
                " Make sure to generate `neg_pooled_user_prompt_embeddings` from the same text encoder that was used to"
                " generate `neg_user_prompt_embeddings`."
            )

       
        if isinstance(self.ctrl_net, MultiControlNetModel):
            if isinstance(user_prompt, list):
                logger.warning(
                    f"You have {len(self.ctrl_net.nets)} ControlNets and you have passed {len(user_prompt)}"
                    " prompts. The conditionings will be fixed across the prompts."
                )

        # Check `input_image`
        is_compiled = hasattr(F, "scaled_dot_product_attention") and isinstance(
            self.ctrl_net, torch._dynamo.eval_frame.OptimizedModule
        )
        if (
            isinstance(self.ctrl_net, ControlNetModel)
            or is_compiled
            and isinstance(self.ctrl_net._orig_mod, ControlNetModel)
        ):
            self.check_image(input_image, user_prompt, user_prompt_embeddings)
        elif (
            isinstance(self.ctrl_net, MultiControlNetModel)
            or is_compiled
            and isinstance(self.ctrl_net._orig_mod, MultiControlNetModel)
        ):
            if not isinstance(input_image, list):
                raise TypeError("For multiple controlnets: `input_image` must be type `list`")

          
            elif any(isinstance(i, list) for i in input_image):
                raise ValueError("A single batch of multiple conditionings is supported at the moment.")
            elif len(input_image) != len(self.ctrl_net.nets):
                raise ValueError(
                    f"For multiple controlnets: `input_image` must have the same length as the number of controlnets,"
                    f" but got {len(input_image)} images and {len(self.ctrl_net.nets)} ControlNets."
                )

            for image_ in input_image:
                self.check_image(image_, user_prompt, user_prompt_embeddings)
        else:
            assert False

        # Check `control_conditioning_scale`
        if (
            isinstance(self.ctrl_net, ControlNetModel)
            or is_compiled
            and isinstance(self.ctrl_net._orig_mod, ControlNetModel)
        ):
            if not isinstance(control_conditioning_scale, float):
                raise TypeError("For single controlnet: `control_conditioning_scale` must be type `float`.")
        elif (
            isinstance(self.ctrl_net, MultiControlNetModel)
            or is_compiled
            and isinstance(self.ctrl_net._orig_mod, MultiControlNetModel)
        ):
            if isinstance(control_conditioning_scale, list):
                if any(isinstance(i, list) for i in control_conditioning_scale):
                    raise ValueError("A single batch of multiple conditionings is supported at the moment.")
            elif isinstance(control_conditioning_scale, list) and len(control_conditioning_scale) != len(
                self.ctrl_net.nets
            ):
                raise ValueError(
                    "For multiple controlnets: When `control_conditioning_scale` is specified as `list`, it must have"
                    " the same length as the number of controlnets."
                )
        else:
            assert False

        if not isinstance(control_start_guidance, (tuple, list)):
            control_start_guidance = [control_start_guidance]

        if not isinstance(control_end_guidance, (tuple, list)):
            control_end_guidance = [control_end_guidance]

        if len(control_start_guidance) != len(control_end_guidance):
            raise ValueError(
                f"`control_start_guidance` has {len(control_start_guidance)} elements, but `control_end_guidance` has"
                f" {len(control_end_guidance)} elements. Make sure to provide the same number of elements to each list."
            )

        if isinstance(self.ctrl_net, MultiControlNetModel):
            if len(control_start_guidance) != len(self.ctrl_net.nets):
                raise ValueError(
                    f"`control_start_guidance`: {control_start_guidance} has {len(control_start_guidance)} elements but"
                    f" there are {len(self.ctrl_net.nets)} controlnets available. Make sure to provide {len(self.ctrl_net.nets)}."
                )

        for start, end in zip(control_start_guidance, control_end_guidance):
            if start >= end:
                raise ValueError(f"Control guidance start: {start} cannot be larger or equal to control guidance end: {end}.")
            if start < 0.0:
                raise ValueError(f"Control guidance start: {start} can't be smaller than 0.")
            if end > 1.0:
                raise ValueError(f"Control guidance end: {end} can't be larger than 1.0.")



    def check_image(self, image, prompt, prompt_embeds):
        image_is_pil = isinstance(image, PIL.Image.Image)
        image_is_tensor = isinstance(image, torch.Tensor)
        image_is_np = isinstance(image, np.ndarray)
        image_is_pil_list = isinstance(image, list) and isinstance(image[0], PIL.Image.Image)
        image_is_tensor_list = isinstance(image, list) and isinstance(image[0], torch.Tensor)
        image_is_np_list = isinstance(image, list) and isinstance(image[0], np.ndarray)

        if (
            not image_is_pil
            and not image_is_tensor
            and not image_is_np
            and not image_is_pil_list
            and not image_is_tensor_list
            and not image_is_np_list
        ):
            raise TypeError(
                f"image must be passed and be one of PIL image, numpy array, torch tensor, list of PIL images, list of numpy arrays or list of torch tensors, but is {type(image)}"
            )

        if image_is_pil:
            image_batch_size = 1
        else:
            image_batch_size = len(image)

        if prompt is not None and isinstance(prompt, str):
            prompt_batch_size = 1
        elif prompt is not None and isinstance(prompt, list):
            prompt_batch_size = len(prompt)
        elif prompt_embeds is not None:
            prompt_batch_size = prompt_embeds.shape[0]

        if image_batch_size != 1 and image_batch_size != prompt_batch_size:
            raise ValueError(
                f"If image batch size is not 1, image batch size must be same as prompt batch size. image batch size: {image_batch_size}, prompt batch size: {prompt_batch_size}"
            )

    
    def prepare_image(
        self,
        input_image,
        target_width,
        target_height,
        requested_batch_size,
        images_per_prompt_count,
        target_device,
        target_dtype,
        enable_guidance_without_classifier=False,
        enable_guess_mode=False,
    ):
        processed_image = self.ctrl_image_proc.preprocess(input_image, height=target_height, width=target_width).to(
            dtype=torch.float32
        )
        image_batch_size = processed_image.shape[0]

        if image_batch_size == 1:
            repetition_factor = requested_batch_size
        else:
            # Image batch size is the same as prompt batch size
            repetition_factor = images_per_prompt_count

        processed_image = processed_image.repeat_interleave(repetition_factor, dim=0)

        processed_image = processed_image.to(device=target_device, dtype=target_dtype)

        if enable_guidance_without_classifier and not enable_guess_mode:
            processed_image = torch.cat([processed_image] * 2)

        return processed_image


  

    def prepare_latents(self, batch_size, num_channels, target_height, target_width, data_type, target_device, source_generator, input_latents=None):
        latents_shape = (batch_size, num_channels, target_height // self.vae_scale_factor, target_width // self.vae_scale_factor)

        if isinstance(source_generator, list) and len(source_generator) != batch_size:
            raise ValueError(
                f"You provided a list of generators with a length of {len(source_generator)}, but requested an effective batch"
                f" size of {batch_size}. Ensure that the batch size matches the length of the generators."
            )

        if input_latents is None:
            input_latents = randn_tensor(latents_shape, generator=source_generator, device=target_device, dtype=data_type)
        else:
            input_latents = input_latents.to(target_device)

        scaled_latents = input_latents * self.scheduler.init_noise_sigma
        return scaled_latents



    def _get_add_time_ids(
        self, base_dimensions, top_left_coordinates, target_dimensions, data_type, projection_dimensions=None
    ):
        add_time_ids = list(base_dimensions + top_left_coordinates + target_dimensions)

        passed_embedding_dim = (
            self.unet.config.addition_time_embed_dim * len(add_time_ids) + projection_dimensions
        )
        expected_embedding_dim = self.unet.add_embedding.linear_1.in_features

        if expected_embedding_dim != passed_embedding_dim:
            raise ValueError(
                f"The model expects an added time embedding vector of length {expected_embedding_dim}, but a vector of {passed_embedding_dim} was created. The model has an incorrect configuration. Please check `unet.config.time_embedding_type` and `text_encoder_2.config.projection_dim`."
            )

        add_time_ids = torch.tensor([add_time_ids], dtype=data_type)
        return add_time_ids


    def upcast_vae(self):
        data_type = self.vae.dtype
        self.vae.to(dtype=torch.float32)
        use_torch_2_0_or_xformers = isinstance(
            self.vae.decoder.mid_block.attentions[0].processor,
            (
                AttnProcessor2_0,
                XFormersAttnProcessor,
                LoRAXFormersAttnProcessor,
                LoRAAttnProcessor2_0,
            ),
        )
     
        if use_torch_2_0_or_xformers:
            self.vae.post_quant_conv.to(data_type)
            self.vae.decoder.conv_in.to(data_type)
            self.vae.decoder.mid_block.to(data_type)



    def enable_freeu(self, scale_1: float, scale_2: float, backbone_scale_1: float, backbone_scale_2: float):
     
        if not hasattr(self, "unet"):
            raise ValueError("The pipeline must have `unet` for using FreeU.")
        self.unet.enable_freeu(s1=scale_1, s2=scale_2, b1=backbone_scale_1, b2=backbone_scale_2)


    def disable_freeu(self):
        """Disables the FreeU mechanism if enabled."""
        self.unet.disable_freeu()


    def get_guidance_scale_embedding(self, time_steps, embedding_size=512, data_type=torch.float32):
   
        assert len(time_steps.shape) == 1
        time_steps = time_steps * 1000.0

        half_size = embedding_size // 2
        embedding = torch.log(torch.tensor(10000.0)) / (half_size - 1)
        embedding = torch.exp(torch.arange(half_size, dtype=data_type) * -embedding)
        embedding = time_steps.to(data_type)[:, None] * embedding[None, :]
        embedding = torch.cat([torch.sin(embedding), torch.cos(embedding)], dim=1)
        if embedding_size % 2 == 1:  # zero pad
            embedding = torch.nn.functional.pad(embedding, (0, 1))
        assert embedding.shape == (time_steps.shape[0], embedding_size)
        return embedding


    @property
    def guidance_scale(self):
        return self._guidance_scale

  
    @property
    def do_classifier_free_guidance(self):
        return self._guidance_scale > 1 and self.unet.config.time_cond_proj_dim is None

    @torch.no_grad()
    
    def __call__(
        self,
        prompt: Union[str, List[str]] = None,
        prompt_2: Optional[Union[str, List[str]]] = None,
        image: PipelineImageInput = None,
        height: Optional[int] = None,
        width: Optional[int] = None,
        num_inference_steps: int = 50,
        guidance_scale: float = 5.0,
        negative_prompt: Optional[Union[str, List[str]]] = None,
        negative_prompt_2: Optional[Union[str, List[str]]] = None,
        num_images_per_prompt: Optional[int] = 1,
        eta: float = 0.0,
        generator: Optional[Union[torch.Generator, List[torch.Generator]]] = None,
        latents: Optional[torch.FloatTensor] = None,
        prompt_embeds: Optional[torch.FloatTensor] = None,
        negative_prompt_embeds: Optional[torch.FloatTensor] = None,
        pooled_prompt_embeds: Optional[torch.FloatTensor] = None,
        negative_pooled_prompt_embeds: Optional[torch.FloatTensor] = None,
        output_type: Optional[str] = "pil",
        return_dict: bool = True,
        callback: Optional[Callable[[int, int, torch.FloatTensor], None]] = None,
        callback_steps: int = 1,
        cross_attention_kwargs: Optional[Dict[str, Any]] = None,
        controlnet_conditioning_scale: Union[float, List[float]] = 1.0,
        guess_mode: bool = False,
        control_guidance_start: Union[float, List[float]] = 0.0,
        control_guidance_end: Union[float, List[float]] = 1.0,
        original_size: Tuple[int, int] = None,
        crops_coords_top_left: Tuple[int, int] = (0, 0),
        target_size: Tuple[int, int] = None,
        negative_original_size: Optional[Tuple[int, int]] = None,
        negative_crops_coords_top_left: Tuple[int, int] = (0, 0),
        negative_target_size: Optional[Tuple[int, int]] = None,
        clip_skip: Optional[int] = None,
    ):
        
        controlnet = self.controlnet._orig_mod if is_compiled_module(self.controlnet) else self.controlnet

        if not isinstance(control_guidance_start, list) and isinstance(control_guidance_end, list):
            control_guidance_start = len(control_guidance_end) * [control_guidance_start]
        elif not isinstance(control_guidance_end, list) and isinstance(control_guidance_start, list):
            control_guidance_end = len(control_guidance_start) * [control_guidance_end]
        elif not isinstance(control_guidance_start, list) and not isinstance(control_guidance_end, list):
            mult = len(controlnet.nets) if isinstance(controlnet, MultiControlNetModel) else 1
            control_guidance_start, control_guidance_end = (
                mult * [control_guidance_start],
                mult * [control_guidance_end],
            )

        self.check_inputs(
            prompt,
            prompt_2,
            image,
            callback_steps,
            negative_prompt,
            negative_prompt_2,
            prompt_embeds,
            negative_prompt_embeds,
            pooled_prompt_embeds,
            negative_pooled_prompt_embeds,
            controlnet_conditioning_scale,
            control_guidance_start,
            control_guidance_end,
        )

        self._guidance_scale = guidance_scale

        # 2. Define call parameters
        if prompt is not None and isinstance(prompt, str):
            batch_size = 1
        elif prompt is not None and isinstance(prompt, list):
            batch_size = len(prompt)
        else:
            batch_size = prompt_embeds.shape[0]

        device = self._execution_device

        if isinstance(controlnet, MultiControlNetModel) and isinstance(controlnet_conditioning_scale, float):
            controlnet_conditioning_scale = [controlnet_conditioning_scale] * len(controlnet.nets)

        global_pool_conditions = (
            controlnet.config.global_pool_conditions
            if isinstance(controlnet, ControlNetModel)
            else controlnet.nets[0].config.global_pool_conditions
        )
        guess_mode = guess_mode or global_pool_conditions

        # 3. Encode input prompt
        text_encoder_lora_scale = (
            cross_attention_kwargs.get("scale", None) if cross_attention_kwargs is not None else None
        )
        (
            prompt_embeds,
            negative_prompt_embeds,
            pooled_prompt_embeds,
            negative_pooled_prompt_embeds,
        ) = self.encode_prompt(
            prompt,
            prompt_2,
            device,
            num_images_per_prompt,
            self.do_classifier_free_guidance,
            negative_prompt,
            negative_prompt_2,
            prompt_embeds=prompt_embeds,
            negative_prompt_embeds=negative_prompt_embeds,
            pooled_prompt_embeds=pooled_prompt_embeds,
            negative_pooled_prompt_embeds=negative_pooled_prompt_embeds,
            lora_scale=text_encoder_lora_scale,
            clip_skip=clip_skip,
        )

        # 4. Prepare image
        if isinstance(controlnet, ControlNetModel):
            image = self.prepare_image(
                image=image,
                width=width,
                height=height,
                batch_size=batch_size * num_images_per_prompt,
                num_images_per_prompt=num_images_per_prompt,
                device=device,
                dtype=controlnet.dtype,
                do_classifier_free_guidance=self.do_classifier_free_guidance,
                guess_mode=guess_mode,
            )
            height, width = image.shape[-2:]
        elif isinstance(controlnet, MultiControlNetModel):
            images = []

            for image_ in image:
                image_ = self.prepare_image(
                    image=image_,
                    width=width,
                    height=height,
                    batch_size=batch_size * num_images_per_prompt,
                    num_images_per_prompt=num_images_per_prompt,
                    device=device,
                    dtype=controlnet.dtype,
                    do_classifier_free_guidance=self.do_classifier_free_guidance,
                    guess_mode=guess_mode,
                )

                images.append(image_)

            image = images
            height, width = image[0].shape[-2:]
        else:
            assert False

        # 5. Prepare timesteps
        self.scheduler.set_timesteps(num_inference_steps, device=device)
        timesteps = self.scheduler.timesteps

        # 6. Prepare latent variables
        num_channels_latents = self.unet.config.in_channels
        latents = self.prepare_latents(
            batch_size * num_images_per_prompt,
            num_channels_latents,
            height,
            width,
            prompt_embeds.dtype,
            device,
            generator,
            latents,
        )

        timestep_cond = None
        if self.unet.config.time_cond_proj_dim is not None:
            guidance_scale_tensor = torch.tensor(self.guidance_scale - 1).repeat(batch_size * num_images_per_prompt)
            timestep_cond = self.get_guidance_scale_embedding(
                guidance_scale_tensor, embedding_dim=self.unet.config.time_cond_proj_dim
            ).to(device=device, dtype=latents.dtype)

        extra_step_kwargs = self.prepare_extra_step_kwargs(generator, eta)

        # 7.1 Create tensor stating which controlnets to keep
        controlnet_keep = []
        for i in range(len(timesteps)):
            keeps = [
                1.0 - float(i / len(timesteps) < s or (i + 1) / len(timesteps) > e)
                for s, e in zip(control_guidance_start, control_guidance_end)
            ]
            controlnet_keep.append(keeps[0] if isinstance(controlnet, ControlNetModel) else keeps)

        # 7.2 Prepare added time ids & embeddings
        if isinstance(image, list):
            original_size = original_size or image[0].shape[-2:]
        else:
            original_size = original_size or image.shape[-2:]
        target_size = target_size or (height, width)

        add_text_embeds = pooled_prompt_embeds
        if self.text_encoder_2 is None:
            text_encoder_projection_dim = int(pooled_prompt_embeds.shape[-1])
        else:
            text_encoder_projection_dim = self.text_encoder_2.config.projection_dim

        add_time_ids = self._get_add_time_ids(
            original_size,
            crops_coords_top_left,
            target_size,
            dtype=prompt_embeds.dtype,
            text_encoder_projection_dim=text_encoder_projection_dim,
        )

        if negative_original_size is not None and negative_target_size is not None:
            negative_add_time_ids = self._get_add_time_ids(
                negative_original_size,
                negative_crops_coords_top_left,
                negative_target_size,
                dtype=prompt_embeds.dtype,
                text_encoder_projection_dim=text_encoder_projection_dim,
            )
        else:
            negative_add_time_ids = add_time_ids

        if self.do_classifier_free_guidance:
            prompt_embeds = torch.cat([negative_prompt_embeds, prompt_embeds], dim=0)
            add_text_embeds = torch.cat([negative_pooled_prompt_embeds, add_text_embeds], dim=0)
            add_time_ids = torch.cat([negative_add_time_ids, add_time_ids], dim=0)

        prompt_embeds = prompt_embeds.to(device)
        add_text_embeds = add_text_embeds.to(device)
        add_time_ids = add_time_ids.to(device).repeat(batch_size * num_images_per_prompt, 1)

        # 8. Denoising loop
        num_warmup_steps = len(timesteps) - num_inference_steps * self.scheduler.order
        is_unet_compiled = is_compiled_module(self.unet)
        is_controlnet_compiled = is_compiled_module(self.controlnet)
        is_torch_higher_equal_2_1 = is_torch_version(">=", "2.1")
        with self.progress_bar(total=num_inference_steps) as progress_bar:
            for i, t in enumerate(timesteps):

                if (is_unet_compiled and is_controlnet_compiled) and is_torch_higher_equal_2_1:
                    torch._inductor.cudagraph_mark_step_begin()
                # expand the latents if we are doing classifier free guidance
                latent_model_input = torch.cat([latents] * 2) if self.do_classifier_free_guidance else latents
                latent_model_input = self.scheduler.scale_model_input(latent_model_input, t)

                added_cond_kwargs = {"text_embeds": add_text_embeds, "time_ids": add_time_ids}

                # controlnet(s) inference
                if guess_mode and self.do_classifier_free_guidance:
                    # Infer ControlNet only for the conditional batch.
                    control_model_input = latents
                    control_model_input = self.scheduler.scale_model_input(control_model_input, t)
                    controlnet_prompt_embeds = prompt_embeds.chunk(2)[1]
                    controlnet_added_cond_kwargs = {
                        "text_embeds": add_text_embeds.chunk(2)[1],
                        "time_ids": add_time_ids.chunk(2)[1],
                    }
                else:
                    control_model_input = latent_model_input
                    controlnet_prompt_embeds = prompt_embeds
                    controlnet_added_cond_kwargs = added_cond_kwargs

                if isinstance(controlnet_keep[i], list):
                    cond_scale = [c * s for c, s in zip(controlnet_conditioning_scale, controlnet_keep[i])]
                else:
                    controlnet_cond_scale = controlnet_conditioning_scale
                    if isinstance(controlnet_cond_scale, list):
                        controlnet_cond_scale = controlnet_cond_scale[0]
                    cond_scale = controlnet_cond_scale * controlnet_keep[i]

                down_block_res_samples, mid_block_res_sample = self.controlnet(
                    control_model_input,
                    t,
                    encoder_hidden_states=controlnet_prompt_embeds,
                    controlnet_cond=image,
                    conditioning_scale=cond_scale,
                    guess_mode=guess_mode,
                    added_cond_kwargs=controlnet_added_cond_kwargs,
                    return_dict=False,
                )

                if guess_mode and self.do_classifier_free_guidance:
                    # Infered ControlNet only for the conditional batch.
                    # To apply the output of ControlNet to both the unconditional and conditional batches,
                    # add 0 to the unconditional batch to keep it unchanged.
                    down_block_res_samples = [torch.cat([torch.zeros_like(d), d]) for d in down_block_res_samples]
                    mid_block_res_sample = torch.cat([torch.zeros_like(mid_block_res_sample), mid_block_res_sample])

                # predict the noise residual
                noise_pred = self.unet(
                    latent_model_input,
                    t,
                    encoder_hidden_states=prompt_embeds,
                    timestep_cond=timestep_cond,
                    cross_attention_kwargs=cross_attention_kwargs,
                    down_block_additional_residuals=down_block_res_samples,
                    mid_block_additional_residual=mid_block_res_sample,
                    added_cond_kwargs=added_cond_kwargs,
                    return_dict=False,
                )[0]

                # perform guidance
                if self.do_classifier_free_guidance:
                    noise_pred_uncond, noise_pred_text = noise_pred.chunk(2)
                    noise_pred = noise_pred_uncond + guidance_scale * (noise_pred_text - noise_pred_uncond)

                # compute the previous noisy sample x_t -> x_t-1
                latents = self.scheduler.step(noise_pred, t, latents, **extra_step_kwargs, return_dict=False)[0]

                # call the callback, if provided
                if i == len(timesteps) - 1 or ((i + 1) > num_warmup_steps and (i + 1) % self.scheduler.order == 0):
                    progress_bar.update()
                    if callback is not None and i % callback_steps == 0:
                        step_idx = i // getattr(self.scheduler, "order", 1)
                        callback(step_idx, t, latents)

        # manually for max memory savings
        if self.vae.dtype == torch.float16 and self.vae.config.force_upcast:
            self.upcast_vae()
            latents = latents.to(next(iter(self.vae.post_quant_conv.parameters())).dtype)

        if not output_type == "latent":
            # make sure the VAE is in float32 mode, as it overflows in float16
            needs_upcasting = self.vae.dtype == torch.float16 and self.vae.config.force_upcast

            if needs_upcasting:
                self.upcast_vae()
                latents = latents.to(next(iter(self.vae.post_quant_conv.parameters())).dtype)

            image = self.vae.decode(latents / self.vae.config.scaling_factor, return_dict=False)[0]

            # cast back to fp16 if needed
            if needs_upcasting:
                self.vae.to(dtype=torch.float16)
        else:
            image = latents

        if not output_type == "latent":
            # apply watermark if available
            if self.watermark is not None:
                image = self.watermark.apply_watermark(image)

            image = self.image_processor.postprocess(image, output_type=output_type)

        # Offload all models
        self.maybe_free_model_hooks()

        if not return_dict:
            return (image,)

        return StableVictorXLPipelineOutput(images=image)
