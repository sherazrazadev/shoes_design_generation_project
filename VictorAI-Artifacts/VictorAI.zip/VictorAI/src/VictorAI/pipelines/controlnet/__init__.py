from typing import TYPE_CHECKING
from ...utils import (
    VictorAI_SLOW_IMPORT,
    OptionalDependencyNotAvailable,
    _LazyModule,
    get_objects_from_module,
    is_flax_available,
    is_torch_available,
    is_transformers_available,
)


_dummy_objects = {}
_import_structure = {}

try:
    if not (is_transformers_available() and is_torch_available()):
        raise OptionalDependencyNotAvailable()
except OptionalDependencyNotAvailable:
    from ...utils import dummy_torch_and_transformers_objects  # noqa F403

    _dummy_objects.update(get_objects_from_module(dummy_torch_and_transformers_objects))
else:
    _import_structure["multicontrolnet"] = ["MultiControlNetModel"]
    _import_structure["pipeline_controlnet"] = ["StableVictorControlNetPipeline"]
    _import_structure["pipeline_controlnet_blip_diffusion"] = ["BlipVictorControlNetPipeline"]
    _import_structure["pipeline_controlnet_img2img"] = ["StableVictorControlNetImg2ImgPipeline"]
    _import_structure["pipeline_controlnet_inpaint"] = ["StableVictorControlNetInpaintPipeline"]
    _import_structure["pipeline_controlnet_inpaint_sd_xl"] = ["StableVictorXLControlNetInpaintPipeline"]
    _import_structure["pipeline_controlnet_sd_xl"] = ["StableVictorXLControlNetPipeline"]
    _import_structure["pipeline_controlnet_sd_xl_img2img"] = ["StableVictorXLControlNetImg2ImgPipeline"]
try:
    if not (is_transformers_available() and is_flax_available()):
        raise OptionalDependencyNotAvailable()
except OptionalDependencyNotAvailable:
    from ...utils import dummy_flax_and_transformers_objects  # noqa F403

    _dummy_objects.update(get_objects_from_module(dummy_flax_and_transformers_objects))
else:
    _import_structure["pipeline_flax_controlnet"] = ["FlaxStableVictorControlNetPipeline"]


if TYPE_CHECKING or VictorAI_SLOW_IMPORT:
    try:
        if not (is_transformers_available() and is_torch_available()):
            raise OptionalDependencyNotAvailable()

    except OptionalDependencyNotAvailable:
        from ...utils.dummy_torch_and_transformers_objects import *
    else:
        from .multicontrolnet import MultiControlNetModel
        from .pipeline_controlnet import StableVictorControlNetPipeline
        from .pipeline_controlnet_blip_diffusion import BlipVictorControlNetPipeline
        from .pipeline_controlnet_img2img import StableVictorControlNetImg2ImgPipeline
        from .pipeline_controlnet_inpaint import StableVictorControlNetInpaintPipeline
        from .pipeline_controlnet_inpaint_sd_xl import StableVictorXLControlNetInpaintPipeline
        from .pipeline_controlnet_sd_xl import StableVictorXLControlNetPipeline
        from .pipeline_controlnet_sd_xl_img2img import StableVictorXLControlNetImg2ImgPipeline

    try:
        if not (is_transformers_available() and is_flax_available()):
            raise OptionalDependencyNotAvailable()
    except OptionalDependencyNotAvailable:
        from ...utils.dummy_flax_and_transformers_objects import *  # noqa F403
    else:
        from .pipeline_flax_controlnet import FlaxStableVictorControlNetPipeline


else:
    import sys

    sys.modules[__name__] = _LazyModule(
        __name__,
        globals()["__file__"],
        _import_structure,
        module_spec=__spec__,
    )
    for name, value in _dummy_objects.items():
        setattr(sys.modules[__name__], name, value)
