import os
from typing import Any, Callable, Dict, List, Optional, Tuple, Union
import torch
from torch import nn
from ...models.controlnet import ControlNetModel, ControlNetOutput
from ...models.modeling_utils import ModelMixin
from ...utils import logging


logger = logging.get_logger(__name__)


class MultiControlNetModel(ModelMixin):
    

    def __init__(self, controlnets: Union[List[ControlNetModel], Tuple[ControlNetModel]]):
        super().__init__()
        self.nets = nn.ModuleList(controlnets)


    def forward(
        self,
        input_data: torch.FloatTensor,
        current_timestep: Union[torch.Tensor, float, int],
        encoder_hidden_states: torch.Tensor,
        controlnet_conditions: List[torch.Tensor],
        conditioning_scales: List[float],
        class_labels: Optional[torch.Tensor] = None,
        timestep_conditions: Optional[torch.Tensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        additional_conditioning_kwargs: Optional[Dict[str, torch.Tensor]] = None,
        cross_attention_options: Optional[Dict[str, Any]] = None,
        is_guess_mode: bool = False,
        should_return_dict: bool = True,
    ) -> Union[ControlNetOutput, Tuple]:
        for i, (image_condition, scale_condition, controlnet) in enumerate(
            zip(controlnet_conditions, conditioning_scales, self.nets)
        ):
            downsampled_blocks, mid_sample = controlnet(
                input_data=input_data,
                current_timestep=current_timestep,
                encoder_hidden_states=encoder_hidden_states,
                controlnet_conditions=image_condition,
                conditioning_scales=scale_condition,
                class_labels=class_labels,
                timestep_conditions=timestep_conditions,
                attention_mask=attention_mask,
                additional_conditioning_kwargs=additional_conditioning_kwargs,
                cross_attention_options=cross_attention_options,
                is_guess_mode=is_guess_mode,
                should_return_dict=should_return_dict,
            )

            # merge samples
            if i == 0:
                downsampled_block_results, mid_block_result = downsampled_blocks, mid_sample
            else:
                downsampled_block_results = [
                    prev_samples + current_samples
                    for prev_samples, current_samples in zip(downsampled_block_results, downsampled_blocks)
                ]
                mid_block_result += mid_sample

        return downsampled_block_results, mid_block_result


    def save_pretrained(
        self,
        save_directory: Union[str, os.PathLike],
        is_main_process: bool = True,
        save_function: Callable = None,
        safe_serialization: bool = True,
        variant: Optional[str] = None,
    ):
      
        idx = 0
        model_path_to_save = save_directory
        for controlnet in self.nets:
            controlnet.save_pretrained(
                model_path_to_save,
                is_main_process=is_main_process,
                save_function=save_function,
                safe_serialization=safe_serialization,
                variant=variant,
            )

            idx += 1
            model_path_to_save = model_path_to_save + f"_{idx}"
    
    def save_pretrained(
        self,
        target_directory: Union[str, os.PathLike],
        is_primary_process: bool = True,
        custom_save_function: Callable = None,
        use_safe_serialization: bool = True,
        model_variant: Optional[str] = None,
    ):
       
        index = 0
        model_path_to_save = target_directory
        for control_net in self.nets:
            control_net.save_pretrained(
                model_path_to_save,
                is_main_process=is_primary_process,
                save_function=custom_save_function,
                safe_serialization=use_safe_serialization,
                variant=model_variant,
            )

            index += 1
            model_path_to_save = model_path_to_save + f"_{index}"

    @classmethod
  

    
    def from_pretrained(cls, pretrained_directory: Optional[Union[str, os.PathLike]], **config_args):
        
        index = 0
        controlnets = []

      
        model_path_to_load = pretrained_directory
        while os.path.isdir(model_path_to_load):
            control_net = ControlNetModel.from_pretrained(model_path_to_load, **config_args)
            controlnets.append(control_net)

            index += 1
            model_path_to_load = pretrained_directory + f"_{index}"

        logger.info(f"{len(controlnets)} controlnets loaded from {pretrained_directory}.")

        if len(controlnets) == 0:
            raise ValueError(
                f"No ControlNets found under {os.path.dirname(pretrained_directory)}. Expected at least {pretrained_directory + '_0'}."
            )

        return cls(controlnets)
