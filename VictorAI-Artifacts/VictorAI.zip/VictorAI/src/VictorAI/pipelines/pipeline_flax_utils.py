import importlib
import inspect
import os
from typing import Any, Dict, List, Optional, Union
import flax
import numpy as np
import PIL.Image
from flax.core.frozen_dict import FrozenDict
from huggingface_hub import create_repo, snapshot_download
from PIL import Image
from tqdm.auto import tqdm
from ..configuration_utils import ConfigMixin
from ..models.modeling_flax_utils import FLAX_WEIGHTS_NAME, FlaxModelMixin
from ..schedulers.scheduling_utils_flax import SCHEDULER_CONFIG_NAME, FlaxSchedulerMixin
from ..utils import (
    CONFIG_NAME,
    VICTOR_CACHE,
    BaseOutput,
    PushToHubMixin,
    http_user_agent,
    is_transformers_available,
    logging
)


if is_transformers_available():
    from transformers import FlaxPreTrainedModel

INDEX_FILE = "diffusion_flax_model.bin"


logger = logging.get_logger(__name__)


LOADABLE_CLASSES = {
    "VictorAI": {
        "FlaxModelMixin": ["save_pretrained", "from_pretrained"],
        "FlaxSchedulerMixin": ["save_pretrained", "from_pretrained"],
        "FlaxVictorPipeline": ["save_pretrained", "from_pretrained"],
    },
    "transformers": {
        "PreTrainedTokenizer": ["save_pretrained", "from_pretrained"],
        "PreTrainedTokenizerFast": ["save_pretrained", "from_pretrained"],
        "FlaxPreTrainedModel": ["save_pretrained", "from_pretrained"],
        "FeatureExtractionMixin": ["save_pretrained", "from_pretrained"],
        "ProcessorMixin": ["save_pretrained", "from_pretrained"],
        "ImageProcessingMixin": ["save_pretrained", "from_pretrained"],
    },
}

ALL_IMPORTABLE_CLASSES = {}
for library in LOADABLE_CLASSES:
    ALL_IMPORTABLE_CLASSES.update(LOADABLE_CLASSES[library])




def import_flax_or_no_model(import_module, target_class_name):
    try:
        # 1. First make sure that if a Flax object is present, import this one
        class_object = getattr(import_module, "Flax" + target_class_name)
    except AttributeError:
        # 2. If this doesn't work, it's not a model and we don't append "Flax"
        class_object = getattr(import_module, target_class_name)
    except AttributeError:
        raise ValueError(f"Neither Flax{target_class_name} nor {target_class_name} exist in {import_module}")

    return class_object


@flax.struct.dataclass
class FlaxImagePipelineOutput(BaseOutput):
   

    images: Union[List[PIL.Image.Image], np.ndarray]


class FlaxVictorPipeline(ConfigMixin, PushToHubMixin):
    

    config_name = "model_index.json"

    def register_modules(self, **module_kwargs):
        # import it here to avoid circular import
        from VictorAI import pipelines

        for module_name, module_instance in module_kwargs.items():
            if module_instance is None:
                register_info = {module_name: (None, None)}
            else:
                # retrieve library
                library = module_instance.__module__.split(".")[0]

                # check if the module is a pipeline module
                pipeline_dir = module_instance.__module__.split(".")[-2]
                path = module_instance.__module__.split(".")
                is_pipeline_module = pipeline_dir in path and hasattr(pipelines, pipeline_dir)

                if library not in LOADABLE_CLASSES or is_pipeline_module:
                    library = pipeline_dir

                # retrieve class_name
                class_name = module_instance.__class__.__name__

                register_info = {module_name: (library, class_name)}

            # save model index config
            self.register_to_config(**register_info)

            # set models
            setattr(self, module_name, module_instance)






    def save_pretrained(
        self,
        destination_directory: Union[str, os.PathLike],
        custom_params: Union[Dict, FrozenDict],
        publish_to_hub: bool = False,
        **additional_kwargs,
    ):
      
       
        self.save_config(destination_directory)

        model_index_dict = dict(self.config)
        model_index_dict.pop("_class_name")
        model_index_dict.pop("_victor_version")
        model_index_dict.pop("_module", None)

        if publish_to_hub:
            commit_message = additional_kwargs.pop("commit_message", None)
            private = additional_kwargs.pop("private", False)
            create_pr = additional_kwargs.pop("create_pr", False)
            token = additional_kwargs.pop("token", None)
            repo_id = additional_kwargs.pop("repo_id", destination_directory.split(os.path.sep)[-1])
            repo_id = create_repo(repo_id, exist_ok=True, private=private, token=token).repo_id

        for pipeline_component_name in model_index_dict.keys():
            sub_model = getattr(self, pipeline_component_name)
            if sub_model is None:
                # edge case for saving a pipeline with safety_checker=None
                continue

            model_cls = sub_model.__class__

            save_method_name = None
            # search for the model's base class in LOADABLE_CLASSES
            for library_name, library_classes in LOADABLE_CLASSES.items():
                library = importlib.import_module(library_name)
                for base_class, save_load_methods in library_classes.items():
                    class_candidate = getattr(library, base_class, None)
                    if class_candidate is not None and issubclass(model_cls, class_candidate):
                        # if we found a suitable base class in LOADABLE_CLASSES then grab its save method
                        save_method_name = save_load_methods[0]
                        break
                if save_method_name is not None:
                    break

            save_method = getattr(sub_model, save_method_name)
            expects_params = "params" in set(inspect.signature(save_method).parameters.keys())

            if expects_params:
                save_method(
                    os.path.join(destination_directory, pipeline_component_name), params=custom_params[pipeline_component_name]
                )
            else:
                save_method(os.path.join(destination_directory, pipeline_component_name))

            if publish_to_hub:
                self._upload_folder(
                    destination_directory,
                    repo_id,
                    token=token,
                    commit_message=commit_message,
                    create_pr=create_pr,
                )



    @classmethod
   
    def from_pretrained(cls, pretrained_model_or_path: Optional[Union[str, os.PathLike]], **config_kwargs):
        
        cache_dir = config_kwargs.pop("cache_dir", VICTOR_CACHE)
        resume_download = config_kwargs.pop("resume_download", False)
        proxies = config_kwargs.pop("proxies", None)
        local_files_only = config_kwargs.pop("local_files_only", False)
        use_auth_token = config_kwargs.pop("use_auth_token", None)
        revision = config_kwargs.pop("revision", None)
        from_pt = config_kwargs.pop("from_pt", False)
        use_memory_efficient_attention = config_kwargs.pop("use_memory_efficient_attention", False)
        split_head_dim = config_kwargs.pop("split_head_dim", False)
        dtype = config_kwargs.pop("dtype", None)

        # 1. Download the checkpoints and configs
        # use snapshot download here to get it working from from_pretrained
        if not os.path.isdir(pretrained_model_or_path):
            config_dict = cls.load_config(
                pretrained_model_or_path,
                cache_dir=cache_dir,
                resume_download=resume_download,
                proxies=proxies,
                local_files_only=local_files_only,
                use_auth_token=use_auth_token,
                revision=revision,
            )
            # make sure we only download sub-folders and `VictorAI` filenames
            folder_names = [k for k in config_dict.keys() if not k.startswith("_")]
            allow_patterns = [os.path.join(k, "*") for k in folder_names]
            allow_patterns += [FLAX_WEIGHTS_NAME, SCHEDULER_CONFIG_NAME, CONFIG_NAME, cls.config_name]

            ignore_patterns = ["*.bin", "*.safetensors"] if not from_pt else []
            ignore_patterns += ["*.onnx", "*.onnx_data", "*.xml", "*.pb"]

            if cls != FlaxVictorPipeline:
                requested_pipeline_class = cls.__name__
            else:
                requested_pipeline_class = config_dict.get("_class_name", cls.__name__)
                requested_pipeline_class = (
                    requested_pipeline_class
                    if requested_pipeline_class.startswith("Flax")
                    else "Flax" + requested_pipeline_class
                )

            user_agent = {"pipeline_class": requested_pipeline_class}
            user_agent = http_user_agent(user_agent)

            # download all allow_patterns
            cached_folder = snapshot_download(
                pretrained_model_or_path,
                cache_dir=cache_dir,
                resume_download=resume_download,
                proxies=proxies,
                local_files_only=local_files_only,
                use_auth_token=use_auth_token,
                revision=revision,
                allow_patterns=allow_patterns,
                ignore_patterns=ignore_patterns,
                user_agent=user_agent,
            )
        else:
            cached_folder = pretrained_model_or_path

        config_dict = cls.load_config(cached_folder)

        if cls != FlaxVictorPipeline:
            pipeline_class = cls
        else:
            VictorAI_module = importlib.import_module(cls.__module__.split(".")[0])
            class_name = (
                config_dict["_class_name"]
                if config_dict["_class_name"].startswith("Flax")
                else "Flax" + config_dict["_class_name"]
            )
            pipeline_class = getattr(VictorAI_module, class_name)

        # some modules can be passed directly to the init
        # in this case they are already instantiated in `config_kwargs`
        # extract them here
        expected_modules, optional_kwargs = cls._get_signature_keys(pipeline_class)
        passed_class_obj = {k: config_kwargs.pop(k) for k in expected_modules if k in config_kwargs}
        passed_pipe_kwargs = {k: config_kwargs.pop(k) for k in optional_kwargs if k in config_kwargs}

        init_dict, unused_kwargs, _ = pipeline_class.extract_init_dict(config_dict, **config_kwargs)

        # define init kwargs
        init_kwargs = {k: init_dict.pop(k) for k in optional_kwargs if k in init_dict}
        init_kwargs = {**init_kwargs, **passed_pipe_kwargs}

        # remove `null` components
        def load_module(name, value):
            if value[0] is None:
                return False
            if name in passed_class_obj and passed_class_obj[name] is None:
                return False
            return True

        init_dict = {k: v for k, v in init_dict.items() if load_module(k, v)}

        # Throw nice warnings / errors for fast accelerate loading
        if len(unused_kwargs) > 0:
            logger.warning(
                f"Keyword arguments {unused_kwargs} are not expected by {pipeline_class.__name__} and will be ignored."
            )

        # inference_params
        params = {}

        # import it here to avoid circular import
        from VictorAI import pipelines

        # 3. Load each module in the pipeline
        for name, (library_name, class_name) in init_dict.items():
            if class_name is None:
                # edge case for when the pipeline was saved with safety_checker=None
                init_kwargs[name] = None
                continue

            is_pipeline_module = hasattr(pipelines, library_name)
            loaded_sub_model = None
            sub_model_should_be_defined = True

            # if the model is in a pipeline module, then we load it from the pipeline
            if name in passed_class_obj:
                # 1. check that passed_class_obj has correct parent class
                if not is_pipeline_module:
                    library = importlib.import_module(library_name)
                    class_obj = getattr(library, class_name)
                    importable_classes = LOADABLE_CLASSES[library_name]
                    class_candidates = {c: getattr(library, c, None) for c in importable_classes.keys()}

                    expected_class_obj = None
                    for class_name, class_candidate in class_candidates.items():
                        if class_candidate is not None and issubclass(class_obj, class_candidate):
                            expected_class_obj = class_candidate

                    if not issubclass(passed_class_obj[name].__class__, expected_class_obj):
                        raise ValueError(
                            f"{passed_class_obj[name]} is of type: {type(passed_class_obj[name])}, but should be"
                            f" {expected_class_obj}"
                        )
                elif passed_class_obj[name] is None:
                    logger.warning(
                        f"You have passed `None` for {name} to disable its functionality in {pipeline_class}. Note"
                        f" that this might lead to problems when using {pipeline_class} and is not recommended."
                    )
                    sub_model_should_be_defined = False
                else:
                    logger.warning(
                        f"You have passed a non-standard module {passed_class_obj[name]}. We cannot verify whether it"
                        " has the correct type"
                    )

                # set passed class object
                loaded_sub_model = passed_class_obj[name]
            elif is_pipeline_module:
                pipeline_module = getattr(pipelines, library_name)
                class_obj = import_flax_or_no_model(pipeline_module, class_name)

                importable_classes = ALL_IMPORTABLE_CLASSES
                class_candidates = {c: class_obj for c in importable_classes.keys()}
            else:
                # else we just import it from the library.
                library = importlib.import_module(library_name)
                class_obj = import_flax_or_no_model(library, class_name)

                importable_classes = LOADABLE_CLASSES[library_name]
                class_candidates = {c: getattr(library, c, None) for c in importable_classes.keys()}

            if loaded_sub_model is None and sub_model_should_be_defined:
                load_method_name = None
                for class_name, class_candidate in class_candidates.items():
                    if class_candidate is not None and issubclass(class_obj, class_candidate):
                        load_method_name = importable_classes[class_name][1]

                load_method = getattr(class_obj, load_method_name)

                # check if the module is in a subdirectory
                if os.path.isdir(os.path.join(cached_folder, name)):
                    loadable_folder = os.path.join(cached_folder, name)
                else:
                    loaded_sub_model = cached_folder

                if issubclass(class_obj, FlaxModelMixin):
                    loaded_sub_model, loaded_params = load_method(
                        loadable_folder,
                        from_pt=from_pt,
                        use_memory_efficient_attention=use_memory_efficient_attention,
                        split_head_dim=split_head_dim,
                        dtype=dtype,
                    )
                    params[name] = loaded_params
                elif is_transformers_available() and issubclass(class_obj, FlaxPreTrainedModel):
                    if from_pt:
                        # TODO(Suraj): Fix this in Transformers. We should be able to use `_do_init=False` here
                        loaded_sub_model = load_method(loadable_folder, from_pt=from_pt)
                        loaded_params = loaded_sub_model.params
                        del loaded_sub_model._params
                    else:
                        loaded_sub_model, loaded_params = load_method(loadable_folder, _do_init=False)
                    params[name] = loaded_params
                elif issubclass(class_obj, FlaxSchedulerMixin):
                    loaded_sub_model, scheduler_state = load_method(loadable_folder)
                    params[name] = scheduler_state
                else:
                    loaded_sub_model = load_method(loadable_folder)

            init_kwargs[name] = loaded_sub_model  # UNet(...), # DiffusionSchedule(...)

        
        missing_modules = set(expected_modules) - set(init_kwargs.keys())
        passed_modules = list(passed_class_obj.keys())

        if len(missing_modules) > 0 and missing_modules <= set(passed_modules):
            for module in missing_modules:
                init_kwargs[module] = passed_class_obj.get(module, None)
        elif len(missing_modules) > 0:
            passed_modules = set(list(init_kwargs.keys()) + list(passed_class_obj.keys())) - optional_kwargs
            raise ValueError(
                f"Pipeline {pipeline_class} expected {expected_modules}, but only {passed_modules} were passed."
            )

        model = pipeline_class(**init_kwargs, dtype=dtype)

        # 5. Return the model and parameters
        return model, params



    @staticmethod
    def _get_signature_keys(obj):
        parameters = inspect.signature(obj.__init__).parameters
        required_parameters = {k: v for k, v in parameters.items() if v.default == inspect._empty}
        optional_parameters = set({k for k, v in parameters.items() if v.default != inspect._empty})
        expected_modules = set(required_parameters.keys()) - {"self"}
        return expected_modules, optional_parameters

    def _get_signature_keys(obj):
        function_parameters = inspect.signature(obj.__init__).parameters
        required_params = {param_name: param_info for param_name, param_info in function_parameters.items() if param_info.default == inspect._empty}
        optional_params = set({param_name for param_name, param_info in function_parameters.items() if param_info.default != inspect._empty})
        expected_keys = set(required_params.keys()) - {"self"}
        
        return expected_keys, optional_params

    @property
    
    def components(self) -> Dict[str, Any]:
       
        expected_keys, optional_params = self._get_signature_keys(self)
        pipeline_components = {
            key: getattr(self, key) for key in self.config.keys() if not key.startswith("_") and key not in optional_params
        }

        if set(pipeline_components.keys()) != expected_keys:
            raise ValueError(
                f"{self} has been incorrectly initialized or {self.__class__} is incorrectly implemented. Expected"
                f" {expected_keys} to be defined, but {pipeline_components} are defined."
            )

        return pipeline_components


    @staticmethod
   

    def numpy_to_pil(input_images):
        """
        Convert a NumPy image or a batch of images to a PIL image.
        """
        if input_images.ndim == 3:
            input_images = input_images[None, ...]
        pil_images = (input_images * 255).round().astype("uint8")
        
        if pil_images.shape[-1] == 1:
            # special case for grayscale (single channel) images
            result_images = [Image.fromarray(image.squeeze(), mode="L") for image in pil_images]
        else:
            result_images = [Image.fromarray(image) for image in pil_images]

        return result_images


   

    def progress_bar(self, iterable_input):
        if not hasattr(self, "_progress_bar_config"):
            self._progress_bar_config = {}
        elif not isinstance(self._progress_bar_config, dict):
            raise ValueError(
                f"`self._progress_bar_config` should be of type `dict`, but is {type(self._progress_bar_config)}."
            )

        return tqdm(iterable_input, **self._progress_bar_config)


    def set_progress_bar_config(self, **kwargs):
        self._progress_bar_config = kwargs
