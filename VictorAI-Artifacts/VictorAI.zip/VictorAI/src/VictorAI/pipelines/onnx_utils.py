import os
import shutil
from pathlib import Path
from typing import Optional, Union
import numpy as np
from huggingface_hub import hf_hub_download
from ..utils import ONNX_EXTERNAL_WEIGHTS_NAME, ONNX_WEIGHTS_NAME, is_onnx_available, logging


if is_onnx_available():
    import onnxruntime as ort


logger = logging.get_logger(__name__)

ORT_TO_NP_TYPE = {
    "tensor(bool)": np.bool_,
    "tensor(int8)": np.int8,
    "tensor(uint8)": np.uint8,
    "tensor(int16)": np.int16,
    "tensor(uint16)": np.uint16,
    "tensor(int32)": np.int32,
    "tensor(uint32)": np.uint32,
    "tensor(int64)": np.int64,
    "tensor(uint64)": np.uint64,
    "tensor(float16)": np.float16,
    "tensor(float)": np.float32,
    "tensor(double)": np.float64,
}


class OnnxRuntimeModel:
    def __init__(self, model=None, **kwargs):
        logger.info("`VictorAI.OnnxRuntimeModel` is experimental and might change in the future.")
        self.model = model
        self.model_save_dir = kwargs.get("model_save_dir", None)
        self.latest_model_name = kwargs.get("latest_model_name", ONNX_WEIGHTS_NAME)

    def __call__(self, **kwargs):
        inputs = {k: np.array(v) for k, v in kwargs.items()}
        return self.model.run(None, inputs)

    @staticmethod
   
    def load_model(provided_path: Union[str, Path], input_provider=None, options_for_sess=None):
        """
        Loads an ONNX Inference session with an ExecutionProvider. Default provider is `CPUExecutionProvider`

        Arguments:
            provided_path (`str` or `Path`):
                Directory from which to load
            provider(`str`, *optional*):
                Onnxruntime execution provider to use for loading the model, defaults to `CPUExecutionProvider`
        """
        if input_provider is None:
            logger.info("No onnxruntime provider specified, using CPUExecutionProvider")
            input_provider = "CPUExecutionProvider"

        return ort.InferenceSession(provided_path, providers=[input_provider], sess_options=options_for_sess)

  

    def _save_pretrained(self, destination_directory: Union[str, Path], custom_file_name: Optional[str] = None, **custom_kwargs):
      
        model_file_name = custom_file_name if custom_file_name is not None else ONNX_WEIGHTS_NAME

        src_path = self.model_save_dir.joinpath(self.latest_model_name)
        dst_path = Path(destination_directory).joinpath(model_file_name)
        try:
            shutil.copyfile(src_path, dst_path)
        except shutil.SameFileError:
            pass

        # copy external weights (for models >2GB)
        src_path = self.model_save_dir.joinpath(ONNX_EXTERNAL_WEIGHTS_NAME)
        if src_path.exists():
            dst_path = Path(destination_directory).joinpath(ONNX_EXTERNAL_WEIGHTS_NAME)
            try:
                shutil.copyfile(src_path, dst_path)
            except shutil.SameFileError:
                pass



    def save_pretrained(
        self,
        destination_directory: Union[str, os.PathLike],
        **custom_kwargs,
    ):
        """
        Save a model to a directory, so that it can be re-loaded using the [`~OnnxModel.from_pretrained`] class
        method.:

        Arguments:
            destination_directory (`str` or `os.PathLike`):
                Directory to which to save. Will be created if it doesn't exist.
        """
        if os.path.isfile(destination_directory):
            logger.error(f"Provided path ({destination_directory}) should be a directory, not a file")
            return

        os.makedirs(destination_directory, exist_ok=True)

        self._save_pretrained(destination_directory, **custom_kwargs)


    @classmethod
   
 
    def _from_pretrained(
        cls,
        model_identifier: Union[str, Path],
        use_authentication_token: Optional[Union[bool, str, None]] = None,
        specific_revision: Optional[Union[str, None]] = None,
        enforce_download: bool = False,
        local_cache_directory: Optional[str] = None,
        custom_file_name: Optional[str] = None,
        runtime_provider: Optional[str] = None,
        session_options: Optional["ort.SessionOptions"] = None,
        **additional_kwargs,
    ):
        
        model_file_name = custom_file_name if custom_file_name is not None else ONNX_WEIGHTS_NAME
        # load model from local directory
        if os.path.isdir(model_identifier):
            model = OnnxRuntimeModel.load_model(
                os.path.join(model_identifier, model_file_name), provider=runtime_provider, sess_options=session_options
            )
            additional_kwargs["model_save_dir"] = Path(model_identifier)
        # load model from hub
        else:
            # download model
            model_cache_path = hf_hub_download(
                repo_id=model_identifier,
                filename=model_file_name,
                use_auth_token=use_authentication_token,
                revision=specific_revision,
                cache_dir=local_cache_directory,
                force_download=enforce_download,
            )
            additional_kwargs["model_save_dir"] = Path(model_cache_path).parent
            additional_kwargs["latest_model_name"] = Path(model_cache_path).name
            model = OnnxRuntimeModel.load_model(model_cache_path, provider=runtime_provider, sess_options=session_options)
        return cls(model=model, **additional_kwargs)


    @classmethod
   
    def from_pretrained(
        cls,
        model_identifier: Union[str, Path],
        enforce_download: bool = True,
        authentication_token: Optional[str] = None,
        local_cache_directory: Optional[str] = None,
        **additional_model_kwargs,
    ):
        revision = None
        if len(str(model_identifier).split("@")) == 2:
            model_identifier, revision = model_identifier.split("@")

        return cls._from_pretrained(
            model_id=model_identifier,
            specific_revision=revision,
            local_cache_directory=local_cache_directory,
            enforce_download=enforce_download,
            use_authentication_token=authentication_token,
            **additional_model_kwargs,
        )

