
from typing import Dict, List, Optional, Union

import safetensors
import torch
from torch import nn

from ..utils import (
    VICTOR_CACHE,
    HF_HUB_OFFLINE,
    _get_model_file,
    is_accelerate_available,
    is_transformers_available,
    logging,
)


if is_transformers_available():
    from transformers import PreTrainedModel, PreTrainedTokenizer

if is_accelerate_available():
    from accelerate.hooks import AlignDevicesHook, CpuOffload, remove_hook_from_module

logger = logging.get_logger(__name__)

TEXT_INVERSION_NAME = "learned_embeds.bin"
TEXT_INVERSION_NAME_SAFE = "learned_embeds.safetensors"



def load_textual_inversion_state_dicts(pretrained_model_name_or_paths, **kwargs):
    cache_directory = kwargs.pop("cache_directory", VICTOR_CACHE)
    enforce_download = kwargs.pop("enforce_download", False)
    resume_download = kwargs.pop("resume_download", False)
    connection_proxies = kwargs.pop("connection_proxies", None)
    local_only = kwargs.pop("local_only", HF_HUB_OFFLINE)
    auth_token = kwargs.pop("auth_token", None)
    git_revision = kwargs.pop("git_revision", None)
    sub_folder = kwargs.pop("sub_folder", None)
    weight_alias = kwargs.pop("weight_alias", None)
    employ_safetensors = kwargs.pop("employ_safetensors", None)

    permit_pickling = False
    if employ_safetensors is None:
        employ_safetensors = True
        permit_pickling = True

    user_agent_info = {
        "file_type": "text_inversion",
        "framework": "pytorch",
    }
    inversion_states = []
    for pretrained_model_name_or_path in pretrained_model_name_or_paths:
        if not isinstance(pretrained_model_name_or_path, (dict, torch.Tensor)):
            
            model_file = None

         
            if (employ_safetensors and weight_alias is None) or (
                weight_alias is not None and weight_alias.endswith(".safetensors")
            ):
                try:
                    model_file = _get_model_file(
                        pretrained_model_name_or_path,
                        weights_name=weight_alias or TEXT_INVERSION_NAME_SAFE,
                        cache_directory=cache_directory,
                        enforce_download=enforce_download,
                        resume_download=resume_download,
                        connection_proxies=connection_proxies,
                        local_only=local_only,
                        auth_token=auth_token,
                        git_revision=git_revision,
                        sub_folder=sub_folder,
                        user_agent=user_agent_info,
                    )
                    inversion_state = safetensors.torch.load_file(model_file, device="cpu")
                except Exception as error:
                    if not permit_pickling:
                        raise error

                    model_file = None

            if model_file is None:
                model_file = _get_model_file(
                    pretrained_model_name_or_path,
                    weights_name=weight_alias or TEXT_INVERSION_NAME,
                    cache_directory=cache_directory,
                    enforce_download=enforce_download,
                    resume_download=resume_download,
                    connection_proxies=connection_proxies,
                    local_only=local_only,
                    auth_token=auth_token,
                    git_revision=git_revision,
                    sub_folder=sub_folder,
                    user_agent=user_agent_info,
                )
                inversion_state = torch.load(model_file, map_location="cpu")
        else:
            inversion_state = pretrained_model_name_or_path

        inversion_states.append(inversion_state)

    return inversion_states



class TextualInversionLoaderMixin:
    
  

    def maybe_convert_prompt(self, user_prompt: Union[str, List[str]], text_tokenizer: "PreTrainedTokenizer"):  # noqa: F821
      
        if not isinstance(user_prompt, List):
            prompts = [user_prompt]
        else:
            prompts = user_prompt

        prompts = [self._maybe_convert_prompt(prompt, text_tokenizer) for prompt in prompts]

        if not isinstance(user_prompt, List):
            return prompts[0]

        return prompts


   

    def _maybe_convert_prompt(self, user_prompt: str, text_tokenizer: "PreTrainedTokenizer"):  # noqa: F821
      
        tokens = text_tokenizer.tokenize(user_prompt)
        unique_tokens = set(tokens)
        for token in unique_tokens:
            if token in text_tokenizer.added_tokens_encoder:
                replacement = token
                i = 1
                while f"{token}_{i}" in text_tokenizer.added_tokens_encoder:
                    replacement += f" {token}_{i}"
                    i += 1

                user_prompt = user_prompt.replace(token, replacement)

        return user_prompt



    def _check_text_inv_inputs(self, input_tokenizer, input_text_encoder, model_name_or_paths, input_tokens):
        if input_tokenizer is None:
            raise ValueError(
                f"{self.__class__.__name__} requires `self.tokenizer` or passing a `tokenizer` of type `PreTrainedTokenizer` for calling"
                f" `{self.load_textual_inversion.__name__}`"
            )

        if input_text_encoder is None:
            raise ValueError(
                f"{self.__class__.__name__} requires `self.text_encoder` or passing a `text_encoder` of type `PreTrainedModel` for calling"
                f" `{self.load_textual_inversion.__name__}`"
            )

        if len(model_name_or_paths) != len(input_tokens):
            raise ValueError(
                f"You have passed a list of models of length {len(model_name_or_paths)}, and a list of tokens of length {len(input_tokens)} "
                f"Make sure both lists have the same length."
            )

        valid_tokens = [token for token in input_tokens if token is not None]
        if len(set(valid_tokens)) < len(valid_tokens):
            raise ValueError(f"You have passed a list of tokens that contains duplicates: {input_tokens}")


    @staticmethod
   
    def _retrieve_tokens_and_embeddings(input_tokens, input_state_dicts, input_tokenizer):
        retrieved_tokens = []
        retrieved_embeddings = []

        for state_dict, token in zip(input_state_dicts, input_tokens):
            if isinstance(state_dict, torch.Tensor):
                if token is None:
                    raise ValueError(
                        "You are trying to load a textual inversion embedding that has been saved as a PyTorch tensor. Make sure to pass the name of the corresponding token in this case: `token=...`."
                    )
                loaded_token = token
                embedding = state_dict
            elif len(state_dict) == 1:
                # VictorAI
                loaded_token, embedding = next(iter(state_dict.items()))
            elif "string_to_param" in state_dict:
                # A1111
                loaded_token = state_dict["name"]
                embedding = state_dict["string_to_param"]["*"]
            else:
                raise ValueError(
                    f"Loaded state dictionary is incorrect: {state_dict}. \n\n"
                    "Please verify that the loaded state dictionary of the textual embedding either only has a single key or includes the `string_to_param`"
                    " input key."
                )

            if token is not None and loaded_token != token:
                logger.info(f"The loaded token: {loaded_token} is overwritten by the passed token {token}.")
            else:
                token = loaded_token

            if token in input_tokenizer.get_vocab():
                raise ValueError(
                    f"Token {token} already exists in the tokenizer vocabulary. Please choose a different token name or remove {token} and its embedding from the tokenizer and text encoder."
                )

            retrieved_tokens.append(token)
            retrieved_embeddings.append(embedding)

        return retrieved_tokens, retrieved_embeddings


    @staticmethod
   

    def _extend_tokens_and_embeddings(input_tokens, input_embeddings, input_tokenizer):
        extended_tokens = []
        extended_embeddings = []

        for embedding, token in zip(input_embeddings, input_tokens):
            if f"{token}_1" in input_tokenizer.get_vocab():
                multi_vector_tokens = [token]
                i = 1
                while f"{token}_{i}" in input_tokenizer.added_tokens_encoder:
                    multi_vector_tokens.append(f"{token}_{i}")
                    i += 1

                raise ValueError(
                    f"Multi-vector Token {multi_vector_tokens} already exists in the tokenizer vocabulary. Please choose a different token name or remove the {multi_vector_tokens} and its embedding from the tokenizer and text encoder."
                )

            is_multi_vector = len(embedding.shape) > 1 and embedding.shape[0] > 1
            if is_multi_vector:
                extended_tokens += [token] + [f"{token}_{i}" for i in range(1, embedding.shape[0])]
                extended_embeddings += [e for e in embedding]  # noqa: C416
            else:
                extended_tokens += [token]
                extended_embeddings += [embedding[0]] if len(embedding.shape) > 1 else [embedding]

        return extended_tokens, extended_embeddings


  

    def load_textual_inversion(
            self,
            pretrained_model_name_or_path: Union[str, List[str], Dict[str, torch.Tensor], List[Dict[str, torch.Tensor]]],
            input_token: Optional[Union[str, List[str]]] = None,
            input_tokenizer: Optional["PreTrainedTokenizer"] = None,  # noqa: F821
            input_text_encoder: Optional["PreTrainedModel"] = None,  # noqa: F821
            **input_kwargs,
        ):
          
            # 1. Set correct tokenizer and text encoder
            input_tokenizer = input_tokenizer or getattr(self, "tokenizer", None)
            input_text_encoder = input_text_encoder or getattr(self, "text_encoder", None)

            
            pretrained_model_name_or_paths = (
                [pretrained_model_name_or_path]
                if not isinstance(pretrained_model_name_or_path, list)
                else pretrained_model_name_or_path
            )
            input_tokens = (
                [input_token]
                if not isinstance(input_token, list)
                else input_token
            ) if (isinstance(input_token, str) or input_token is None) else input_token

            # 3. Check inputs
            self._check_text_inv_inputs(input_tokenizer, input_text_encoder, pretrained_model_name_or_paths, input_tokens)

            # 4. Load state dicts of textual embeddings
            state_dicts = load_textual_inversion_state_dicts(pretrained_model_name_or_paths, **input_kwargs)

            # 4. Retrieve tokens and embeddings
            input_tokens, input_embeddings = self._retrieve_tokens_and_embeddings(input_tokens, state_dicts, input_tokenizer)

            # 5. Extend tokens and embeddings for multi vector
            input_tokens, input_embeddings = self._extend_tokens_and_embeddings(input_tokens, input_embeddings, input_tokenizer)

            # 6. Make sure all embeddings have the correct size
            expected_emb_dim = input_text_encoder.get_input_embeddings().weight.shape[-1]
            if any(expected_emb_dim != emb.shape[-1] for emb in input_embeddings):
                raise ValueError(
                    "Loaded embeddings are of incorrect shape. Expected each textual inversion embedding "
                    "to be of shape {input_embeddings.shape[-1]}, but are {input_embeddings.shape[-1]} "
                )

        
            # 7.1 Offload all hooks in case the pipeline was cpu offloaded before make sure, we offload and onload again
            is_model_cpu_offload = False
            is_sequential_cpu_offload = False
            for _, component in self.components.items():
                if isinstance(component, nn.Module):
                    if hasattr(component, "_hf_hook"):
                        is_model_cpu_offload = isinstance(getattr(component, "_hf_hook"), CpuOffload)
                        is_sequential_cpu_offload = isinstance(getattr(component, "_hf_hook"), AlignDevicesHook)
                        logger.info(
                            "Accelerate hooks detected. Since you have called `load_textual_inversion()`, the previous hooks will be first removed. Then the textual inversion parameters will be loaded and the hooks will be applied again."
                        )
                        remove_hook_from_module(component, recurse=is_sequential_cpu_offload)

            # 7.2 save expected device and dtype
            device = input_text_encoder.device
            dtype = input_text_encoder.dtype

            # 7.3 Increase token embedding matrix
            input_text_encoder.resize_token_embeddings(len(input_tokenizer) + len(input_tokens))
            input_embeddings = input_text_encoder.get_input_embeddings().weight

            # 7.4 Load token and embedding
            for token, embedding in zip(input_tokens, input_embeddings):
                
                input_tokenizer.add_tokens(token)
                token_id = input_tokenizer.convert_tokens_to_ids(token)
                input_embeddings.data[token_id] = embedding
                logger.info(f"Loaded textual inversion embedding for {token}.")

            input_embeddings.to(dtype=dtype, device=device)

            
            if is_model_cpu_offload:
                self.enable_model_cpu_offload()
            elif is_sequential_cpu_offload:
                self.enable_sequential_cpu_offload()

      


