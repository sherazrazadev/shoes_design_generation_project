from typing import Dict

import torch


class AttnProcsLayers(torch.nn.Module):
    def __init__(self, state_dict: Dict[str, torch.Tensor]):
        super().__init__()
        self.layers = torch.nn.ModuleList(state_dict.values())
        self.mapping = dict(enumerate(state_dict.keys()))
        self.rev_mapping = {v: k for k, v in enumerate(state_dict.keys())}

        # .processor for unet, .self_attn for text encoder
        self.split_keys = [".processor", ".self_attn"]

        def map_to(mapping_module, input_state_dict, *args, **kwargs):
            new_state_dict = {}
            for original_key, value in input_state_dict.items():
                num = int(original_key.split(".")[1])  
                new_key = original_key.replace(f"layers.{num}", mapping_module.mapping[num])
                new_state_dict[new_key] = value

            return new_state_dict

        def remap_key(input_key, input_state_dict):
            for split_key in self.split_keys:
                if split_key in input_key:
                    return input_key.split(split_key)[0] + split_key

            raise ValueError(
                f"There seems to be a problem with the input_state_dict: {set(input_state_dict.keys())}. {input_key} has to have one of {self.split_keys}."
            )

        def map_from(mapping_module, input_state_dict, *args, **kwargs):
            all_keys = list(input_state_dict.keys())
            for input_key in all_keys:
                replace_key = remap_key(input_key, input_state_dict)
                new_key = input_key.replace(replace_key, f"layers.{mapping_module.rev_mapping[replace_key]}")
                input_state_dict[new_key] = input_state_dict[input_key]
                del input_state_dict[input_key]

        self._register_state_dict_hook(map_to)
        self._register_load_state_dict_pre_hook(map_from, with_module=True)
