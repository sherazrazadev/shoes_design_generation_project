
from dataclasses import dataclass
from typing import Optional, Tuple, Union
import torch
import torch.nn as nn
from ..configuration_utils import ConfigMixin, register_to_config
from ..utils import BaseOutput
from ..utils.accelerate_utils import apply_forward_hook
from .modeling_utils import ModelMixin
from .vae import Decoder, DecoderOutput, Encoder, VectorQuantizer


@dataclass
class VQEncoderOutput(BaseOutput):


    latents: torch.FloatTensor


class VQModel(ModelMixin, ConfigMixin):
  
    @register_to_config
    def __init__(
        self,
        in_channels: int = 3,
        out_channels: int = 3,
        down_block_types: Tuple[str, ...] = ("DownEncoderBlock2D",),
        up_block_types: Tuple[str, ...] = ("UpDecoderBlock2D",),
        block_out_channels: Tuple[int, ...] = (64,),
        layers_per_block: int = 1,
        act_fn: str = "silu",
        latent_channels: int = 3,
        sample_size: int = 32,
        num_vq_embeddings: int = 256,
        norm_num_groups: int = 32,
        vq_embed_dim: Optional[int] = None,
        scaling_factor: float = 0.18215,
        norm_type: str = "group",  # group, spatial
    ):
        
        super().__init__()
        super().__init__()
        self._initialize_encoder(in_channels, latent_channels, down_block_types, block_out_channels, layers_per_block, act_fn, norm_num_groups)
        self._initialize_decoder(out_channels, up_block_types, block_out_channels, layers_per_block, act_fn, norm_num_groups, norm_type)
        self._initialize_quantization(latent_channels, num_vq_embeddings, vq_embed_dim)

    def _initialize_encoder(self, in_channels, latent_channels, down_block_types, block_out_channels, layers_per_block, act_fn, norm_num_groups):
        self.encoder = Encoder(
            in_channels=in_channels,
            out_channels=latent_channels,
            down_block_types=down_block_types,
            block_out_channels=block_out_channels,
            layers_per_block=layers_per_block,
            act_fn=act_fn,
            norm_num_groups=norm_num_groups,
            double_z=False,
        )

    def _initialize_decoder(self, out_channels,latent_channels, up_block_types, block_out_channels, layers_per_block, act_fn, norm_num_groups, norm_type):
        self.decoder = Decoder(
            in_channels=latent_channels,
            out_channels=out_channels,
            up_block_types=up_block_types,
            block_out_channels=block_out_channels,
            layers_per_block=layers_per_block,
            act_fn=act_fn,
            norm_num_groups=norm_num_groups,
            norm_type=norm_type,
        )

    def _initialize_quantization(self, latent_channels, num_vq_embeddings, vq_embed_dim):
        vq_embed_dim = vq_embed_dim or latent_channels
        self.quant_conv = nn.Conv2d(latent_channels, vq_embed_dim, 1)
        self.quantize = VectorQuantizer(num_vq_embeddings, vq_embed_dim, beta=0.25)
        self.post_quant_conv = nn.Conv2d(vq_embed_dim, latent_channels, 1)

        

    @apply_forward_hook
    def encode(self, x: torch.FloatTensor, return_dict: bool = True) -> VQEncoderOutput:
        h = self.encoder(x)
        h = self.quant_conv(h)
        return VQEncoderOutput(latents=h) if return_dict else (h,)

    
    @apply_forward_hook
    def decode(self, h: torch.FloatTensor, force_not_quantize: bool = False, return_dict: bool = True) -> Union[DecoderOutput, torch.FloatTensor]:
        quant = h if force_not_quantize else self.quantize(h)[0]
        quant2 = self.post_quant_conv(quant)
        dec = self.decoder(quant2, quant if self.config.norm_type == "spatial" else None)
        return DecoderOutput(sample=dec) if return_dict else (dec,)

    
    def forward(self, sample: torch.FloatTensor, return_dict: bool = True) -> Union[DecoderOutput, Tuple[torch.FloatTensor, ...]]:
        encoded = self.encode(sample).latents
        decoded = self.decode(encoded).sample
        return DecoderOutput(sample=decoded) if return_dict else (decoded,)